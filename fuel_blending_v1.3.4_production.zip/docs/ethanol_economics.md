# Analisi di Sensibilità e Vincoli Etanolo

Questo documento descrive le funzionalità di analisi di sensibilità e vincoli sull'etanolo implementate nel pacchetto `fuel_blending`.

## Vincoli sull'Etanolo

Il pacchetto supporta la definizione di vincoli specifici per l'etanolo nei blend di carburante. Questa funzionalità è particolarmente utile per i grade che richiedono una percentuale fissa di etanolo (come E5, E10, ecc.).

### Come Funziona

1. **Identificazione dell'Etanolo**: Un componente può essere marcato come etanolo impostando il flag `is_ethanol=True` nella definizione del componente.

2. **Definizione del Vincolo**: Per ogni grade, è possibile specificare un vincolo di etanolo utilizzando il campo `force_ethanol` di tipo `ForceEthanol`, che contiene:
   - `enabled`: Flag che indica se il vincolo è attivo
   - `mass_frac`: Frazione di massa dell'etanolo da forzare nel blend (es. 0.05 per E5)

3. **Applicazione del Vincolo**: Durante l'ottimizzazione, il componente etanolo viene trattato come un componente fisso con la frazione specificata, riducendo lo spazio di ricerca dell'ottimizzatore.

### Esempio di Utilizzo

```python
from fuel_blending.models import Component, Grade, ForceEthanol

# Definizione di un componente etanolo
ethanol = Component(
    name="Ethanol",
    delta_type="as_is",
    delta_value=10.0,
    density=790.0,
    properties={"ron": 108.0, "mon": 89.0, "rvp": 55.0},
    is_ethanol=True
)

# Definizione di un grade con vincolo di etanolo (E5)
e5_grade = Grade(
    name="E5_Premium",
    spec_min={"ron": 95.0, "mon": 85.0},
    spec_max={"rvp": 10.0},
    force_ethanol=ForceEthanol(enabled=True, mass_frac=0.05)
)
```

## Analisi Economica

Il pacchetto include funzionalità per l'analisi economica dei blend, permettendo di valutare il valore marginale dei componenti e calcolare i valori neutri.

### Concetti Chiave

1. **Valore Marginale (MV)**: Rappresenta quanto il costo totale del blend diminuisce (se positivo) o aumenta (se negativo) per ogni unità marginale del componente aggiunto.

2. **Differenziale Neutro**: Il differenziale di prezzo che renderebbe il componente "neutro" in termini di impatto sul costo totale del blend.

3. **Moltiplicatore Neutro**: Il moltiplicatore che, applicato al prezzo flat, renderebbe il componente "neutro".

### Caratteristiche dell'Analisi Economica

- **Esclusione dell'Etanolo**: L'etanolo viene automaticamente escluso dall'analisi economica, poiché è considerato un componente forzato con una frazione fissa.

- **Supporto per Diversi Tipi di Pricing**: L'analisi supporta i tre tipi di pricing dei componenti:
  - `as_is`: Prezzo flat + differenziale fisso
  - `factor`: Prezzo flat * moltiplicatore
  - `escalated`: Prezzo flat * (densità base / densità componente)

- **Calcolo dei Valori Neutri**: Per ogni componente, l'analisi calcola:
  - Per componenti `as_is`: il differenziale neutro
  - Per componenti `factor`: il moltiplicatore neutro
  - Per componenti `escalated`: il differenziale neutro (basato sul valore marginale)

### Esempio di Utilizzo

```python
from fuel_blending.analysis.economic_analyzer import EconomicAnalyzer

# Assumendo che components, grades e optimization_results siano già definiti
flat_price = 700.0  # USD/mt

# Analisi dei candidati
results_df = EconomicAnalyzer.analyze_candidates(
    candidates=components,
    grades=grades,
    optimization_results=optimization_results,
    flat_price=flat_price
)

# Il DataFrame results_df contiene:
# - Nome del candidato
# - Nome del grade
# - Valore marginale (USD/mt)
# - Differenziale neutro (per componenti as_is e escalated)
# - Moltiplicatore neutro (per componenti factor)
```

## Integrazione con il Modello di Ottimizzazione

Entrambe le funzionalità sono completamente integrate con il modello di ottimizzazione del pacchetto:

1. **Vincoli Etanolo**: Vengono applicati durante la costruzione del contesto di blending e influenzano direttamente l'ottimizzazione.

2. **Analisi Economica**: Utilizza i risultati dell'ottimizzazione (in particolare i moltiplicatori di Lagrange) per calcolare i valori marginali e neutri.

## Note Importanti

- I vincoli sull'etanolo hanno la precedenza su altri vincoli e considerazioni economiche.
- L'analisi economica esclude sempre l'etanolo, indipendentemente dal fatto che sia forzato o meno.
- I prezzi e i differenziali sono espressi in USD/mt, coerentemente con il resto del modello.
