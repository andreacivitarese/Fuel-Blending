import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter
import xlsxwriter

# Crea il DataFrame per i componenti
components_data = {
    'name': [
        'Naphtha_Light_as_is',      # Esempio as_is
        'Naphtha_Heavy_factor',     # Esempio factor
        'Reformate_escalated',      # Esempio escalated
        'Ethanol',                  # Esempio etanolo
        'Isomerate',                # Esempio normale
        'Alkylate',                 # Esempio normale
        'FCC_Naphtha',              # Esempio normale
        'Butane',                   # Esempio normale
        'MTBE',                     # Esempio con MTBE
        'Toluene'                   # Esempio con aromatici alti
    ],
    'delta_type': [
        'as_is',                    # Differenziale as_is
        'factor',                   # Differenziale factor
        'escalated',                # Differenziale escalated
        'as_is',                    # as_is per etanolo
        'as_is',                    # as_is normale
        'factor',                   # factor normale
        'as_is',                    # as_is normale
        'factor',                   # factor normale
        'as_is',                    # as_is per MTBE
        'escalated'                 # escalated per toluene
    ],
    'delta_value': [
        7.5,                        # Valore per as_is
        None,                       # None per factor
        None,                       # None per escalated
        20.0,                       # Valore per etanolo
        5.0,                        # Valore normale
        None,                       # None per factor
        -3.0,                       # Valore negativo
        None,                       # None per factor
        15.0,                       # Valore per MTBE
        None                        # None per escalated
    ],
    'multiplier': [
        None,                       # None per as_is
        1.05,                       # Valore per factor
        None,                       # None per escalated
        None,                       # None per as_is
        None,                       # None per as_is
        1.02,                       # Valore per factor
        None,                       # None per as_is
        0.98,                       # Valore per factor
        None,                       # None per as_is
        None                        # None per escalated
    ],
    'base_density_component': [
        None,                       # None per as_is
        None,                       # None per factor
        'Naphtha_Light_as_is',      # Componente base per escalated
        None,                       # None per as_is
        None,                       # None per as_is
        None,                       # None per factor
        None,                       # None per as_is
        None,                       # None per factor
        None,                       # None per as_is
        'Naphtha_Heavy_factor'      # Componente base per escalated
    ],
    'density': [
        0.680,                      # Densità bassa
        0.750,                      # Densità media
        0.790,                      # Densità alta
        0.794,                      # Densità etanolo
        0.660,                      # Densità bassa
        0.700,                      # Densità media
        0.740,                      # Densità media
        0.580,                      # Densità molto bassa
        0.740,                      # Densità MTBE
        0.870                       # Densità alta
    ],
    'ron': [
        72.0,                       # RON basso
        85.0,                       # RON medio
        98.0,                       # RON alto
        120.0,                      # RON etanolo
        88.0,                       # RON medio
        95.0,                       # RON alto
        92.0,                       # RON medio-alto
        93.0,                       # RON alto
        118.0,                      # RON MTBE
        115.0                       # RON alto
    ],
    'mon': [
        70.0,                       # MON basso
        80.0,                       # MON medio
        87.0,                       # MON alto
        100.0,                      # MON etanolo
        86.0,                       # MON medio-alto
        93.0,                       # MON alto
        80.0,                       # MON medio
        92.0,                       # MON alto
        100.0,                      # MON MTBE
        103.0                       # MON alto
    ],
    'rvp': [
        12.0,                       # RVP medio
        3.0,                        # RVP basso
        2.5,                        # RVP basso
        18.0,                       # RVP etanolo
        14.0,                       # RVP alto
        5.0,                        # RVP medio
        7.0,                        # RVP medio
        60.0,                       # RVP molto alto
        8.0,                        # RVP MTBE
        2.0                         # RVP basso
    ],
    'sulfur_ppm': [
        5.0,                        # Zolfo basso
        50.0,                       # Zolfo medio
        1.0,                        # Zolfo molto basso
        0.0,                        # Zolfo etanolo
        1.0,                        # Zolfo molto basso
        1.0,                        # Zolfo molto basso
        150.0,                      # Zolfo alto
        1.0,                        # Zolfo molto basso
        0.0,                        # Zolfo MTBE
        1.0                         # Zolfo molto basso
    ],
    'benzene': [
        0.5,                        # Benzene basso
        1.0,                        # Benzene medio
        0.8,                        # Benzene medio
        0.0,                        # Benzene etanolo
        0.1,                        # Benzene molto basso
        0.0,                        # Benzene nullo
        0.7,                        # Benzene medio
        0.0,                        # Benzene nullo
        0.0,                        # Benzene MTBE
        5.0                         # Benzene alto
    ],
    'aromatics': [
        5.0,                        # Aromatici bassi
        20.0,                       # Aromatici medi
        65.0,                       # Aromatici alti
        0.0,                        # Aromatici etanolo
        0.0,                        # Aromatici nulli
        0.0,                        # Aromatici nulli
        25.0,                       # Aromatici medi
        0.0,                        # Aromatici nulli
        0.0,                        # Aromatici MTBE
        95.0                        # Aromatici molto alti
    ],
    'olefins': [
        1.0,                        # Olefine basse
        1.0,                        # Olefine basse
        1.0,                        # Olefine basse
        0.0,                        # Olefine etanolo
        0.0,                        # Olefine nulle
        0.0,                        # Olefine nulle
        20.0,                       # Olefine alte
        0.0,                        # Olefine nulle
        0.0,                        # Olefine MTBE
        0.0                         # Olefine nulle
    ],
    'mtbe': [
        0.0,                        # MTBE nullo
        0.0,                        # MTBE nullo
        0.0,                        # MTBE nullo
        0.0,                        # MTBE etanolo
        0.0,                        # MTBE nullo
        0.0,                        # MTBE nullo
        0.0,                        # MTBE nullo
        0.0,                        # MTBE nullo
        100.0,                      # MTBE 100%
        0.0                         # MTBE nullo
    ],
    't10': [
        40.0,                       # T10 basso
        70.0,                       # T10 medio
        90.0,                       # T10 alto
        78.0,                       # T10 etanolo
        35.0,                       # T10 basso
        60.0,                       # T10 medio
        55.0,                       # T10 medio
        -5.0,                       # T10 molto basso
        55.0,                       # T10 MTBE
        110.0                       # T10 alto
    ],
    't50': [
        80.0,                       # T50 basso
        110.0,                      # T50 medio
        120.0,                      # T50 alto
        78.0,                       # T50 etanolo
        75.0,                       # T50 basso
        95.0,                       # T50 medio
        90.0,                       # T50 medio
        -5.0,                       # T50 molto basso
        55.0,                       # T50 MTBE
        110.0                       # T50 alto
    ],
    'e70': [
        35.0,                       # E70 medio
        15.0,                       # E70 basso
        10.0,                       # E70 basso
        100.0,                      # E70 etanolo
        40.0,                       # E70 medio
        25.0,                       # E70 medio
        30.0,                       # E70 medio
        100.0,                      # E70 alto
        70.0,                       # E70 MTBE
        5.0                         # E70 basso
    ],
    'oxy_wt': [
        0.0,                        # Ossigeno nullo
        0.0,                        # Ossigeno nullo
        0.0,                        # Ossigeno nullo
        34.7,                       # Ossigeno etanolo
        0.0,                        # Ossigeno nullo
        0.0,                        # Ossigeno nullo
        0.0,                        # Ossigeno nullo
        0.0,                        # Ossigeno nullo
        18.2,                       # Ossigeno MTBE
        0.0                         # Ossigeno nullo
    ],
    'is_ethanol': [
        False,                      # Non etanolo
        False,                      # Non etanolo
        False,                      # Non etanolo
        True,                       # Etanolo
        False,                      # Non etanolo
        False,                      # Non etanolo
        False,                      # Non etanolo
        False,                      # Non etanolo
        False,                      # Non etanolo
        False                       # Non etanolo
    ]
}

# Crea il DataFrame
df_components = pd.DataFrame(components_data)

# Crea un file Excel con formattazione avanzata
def create_formatted_excel(df, file_path, sheet_name, title, description, color_theme='blue'):
    # Crea un nuovo workbook
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_name
    
    # Definisci gli stili
    if color_theme == 'blue':
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        title_fill = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
        alt_row_fill = PatternFill(start_color="EBF1F8", end_color="EBF1F8", fill_type="solid")
    elif color_theme == 'green':
        header_fill = PatternFill(start_color="375623", end_color="375623", fill_type="solid")
        title_fill = PatternFill(start_color="E2EFD9", end_color="E2EFD9", fill_type="solid")
        alt_row_fill = PatternFill(start_color="F2F9EC", end_color="F2F9EC", fill_type="solid")
    else:  # red
        header_fill = PatternFill(start_color="953735", end_color="953735", fill_type="solid")
        title_fill = PatternFill(start_color="F2DCDB", end_color="F2DCDB", fill_type="solid")
        alt_row_fill = PatternFill(start_color="FCF0EF", end_color="FCF0EF", fill_type="solid")
    
    header_font = Font(bold=True, color="FFFFFF", size=12)
    title_font = Font(bold=True, size=14)
    desc_font = Font(italic=True, size=11)
    
    # Aggiungi titolo e descrizione
    worksheet.merge_cells('A1:D1')
    title_cell = worksheet['A1']
    title_cell.value = title
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal='left', vertical='center')
    title_cell.fill = title_fill
    
    # Aggiungi descrizione
    worksheet.merge_cells('A2:D2')
    desc_cell = worksheet['A2']
    desc_cell.value = description
    desc_cell.font = desc_font
    desc_cell.alignment = Alignment(horizontal='left', vertical='center')
    
    # Aggiungi spazio
    worksheet.append([])
    
    # Aggiungi intestazioni
    headers = list(df.columns)
    worksheet.append(headers)
    
    # Formatta intestazioni
    for cell in worksheet[4]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    
    # Aggiungi dati
    for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
        worksheet.append(row)
        # Formatta righe alternate
        if r_idx % 2 == 0:
            for cell in worksheet[r_idx + 5]:
                cell.fill = alt_row_fill
    
    # Imposta larghezza colonne
    for i, column in enumerate(df.columns):
        col_letter = get_column_letter(i + 1)
        # Imposta larghezza in base alla lunghezza massima dei valori
        max_length = max(
            len(str(column)),
            df[column].astype(str).map(len).max()
        )
        adjusted_width = max_length + 2
        worksheet.column_dimensions[col_letter].width = adjusted_width
    
    # Aggiungi bordi a tutte le celle
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
        for cell in row:
            cell.border = thin_border
    
    # Aggiungi filtro alle intestazioni
    worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
    
    # Blocca le intestazioni
    worksheet.freeze_panes = "A5"
    
    # Salva il file
    workbook.save(file_path)

# Crea il file Excel formattato per i componenti
components_file_path = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/components_example.xlsx'
components_title = 'Componenti per Fuel Blending'
components_description = 'Questo foglio contiene esempi di tutti i tipi di componenti possibili (as_is, factor, escalated, etanolo, ecc.)'

create_formatted_excel(
    df_components, 
    components_file_path, 
    'Componenti', 
    components_title, 
    components_description, 
    'blue'
)

print(f"File Excel dei componenti creato: {components_file_path}")
