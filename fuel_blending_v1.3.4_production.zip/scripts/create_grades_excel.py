import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter
import json

# Crea il DataFrame per i grade con formato JSON per le specifiche
grades_json_data = {
    'name': [
        'Regular_ASIS',           # Grade regolare con prezzo as_is
        'Premium_ASIS',           # Grade premium con prezzo as_is
        'Regular_ESC',            # Grade regolare con prezzo escalated
        'Premium_ESC',            # Grade premium con prezzo escalated
        'E5_Regular',             # Grade con etanolo forzato al 5%
        'E10_Premium'             # Grade con etanolo forzato al 10%
    ],
    'specs': [
        # Regular_ASIS - specifiche base
        json.dumps({
            "RON": [91, None],
            "MON": [81, None],
            "RVP": [None, 60],
            "sulfur_ppm": [None, 10],
            "benzene": [None, 1],
            "aromatics": [None, 35],
            "olefins": [None, 18],
            "mtbe": [None, 15],
            "oxy_wt": [None, 2.7],
            "t10": [None, 70],
            "t50": [None, 110],
            "e70": [20, 48],
            "vli": [None, 1200]
        }),
        # Premium_ASIS - specifiche premium
        json.dumps({
            "RON": [95, None],
            "MON": [85, None],
            "RVP": [None, 60],
            "sulfur_ppm": [None, 10],
            "benzene": [None, 1],
            "aromatics": [None, 35],
            "olefins": [None, 18],
            "mtbe": [None, 15],
            "oxy_wt": [None, 2.7],
            "t10": [None, 70],
            "t50": [None, 110],
            "e70": [20, 48],
            "vli": [None, 1200]
        }),
        # Regular_ESC - specifiche base con prezzo escalated
        json.dumps({
            "RON": [91, None],
            "MON": [81, None],
            "RVP": [None, 60],
            "sulfur_ppm": [None, 10],
            "benzene": [None, 1],
            "aromatics": [None, 35],
            "olefins": [None, 18],
            "mtbe": [None, 15],
            "oxy_wt": [None, 2.7],
            "t10": [None, 70],
            "t50": [None, 110],
            "e70": [20, 48],
            "vli": [None, 1200]
        }),
        # Premium_ESC - specifiche premium con prezzo escalated
        json.dumps({
            "RON": [95, None],
            "MON": [85, None],
            "RVP": [None, 60],
            "sulfur_ppm": [None, 10],
            "benzene": [None, 1],
            "aromatics": [None, 35],
            "olefins": [None, 18],
            "mtbe": [None, 15],
            "oxy_wt": [None, 2.7],
            "t10": [None, 70],
            "t50": [None, 110],
            "e70": [20, 48],
            "vli": [None, 1200]
        }),
        # E5_Regular - specifiche con etanolo forzato al 5%
        json.dumps({
            "RON": [91, None],
            "MON": [81, None],
            "RVP": [None, 60],
            "sulfur_ppm": [None, 10],
            "benzene": [None, 1],
            "aromatics": [None, 35],
            "olefins": [None, 18],
            "mtbe": [None, 15],
            "oxy_wt": [None, 2.7],
            "t10": [None, 70],
            "t50": [None, 110],
            "e70": [20, 48],
            "vli": [None, 1200]
        }),
        # E10_Premium - specifiche premium con etanolo forzato al 10%
        json.dumps({
            "RON": [95, None],
            "MON": [85, None],
            "RVP": [None, 60],
            "sulfur_ppm": [None, 10],
            "benzene": [None, 1],
            "aromatics": [None, 35],
            "olefins": [None, 18],
            "mtbe": [None, 15],
            "oxy_wt": [None, 2.7],
            "t10": [None, 70],
            "t50": [None, 110],
            "e70": [20, 48],
            "vli": [None, 1200]
        })
    ],
    'target_mass': [
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000                      # Massa target standard
    ],
    'price_mode': [
        'as_is',                  # Prezzo as_is
        'as_is',                  # Prezzo as_is
        'escalated',              # Prezzo escalated
        'escalated',              # Prezzo escalated
        'as_is',                  # Prezzo as_is
        'escalated'               # Prezzo escalated
    ],
    'ron_linear_min': [
        None,                     # RON lineare non specificato
        None,                     # RON lineare non specificato
        None,                     # RON lineare non specificato
        None,                     # RON lineare non specificato
        90.5,                     # RON lineare specificato
        94.5                      # RON lineare specificato
    ],
    'force_ethanol_enabled': [
        False,                    # Etanolo non forzato
        False,                    # Etanolo non forzato
        False,                    # Etanolo non forzato
        False,                    # Etanolo non forzato
        True,                     # Etanolo forzato
        True                      # Etanolo forzato
    ],
    'force_ethanol_mass_frac': [
        0.0,                      # Frazione di massa etanolo non specificata
        0.0,                      # Frazione di massa etanolo non specificata
        0.0,                      # Frazione di massa etanolo non specificata
        0.0,                      # Frazione di massa etanolo non specificata
        0.05,                     # 5% etanolo
        0.10                      # 10% etanolo
    ]
}

# Crea il DataFrame per i grade con formato colonne separate per min/max
grades_columns_data = {
    'name': [
        'Regular_ASIS_Columns',   # Grade regolare con prezzo as_is
        'Premium_ASIS_Columns',   # Grade premium con prezzo as_is
        'Regular_ESC_Columns',    # Grade regolare con prezzo escalated
        'Premium_ESC_Columns',    # Grade premium con prezzo escalated
        'E5_Regular_Columns',     # Grade con etanolo forzato al 5%
        'E10_Premium_Columns'     # Grade con etanolo forzato al 10%
    ],
    'target_mass': [
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000,                     # Massa target standard
        1000                      # Massa target standard
    ],
    'price_mode': [
        'as_is',                  # Prezzo as_is
        'as_is',                  # Prezzo as_is
        'escalated',              # Prezzo escalated
        'escalated',              # Prezzo escalated
        'as_is',                  # Prezzo as_is
        'escalated'               # Prezzo escalated
    ],
    'ron_linear_min': [
        None,                     # RON lineare non specificato
        None,                     # RON lineare non specificato
        None,                     # RON lineare non specificato
        None,                     # RON lineare non specificato
        90.5,                     # RON lineare specificato
        94.5                      # RON lineare specificato
    ],
    'force_ethanol_enabled': [
        False,                    # Etanolo non forzato
        False,                    # Etanolo non forzato
        False,                    # Etanolo non forzato
        False,                    # Etanolo non forzato
        True,                     # Etanolo forzato
        True                      # Etanolo forzato
    ],
    'force_ethanol_mass_frac': [
        0.0,                      # Frazione di massa etanolo non specificata
        0.0,                      # Frazione di massa etanolo non specificata
        0.0,                      # Frazione di massa etanolo non specificata
        0.0,                      # Frazione di massa etanolo non specificata
        0.05,                     # 5% etanolo
        0.10                      # 10% etanolo
    ],
    'RON_min': [
        91,                       # RON minimo regolare
        95,                       # RON minimo premium
        91,                       # RON minimo regolare
        95,                       # RON minimo premium
        91,                       # RON minimo regolare
        95                        # RON minimo premium
    ],
    'RON_max': [
        None,                     # RON massimo non specificato
        None,                     # RON massimo non specificato
        None,                     # RON massimo non specificato
        None,                     # RON massimo non specificato
        None,                     # RON massimo non specificato
        None                      # RON massimo non specificato
    ],
    'MON_min': [
        81,                       # MON minimo regolare
        85,                       # MON minimo premium
        81,                       # MON minimo regolare
        85,                       # MON minimo premium
        81,                       # MON minimo regolare
        85                        # MON minimo premium
    ],
    'MON_max': [
        None,                     # MON massimo non specificato
        None,                     # MON massimo non specificato
        None,                     # MON massimo non specificato
        None,                     # MON massimo non specificato
        None,                     # MON massimo non specificato
        None                      # MON massimo non specificato
    ],
    'RVP_min': [
        None,                     # RVP minimo non specificato
        None,                     # RVP minimo non specificato
        None,                     # RVP minimo non specificato
        None,                     # RVP minimo non specificato
        None,                     # RVP minimo non specificato
        None                      # RVP minimo non specificato
    ],
    'RVP_max': [
        60,                       # RVP massimo
        60,                       # RVP massimo
        60,                       # RVP massimo
        60,                       # RVP massimo
        60,                       # RVP massimo
        60                        # RVP massimo
    ],
    'sulfur_ppm_min': [
        None,                     # Zolfo minimo non specificato
        None,                     # Zolfo minimo non specificato
        None,                     # Zolfo minimo non specificato
        None,                     # Zolfo minimo non specificato
        None,                     # Zolfo minimo non specificato
        None                      # Zolfo minimo non specificato
    ],
    'sulfur_ppm_max': [
        10,                       # Zolfo massimo
        10,                       # Zolfo massimo
        10,                       # Zolfo massimo
        10,                       # Zolfo massimo
        10,                       # Zolfo massimo
        10                        # Zolfo massimo
    ],
    'benzene_min': [
        None,                     # Benzene minimo non specificato
        None,                     # Benzene minimo non specificato
        None,                     # Benzene minimo non specificato
        None,                     # Benzene minimo non specificato
        None,                     # Benzene minimo non specificato
        None                      # Benzene minimo non specificato
    ],
    'benzene_max': [
        1,                        # Benzene massimo
        1,                        # Benzene massimo
        1,                        # Benzene massimo
        1,                        # Benzene massimo
        1,                        # Benzene massimo
        1                         # Benzene massimo
    ],
    'aromatics_min': [
        None,                     # Aromatici minimo non specificato
        None,                     # Aromatici minimo non specificato
        None,                     # Aromatici minimo non specificato
        None,                     # Aromatici minimo non specificato
        None,                     # Aromatici minimo non specificato
        None                      # Aromatici minimo non specificato
    ],
    'aromatics_max': [
        35,                       # Aromatici massimo
        35,                       # Aromatici massimo
        35,                       # Aromatici massimo
        35,                       # Aromatici massimo
        35,                       # Aromatici massimo
        35                        # Aromatici massimo
    ],
    'olefins_min': [
        None,                     # Olefine minimo non specificato
        None,                     # Olefine minimo non specificato
        None,                     # Olefine minimo non specificato
        None,                     # Olefine minimo non specificato
        None,                     # Olefine minimo non specificato
        None                      # Olefine minimo non specificato
    ],
    'olefins_max': [
        18,                       # Olefine massimo
        18,                       # Olefine massimo
        18,                       # Olefine massimo
        18,                       # Olefine massimo
        18,                       # Olefine massimo
        18                        # Olefine massimo
    ],
    'mtbe_min': [
        None,                     # MTBE minimo non specificato
        None,                     # MTBE minimo non specificato
        None,                     # MTBE minimo non specificato
        None,                     # MTBE minimo non specificato
        None,                     # MTBE minimo non specificato
        None                      # MTBE minimo non specificato
    ],
    'mtbe_max': [
        15,                       # MTBE massimo
        15,                       # MTBE massimo
        15,                       # MTBE massimo
        15,                       # MTBE massimo
        15,                       # MTBE massimo
        15                        # MTBE massimo
    ],
    'oxy_wt_min': [
        None,                     # Ossigeno minimo non specificato
        None,                     # Ossigeno minimo non specificato
        None,                     # Ossigeno minimo non specificato
        None,                     # Ossigeno minimo non specificato
        None,                     # Ossigeno minimo non specificato
        None                      # Ossigeno minimo non specificato
    ],
    'oxy_wt_max': [
        2.7,                      # Ossigeno massimo
        2.7,                      # Ossigeno massimo
        2.7,                      # Ossigeno massimo
        2.7,                      # Ossigeno massimo
        2.7,                      # Ossigeno massimo
        2.7                       # Ossigeno massimo
    ],
    't10_min': [
        None,                     # T10 minimo non specificato
        None,                     # T10 minimo non specificato
        None,                     # T10 minimo non specificato
        None,                     # T10 minimo non specificato
        None,                     # T10 minimo non specificato
        None                      # T10 minimo non specificato
    ],
    't10_max': [
        70,                       # T10 massimo
        70,                       # T10 massimo
        70,                       # T10 massimo
        70,                       # T10 massimo
        70,                       # T10 massimo
        70                        # T10 massimo
    ],
    't50_min': [
        None,                     # T50 minimo non specificato
        None,                     # T50 minimo non specificato
        None,                     # T50 minimo non specificato
        None,                     # T50 minimo non specificato
        None,                     # T50 minimo non specificato
        None                      # T50 minimo non specificato
    ],
    't50_max': [
        110,                      # T50 massimo
        110,                      # T50 massimo
        110,                      # T50 massimo
        110,                      # T50 massimo
        110,                      # T50 massimo
        110                       # T50 massimo
    ],
    'e70_min': [
        20,                       # E70 minimo
        20,                       # E70 minimo
        20,                       # E70 minimo
        20,                       # E70 minimo
        20,                       # E70 minimo
        20                        # E70 minimo
    ],
    'e70_max': [
        48,                       # E70 massimo
        48,                       # E70 massimo
        48,                       # E70 massimo
        48,                       # E70 massimo
        48,                       # E70 massimo
        48                        # E70 massimo
    ],
    'vli_min': [
        None,                     # VLI minimo non specificato
        None,                     # VLI minimo non specificato
        None,                     # VLI minimo non specificato
        None,                     # VLI minimo non specificato
        None,                     # VLI minimo non specificato
        None                      # VLI minimo non specificato
    ],
    'vli_max': [
        1200,                     # VLI massimo
        1200,                     # VLI massimo
        1200,                     # VLI massimo
        1200,                     # VLI massimo
        1200,                     # VLI massimo
        1200                      # VLI massimo
    ]
}

# Crea i DataFrame
df_grades_json = pd.DataFrame(grades_json_data)
df_grades_columns = pd.DataFrame(grades_columns_data)

# Crea un file Excel con formattazione avanzata
def create_formatted_excel(df, file_path, sheet_name, title, description, color_theme='green'):
    # Crea un nuovo workbook
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_name
    
    # Definisci gli stili
    if color_theme == 'blue':
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        title_fill = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
        alt_row_fill = PatternFill(start_color="EBF1F8", end_color="EBF1F8", fill_type="solid")
    elif color_theme == 'green':
        header_fill = PatternFill(start_color="375623", end_color="375623", fill_type="solid")
        title_fill = PatternFill(start_color="E2EFD9", end_color="E2EFD9", fill_type="solid")
        alt_row_fill = PatternFill(start_color="F2F9EC", end_color="F2F9EC", fill_type="solid")
    else:  # red
        header_fill = PatternFill(start_color="953735", end_color="953735", fill_type="solid")
        title_fill = PatternFill(start_color="F2DCDB", end_color="F2DCDB", fill_type="solid")
        alt_row_fill = PatternFill(start_color="FCF0EF", end_color="FCF0EF", fill_type="solid")
    
    header_font = Font(bold=True, color="FFFFFF", size=12)
    title_font = Font(bold=True, size=14)
    desc_font = Font(italic=True, size=11)
    
    # Aggiungi titolo e descrizione
    worksheet.merge_cells('A1:D1')
    title_cell = worksheet['A1']
    title_cell.value = title
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal='left', vertical='center')
    title_cell.fill = title_fill
    
    # Aggiungi descrizione
    worksheet.merge_cells('A2:D2')
    desc_cell = worksheet['A2']
    desc_cell.value = description
    desc_cell.font = desc_font
    desc_cell.alignment = Alignment(horizontal='left', vertical='center')
    
    # Aggiungi spazio
    worksheet.append([])
    
    # Aggiungi intestazioni
    headers = list(df.columns)
    worksheet.append(headers)
    
    # Formatta intestazioni
    for cell in worksheet[4]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    
    # Aggiungi dati
    for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
        worksheet.append(row)
        # Formatta righe alternate
        if r_idx % 2 == 0:
            for cell in worksheet[r_idx + 5]:
                cell.fill = alt_row_fill
    
    # Imposta larghezza colonne
    for i, column in enumerate(df.columns):
        col_letter = get_column_letter(i + 1)
        # Imposta larghezza in base alla lunghezza massima dei valori
        max_length = max(
            len(str(column)),
            df[column].astype(str).map(len).max()
        )
        adjusted_width = max_length + 2
        worksheet.column_dimensions[col_letter].width = adjusted_width
    
    # Aggiungi bordi a tutte le celle
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
        for cell in row:
            cell.border = thin_border
    
    # Aggiungi filtro alle intestazioni
    worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
    
    # Blocca le intestazioni
    worksheet.freeze_panes = "A5"
    
    # Salva il file
    workbook.save(file_path)

# Crea un file Excel con più fogli
def create_multi_sheet_excel(file_path, dataframes, sheet_names, titles, descriptions, color_themes):
    # Crea un nuovo workbook
    workbook = Workbook()
    
    # Rimuovi il foglio predefinito
    default_sheet = workbook.active
    workbook.remove(default_sheet)
    
    # Aggiungi ogni DataFrame come foglio
    for i, (df, sheet_name, title, description, color_theme) in enumerate(zip(dataframes, sheet_names, titles, descriptions, color_themes)):
        # Crea un nuovo foglio
        worksheet = workbook.create_sheet(sheet_name)
        
        # Definisci gli stili
        if color_theme == 'blue':
            header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
            title_fill = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
            alt_row_fill = PatternFill(start_color="EBF1F8", end_color="EBF1F8", fill_type="solid")
        elif color_theme == 'green':
            header_fill = PatternFill(start_color="375623", end_color="375623", fill_type="solid")
            title_fill = PatternFill(start_color="E2EFD9", end_color="E2EFD9", fill_type="solid")
            alt_row_fill = PatternFill(start_color="F2F9EC", end_color="F2F9EC", fill_type="solid")
        else:  # red
            header_fill = PatternFill(start_color="953735", end_color="953735", fill_type="solid")
            title_fill = PatternFill(start_color="F2DCDB", end_color="F2DCDB", fill_type="solid")
            alt_row_fill = PatternFill(start_color="FCF0EF", end_color="FCF0EF", fill_type="solid")
        
        header_font = Font(bold=True, color="FFFFFF", size=12)
        title_font = Font(bold=True, size=14)
        desc_font = Font(italic=True, size=11)
        
        # Aggiungi titolo e descrizione
        worksheet.merge_cells('A1:D1')
        title_cell = worksheet['A1']
        title_cell.value = title
        title_cell.font = title_font
        title_cell.alignment = Alignment(horizontal='left', vertical='center')
        title_cell.fill = title_fill
        
        # Aggiungi descrizione
        worksheet.merge_cells('A2:D2')
        desc_cell = worksheet['A2']
        desc_cell.value = description
        desc_cell.font = desc_font
        desc_cell.alignment = Alignment(horizontal='left', vertical='center')
        
        # Aggiungi spazio
        worksheet.append([])
        
        # Aggiungi intestazioni
        headers = list(df.columns)
        worksheet.append(headers)
        
        # Formatta intestazioni
        for cell in worksheet[4]:
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        
        # Aggiungi dati
        for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
            worksheet.append(row)
            # Formatta righe alternate
            if r_idx % 2 == 0:
                for cell in worksheet[r_idx + 5]:
                    cell.fill = alt_row_fill
        
        # Imposta larghezza colonne
        for i, column in enumerate(df.columns):
            col_letter = get_column_letter(i + 1)
            # Imposta larghezza in base alla lunghezza massima dei valori
            max_length = max(
                len(str(column)),
                df[column].astype(str).map(len).max()
            )
            adjusted_width = max_length + 2
            worksheet.column_dimensions[col_letter].width = adjusted_width
        
        # Aggiungi bordi a tutte le celle
        thin_border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
            for cell in row:
                cell.border = thin_border
        
        # Aggiungi filtro alle intestazioni
        worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
        
        # Blocca le intestazioni
        worksheet.freeze_panes = "A5"
    
    # Salva il file
    workbook.save(file_path)

# Crea il file Excel formattato per i grade
grades_file_path = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/grades_example.xlsx'

# Crea il file Excel con due fogli
create_multi_sheet_excel(
    grades_file_path,
    [df_grades_json, df_grades_columns],
    ['Grade_JSON', 'Grade_Columns'],
    ['Grade con specifiche in formato JSON', 'Grade con specifiche in colonne separate'],
    [
        'Questo foglio contiene esempi di grade con specifiche in formato JSON, coprendo tutti i casi d\'uso (as_is, escalated, etanolo forzato, ecc.)',
        'Questo foglio contiene esempi di grade con specifiche in colonne separate per min/max, coprendo tutti i casi d\'uso (as_is, escalated, etanolo forzato, ecc.)'
    ],
    ['green', 'green']
)

print(f"File Excel dei grade creato: {grades_file_path}")
