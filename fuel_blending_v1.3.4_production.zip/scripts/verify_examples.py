"""
Script per verificare la completezza degli esempi Excel creati.

Questo script verifica che tutti i file Excel di esempio siano stati creati correttamente
e che contengano tutti i casi d'uso necessari.
"""

import os
import pandas as pd
import yaml
import json

def check_file_exists(file_path, file_type):
    """Verifica che il file esista."""
    if os.path.exists(file_path):
        print(f"✅ File {file_type} trovato: {file_path}")
        return True
    else:
        print(f"❌ File {file_type} NON trovato: {file_path}")
        return False

def check_components_file(file_path):
    """Verifica la completezza del file dei componenti."""
    if not check_file_exists(file_path, "componenti"):
        return False
    
    try:
        # Leggi il file Excel
        df = pd.read_excel(file_path)
        
        # Verifica che tutte le colonne necessarie siano presenti
        required_columns = [
            'name', 'delta_type', 'delta_value', 'multiplier', 'base_density_component',
            'density', 'ron', 'mon', 'rvp', 'sulfur_ppm', 'benzene', 'aromatics',
            'olefins', 'mtbe', 't10', 't50', 'e70', 'oxy_wt', 'is_ethanol'
        ]
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            print(f"❌ Colonne mancanti nel file dei componenti: {', '.join(missing_columns)}")
            return False
        else:
            print("✅ Tutte le colonne necessarie sono presenti nel file dei componenti")
        
        # Verifica che ci siano esempi di tutti i tipi di delta_type
        delta_types = df['delta_type'].unique()
        required_delta_types = ['as_is', 'factor', 'escalated']
        
        missing_delta_types = [dt for dt in required_delta_types if dt not in delta_types]
        if missing_delta_types:
            print(f"❌ Tipi di delta mancanti nel file dei componenti: {', '.join(missing_delta_types)}")
            return False
        else:
            print("✅ Tutti i tipi di delta sono presenti nel file dei componenti")
        
        # Verifica che ci sia almeno un componente etanolo
        if not any(df['is_ethanol']):
            print("❌ Nessun componente etanolo trovato nel file dei componenti")
            return False
        else:
            print("✅ Componente etanolo trovato nel file dei componenti")
        
        # Verifica che ci siano almeno 5 componenti
        if len(df) < 5:
            print(f"❌ Numero insufficiente di componenti: {len(df)} (minimo 5)")
            return False
        else:
            print(f"✅ Numero sufficiente di componenti: {len(df)}")
        
        return True
        
    except Exception as e:
        print(f"❌ Errore durante la verifica del file dei componenti: {str(e)}")
        return False

def check_grades_file(file_path):
    """Verifica la completezza del file dei grade."""
    if not check_file_exists(file_path, "grade"):
        return False
    
    try:
        # Verifica che il file Excel contenga almeno due fogli
        excel_file = pd.ExcelFile(file_path)
        sheets = excel_file.sheet_names
        
        if len(sheets) < 2:
            print(f"❌ Numero insufficiente di fogli nel file dei grade: {len(sheets)} (minimo 2)")
            return False
        else:
            print(f"✅ Numero sufficiente di fogli nel file dei grade: {len(sheets)}")
        
        # Verifica il foglio con specifiche JSON
        json_sheet_name = [s for s in sheets if 'json' in s.lower()]
        if not json_sheet_name:
            print("❌ Nessun foglio con specifiche JSON trovato nel file dei grade")
            return False
        else:
            print(f"✅ Foglio con specifiche JSON trovato: {json_sheet_name[0]}")
            
            # Leggi il foglio con specifiche JSON
            df_json = pd.read_excel(file_path, sheet_name=json_sheet_name[0])
            
            # Verifica che tutte le colonne necessarie siano presenti
            required_columns_json = [
                'name', 'specs', 'target_mass', 'price_mode', 'ron_linear_min',
                'force_ethanol_enabled', 'force_ethanol_mass_frac'
            ]
            
            missing_columns_json = [col for col in required_columns_json if col not in df_json.columns]
            if missing_columns_json:
                print(f"❌ Colonne mancanti nel foglio JSON: {', '.join(missing_columns_json)}")
                return False
            else:
                print("✅ Tutte le colonne necessarie sono presenti nel foglio JSON")
            
            # Verifica che ci siano esempi di tutti i tipi di price_mode
            price_modes_json = df_json['price_mode'].unique()
            required_price_modes = ['as_is', 'escalated']
            
            missing_price_modes_json = [pm for pm in required_price_modes if pm not in price_modes_json]
            if missing_price_modes_json:
                print(f"❌ Modalità di prezzo mancanti nel foglio JSON: {', '.join(missing_price_modes_json)}")
                return False
            else:
                print("✅ Tutte le modalità di prezzo sono presenti nel foglio JSON")
            
            # Verifica che ci sia almeno un grade con etanolo forzato
            if not any(df_json['force_ethanol_enabled']):
                print("❌ Nessun grade con etanolo forzato trovato nel foglio JSON")
                return False
            else:
                print("✅ Grade con etanolo forzato trovato nel foglio JSON")
        
        # Verifica il foglio con specifiche in colonne separate
        columns_sheet_name = [s for s in sheets if 'column' in s.lower()]
        if not columns_sheet_name:
            print("❌ Nessun foglio con specifiche in colonne separate trovato nel file dei grade")
            return False
        else:
            print(f"✅ Foglio con specifiche in colonne separate trovato: {columns_sheet_name[0]}")
            
            # Leggi il foglio con specifiche in colonne separate
            df_columns = pd.read_excel(file_path, sheet_name=columns_sheet_name[0])
            
            # Verifica che ci siano colonne min/max per le proprietà
            min_max_columns = [col for col in df_columns.columns if '_min' in col or '_max' in col]
            if len(min_max_columns) < 10:  # Almeno 5 proprietà con min e max
                print(f"❌ Numero insufficiente di colonne min/max: {len(min_max_columns)} (minimo 10)")
                return False
            else:
                print(f"✅ Numero sufficiente di colonne min/max: {len(min_max_columns)}")
            
            # Verifica che ci siano esempi di tutti i tipi di price_mode
            price_modes_columns = df_columns['price_mode'].unique()
            
            missing_price_modes_columns = [pm for pm in required_price_modes if pm not in price_modes_columns]
            if missing_price_modes_columns:
                print(f"❌ Modalità di prezzo mancanti nel foglio colonne: {', '.join(missing_price_modes_columns)}")
                return False
            else:
                print("✅ Tutte le modalità di prezzo sono presenti nel foglio colonne")
            
            # Verifica che ci sia almeno un grade con etanolo forzato
            if not any(df_columns['force_ethanol_enabled']):
                print("❌ Nessun grade con etanolo forzato trovato nel foglio colonne")
                return False
            else:
                print("✅ Grade con etanolo forzato trovato nel foglio colonne")
        
        return True
        
    except Exception as e:
        print(f"❌ Errore durante la verifica del file dei grade: {str(e)}")
        return False

def check_additives_file(file_path, yaml_path=None):
    """Verifica la completezza del file degli additivi."""
    if not check_file_exists(file_path, "additivi"):
        return False
    
    try:
        # Leggi il file Excel
        df = pd.read_excel(file_path)
        
        # Verifica che tutte le colonne necessarie siano presenti
        required_columns = ['name', 'cost_usd_per_litre', 'density_add']
        
        missing_columns = [col for col in required_columns if col not in df.columns]
        if missing_columns:
            print(f"❌ Colonne mancanti nel file degli additivi: {', '.join(missing_columns)}")
            return False
        else:
            print("✅ Tutte le colonne necessarie sono presenti nel file degli additivi")
        
        # Verifica che ci siano almeno 3 additivi
        if len(df) < 3:
            print(f"❌ Numero insufficiente di additivi: {len(df)} (minimo 3)")
            return False
        else:
            print(f"✅ Numero sufficiente di additivi: {len(df)}")
        
        # Verifica il file YAML se specificato
        if yaml_path:
            if not check_file_exists(yaml_path, "additivi YAML"):
                return False
            
            try:
                # Leggi il file YAML
                with open(yaml_path, 'r') as f:
                    additives_yaml = yaml.safe_load(f)
                
                # Verifica che ci siano gli stessi additivi nel file YAML
                if len(additives_yaml) != len(df):
                    print(f"❌ Numero di additivi diverso tra Excel ({len(df)}) e YAML ({len(additives_yaml)})")
                    return False
                else:
                    print("✅ Stesso numero di additivi in Excel e YAML")
                
                # Verifica che tutti gli additivi abbiano le proprietà necessarie
                for name, props in additives_yaml.items():
                    if 'cost_usd_per_litre' not in props or 'density_add' not in props:
                        print(f"❌ Proprietà mancanti per l'additivo {name} nel file YAML")
                        return False
                
                print("✅ Tutte le proprietà necessarie sono presenti nel file YAML")
                
            except Exception as e:
                print(f"❌ Errore durante la verifica del file YAML degli additivi: {str(e)}")
                return False
        
        return True
        
    except Exception as e:
        print(f"❌ Errore durante la verifica del file degli additivi: {str(e)}")
        return False

def main():
    """Funzione principale."""
    print("\n=== VERIFICA COMPLETEZZA ESEMPI EXCEL ===\n")
    
    # Percorsi dei file
    components_file = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/components_example.xlsx'
    grades_file = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/grades_example.xlsx'
    additives_file = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/additives_example.xlsx'
    additives_yaml = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/additives_example.yaml'
    
    # Verifica i file
    print("\n--- Verifica file dei componenti ---")
    components_ok = check_components_file(components_file)
    
    print("\n--- Verifica file dei grade ---")
    grades_ok = check_grades_file(grades_file)
    
    print("\n--- Verifica file degli additivi ---")
    additives_ok = check_additives_file(additives_file, additives_yaml)
    
    # Risultato complessivo
    print("\n--- Risultato complessivo ---")
    if components_ok and grades_ok and additives_ok:
        print("✅ TUTTI I FILE SONO COMPLETI E CONTENGONO TUTTI I CASI D'USO NECESSARI")
        return True
    else:
        print("❌ ALCUNI FILE NON SONO COMPLETI O NON CONTENGONO TUTTI I CASI D'USO NECESSARI")
        return False

if __name__ == "__main__":
    main()
