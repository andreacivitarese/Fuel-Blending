import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter

# Crea il DataFrame per i grades da valorizzare
grades_to_evaluate_data = {
    'name': [
        'Coker_Naphtha',          # Esempio di componente da valorizzare
        'Pentane_mix',            # Esempio di componente da valorizzare
        'Light_Reformate',        # Esempio di componente da valorizzare
        'Heavy_Reformate',        # Esempio di componente da valorizzare
        'FCC_Naphtha_Light',      # Esempio di componente da valorizzare
        'Isomerate_Premium'       # Esempio di componente da valorizzare
    ],
    'delta_type': [
        'as_is',                  # Differenziale as_is
        'factor',                 # Differenziale factor
        'escalated',              # Differenziale escalated
        'as_is',                  # Differenziale as_is
        'factor',                 # Differenziale factor
        'escalated'               # Differenziale escalated
    ],
    'base_density_component': [
        None,                     # None per as_is
        None,                     # None per factor
        'Naphtha_Light_as_is',    # Componente base per escalated
        None,                     # None per as_is
        None,                     # None per factor
        'Naphtha_Heavy_factor'    # Componente base per escalated
    ],
    'density': [
        0.750,                    # Densità media
        0.630,                    # Densità bassa
        0.770,                    # Densità media-alta
        0.810,                    # Densità alta
        0.720,                    # Densità media
        0.680                     # Densità media-bassa
    ],
    'ron': [
        86.0,                     # RON medio
        89.0,                     # RON medio
        95.0,                     # RON alto
        102.0,                    # RON molto alto
        92.0,                     # RON alto
        88.0                      # RON medio
    ],
    'mon': [
        78.0,                     # MON medio
        85.0,                     # MON alto
        84.0,                     # MON medio-alto
        90.0,                     # MON alto
        80.0,                     # MON medio
        86.0                      # MON alto
    ],
    'rvp': [
        11.0,                     # RVP medio
        70.0,                     # RVP molto alto
        5.0,                      # RVP basso
        2.0,                      # RVP molto basso
        8.0,                      # RVP medio
        14.0                      # RVP alto
    ],
    'sulfur_ppm': [
        900.0,                    # Zolfo alto
        10.0,                     # Zolfo basso
        5.0,                      # Zolfo molto basso
        1.0,                      # Zolfo molto basso
        200.0,                    # Zolfo medio
        2.0                       # Zolfo molto basso
    ],
    'benzene': [
        0.30,                     # Benzene basso
        0.05,                     # Benzene molto basso
        0.20,                     # Benzene basso
        0.10,                     # Benzene molto basso
        0.50,                     # Benzene medio
        0.05                      # Benzene molto basso
    ],
    'aromatics': [
        15.0,                     # Aromatici medi
        2.0,                      # Aromatici bassi
        40.0,                     # Aromatici alti
        70.0,                     # Aromatici molto alti
        25.0,                     # Aromatici medi
        1.0                       # Aromatici molto bassi
    ],
    'olefins': [
        25.0,                     # Olefine alte
        5.0,                      # Olefine basse
        2.0,                      # Olefine molto basse
        1.0,                      # Olefine molto basse
        15.0,                     # Olefine medie
        0.5                       # Olefine molto basse
    ],
    'mtbe': [
        0.0,                      # MTBE nullo
        0.0,                      # MTBE nullo
        0.0,                      # MTBE nullo
        0.0,                      # MTBE nullo
        0.0,                      # MTBE nullo
        0.0                       # MTBE nullo
    ],
    't10': [
        80.0,                     # T10 medio
        45.0,                     # T10 basso
        70.0,                     # T10 medio
        100.0,                    # T10 alto
        60.0,                     # T10 medio
        35.0                      # T10 basso
    ],
    't50': [
        110.0,                    # T50 medio
        65.0,                     # T50 basso
        100.0,                    # T50 medio
        130.0,                    # T50 alto
        90.0,                     # T50 medio
        70.0                      # T50 basso
    ],
    'e70': [
        30.0,                     # E70 medio
        95.0,                     # E70 alto
        25.0,                     # E70 basso
        10.0,                     # E70 molto basso
        35.0,                     # E70 medio
        45.0                      # E70 medio-alto
    ],
    'oxy_wt': [
        0.0,                      # Ossigeno nullo
        0.0,                      # Ossigeno nullo
        0.0,                      # Ossigeno nullo
        0.0,                      # Ossigeno nullo
        0.0,                      # Ossigeno nullo
        0.0                       # Ossigeno nullo
    ],
    'is_ethanol': [
        False,                    # Non etanolo
        False,                    # Non etanolo
        False,                    # Non etanolo
        False,                    # Non etanolo
        False,                    # Non etanolo
        False                     # Non etanolo
    ]
}

# Crea il DataFrame
df_grades_to_evaluate = pd.DataFrame(grades_to_evaluate_data)

# Crea un file Excel con formattazione avanzata
def create_formatted_excel(df, file_path, sheet_name, title, description, color_theme='purple'):
    # Crea un nuovo workbook
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_name
    
    # Definisci gli stili
    if color_theme == 'blue':
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        title_fill = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
        alt_row_fill = PatternFill(start_color="EBF1F8", end_color="EBF1F8", fill_type="solid")
    elif color_theme == 'green':
        header_fill = PatternFill(start_color="375623", end_color="375623", fill_type="solid")
        title_fill = PatternFill(start_color="E2EFD9", end_color="E2EFD9", fill_type="solid")
        alt_row_fill = PatternFill(start_color="F2F9EC", end_color="F2F9EC", fill_type="solid")
    elif color_theme == 'red':
        header_fill = PatternFill(start_color="953735", end_color="953735", fill_type="solid")
        title_fill = PatternFill(start_color="F2DCDB", end_color="F2DCDB", fill_type="solid")
        alt_row_fill = PatternFill(start_color="FCF0EF", end_color="FCF0EF", fill_type="solid")
    else:  # purple
        header_fill = PatternFill(start_color="5F497A", end_color="5F497A", fill_type="solid")
        title_fill = PatternFill(start_color="E4DFEC", end_color="E4DFEC", fill_type="solid")
        alt_row_fill = PatternFill(start_color="F2EFF6", end_color="F2EFF6", fill_type="solid")
    
    header_font = Font(bold=True, color="FFFFFF", size=12)
    title_font = Font(bold=True, size=14)
    desc_font = Font(italic=True, size=11)
    
    # Aggiungi titolo e descrizione
    worksheet.merge_cells('A1:D1')
    title_cell = worksheet['A1']
    title_cell.value = title
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal='left', vertical='center')
    title_cell.fill = title_fill
    
    # Aggiungi descrizione
    worksheet.merge_cells('A2:D2')
    desc_cell = worksheet['A2']
    desc_cell.value = description
    desc_cell.font = desc_font
    desc_cell.alignment = Alignment(horizontal='left', vertical='center')
    
    # Aggiungi spazio
    worksheet.append([])
    
    # Aggiungi intestazioni
    headers = list(df.columns)
    worksheet.append(headers)
    
    # Formatta intestazioni
    for cell in worksheet[4]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    
    # Aggiungi dati
    for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
        worksheet.append(row)
        # Formatta righe alternate
        if r_idx % 2 == 0:
            for cell in worksheet[r_idx + 5]:
                cell.fill = alt_row_fill
    
    # Imposta larghezza colonne
    for i, column in enumerate(df.columns):
        col_letter = get_column_letter(i + 1)
        # Imposta larghezza in base alla lunghezza massima dei valori
        max_length = max(
            len(str(column)),
            df[column].astype(str).map(len).max()
        )
        adjusted_width = max_length + 2
        worksheet.column_dimensions[col_letter].width = adjusted_width
    
    # Aggiungi bordi a tutte le celle
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
        for cell in row:
            cell.border = thin_border
    
    # Aggiungi filtro alle intestazioni
    worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
    
    # Blocca le intestazioni
    worksheet.freeze_panes = "A5"
    
    # Salva il file
    workbook.save(file_path)

# Crea il file Excel formattato per i grades da valorizzare
grades_to_evaluate_file_path = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/grades_to_evaluate_example.xlsx'
grades_to_evaluate_title = 'Grades da Valorizzare'
grades_to_evaluate_description = 'Questo foglio contiene esempi di grades da valorizzare con diverse proprietà'

create_formatted_excel(
    df_grades_to_evaluate, 
    grades_to_evaluate_file_path, 
    'Grades_da_Valorizzare', 
    grades_to_evaluate_title, 
    grades_to_evaluate_description, 
    'purple'
)

print(f"File Excel dei grades da valorizzare creato: {grades_to_evaluate_file_path}")
