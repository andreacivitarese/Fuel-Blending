import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter
import yaml

# Crea il DataFrame per gli additivi
additives_data = {
    'name': [
        'Octane_Booster',         # Additivo per aumentare l'ottano
        'Antiknock',              # Additivo antidetonante
        'Detergent',              # Additivo detergente
        'Antioxidant',            # Additivo antiossidante
        'Corrosion_Inhibitor',    # Inibitore di corrosione
        'Lubricity_Enhancer',     # Miglioratore di lubrificazione
        'Deposit_Control',        # Controllo dei depositi
        'Cetane_Improver',        # Miglioratore di cetano
        'Flow_Improver',          # Miglioratore di flusso
        'Demulsifier'             # Demulsionante
    ],
    'cost_usd_per_litre': [
        3.50,                     # Costo medio-alto
        4.20,                     # Costo alto
        2.80,                     # Costo medio
        3.00,                     # Costo medio
        2.50,                     # Costo medio-basso
        3.75,                     # Costo medio-alto
        2.90,                     # Costo medio
        4.50,                     # Costo molto alto
        3.25,                     # Costo medio
        2.60                      # Costo medio-basso
    ],
    'density_add': [
        0.85,                     # Densità media-alta
        0.88,                     # Densità alta
        0.82,                     # Densità media
        0.80,                     # Densità media-bassa
        0.83,                     # Densità media
        0.86,                     # Densità media-alta
        0.84,                     # Densità media
        0.89,                     # Densità alta
        0.81,                     # Densità media-bassa
        0.82                      # Densità media
    ]
}

# Crea il DataFrame
df_additives = pd.DataFrame(additives_data)

# Crea un file Excel con formattazione avanzata
def create_formatted_excel(df, file_path, sheet_name, title, description, color_theme='red'):
    # Crea un nuovo workbook
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.title = sheet_name
    
    # Definisci gli stili
    if color_theme == 'blue':
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        title_fill = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
        alt_row_fill = PatternFill(start_color="EBF1F8", end_color="EBF1F8", fill_type="solid")
    elif color_theme == 'green':
        header_fill = PatternFill(start_color="375623", end_color="375623", fill_type="solid")
        title_fill = PatternFill(start_color="E2EFD9", end_color="E2EFD9", fill_type="solid")
        alt_row_fill = PatternFill(start_color="F2F9EC", end_color="F2F9EC", fill_type="solid")
    else:  # red
        header_fill = PatternFill(start_color="953735", end_color="953735", fill_type="solid")
        title_fill = PatternFill(start_color="F2DCDB", end_color="F2DCDB", fill_type="solid")
        alt_row_fill = PatternFill(start_color="FCF0EF", end_color="FCF0EF", fill_type="solid")
    
    header_font = Font(bold=True, color="FFFFFF", size=12)
    title_font = Font(bold=True, size=14)
    desc_font = Font(italic=True, size=11)
    
    # Aggiungi titolo e descrizione
    worksheet.merge_cells('A1:D1')
    title_cell = worksheet['A1']
    title_cell.value = title
    title_cell.font = title_font
    title_cell.alignment = Alignment(horizontal='left', vertical='center')
    title_cell.fill = title_fill
    
    # Aggiungi descrizione
    worksheet.merge_cells('A2:D2')
    desc_cell = worksheet['A2']
    desc_cell.value = description
    desc_cell.font = desc_font
    desc_cell.alignment = Alignment(horizontal='left', vertical='center')
    
    # Aggiungi spazio
    worksheet.append([])
    
    # Aggiungi intestazioni
    headers = list(df.columns)
    worksheet.append(headers)
    
    # Formatta intestazioni
    for cell in worksheet[4]:
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
    
    # Aggiungi dati
    for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
        worksheet.append(row)
        # Formatta righe alternate
        if r_idx % 2 == 0:
            for cell in worksheet[r_idx + 5]:
                cell.fill = alt_row_fill
    
    # Imposta larghezza colonne
    for i, column in enumerate(df.columns):
        col_letter = get_column_letter(i + 1)
        # Imposta larghezza in base alla lunghezza massima dei valori
        max_length = max(
            len(str(column)),
            df[column].astype(str).map(len).max()
        )
        adjusted_width = max_length + 2
        worksheet.column_dimensions[col_letter].width = adjusted_width
    
    # Aggiungi bordi a tutte le celle
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )
    
    for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
        for cell in row:
            cell.border = thin_border
    
    # Aggiungi filtro alle intestazioni
    worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
    
    # Blocca le intestazioni
    worksheet.freeze_panes = "A5"
    
    # Salva il file
    workbook.save(file_path)

# Crea il file Excel formattato per gli additivi
additives_file_path = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/additives_example.xlsx'
additives_title = 'Additivi per Fuel Blending'
additives_description = 'Questo foglio contiene esempi di additivi con diverse proprietà e costi'

create_formatted_excel(
    df_additives, 
    additives_file_path, 
    'Additivi', 
    additives_title, 
    additives_description, 
    'red'
)

# Crea anche un file YAML per riferimento
additives_yaml = {}
for _, row in df_additives.iterrows():
    additives_yaml[row['name']] = {
        'cost_usd_per_litre': row['cost_usd_per_litre'],
        'density_add': row['density_add']
    }

# Salva il file YAML
additives_yaml_path = '/home/ubuntu/fuel_blending_ottimizzato/excel_examples/additives_example.yaml'
with open(additives_yaml_path, 'w') as f:
    yaml.dump(additives_yaml, f, default_flow_style=False)

print(f"File Excel degli additivi creato: {additives_file_path}")
print(f"File YAML degli additivi creato: {additives_yaml_path}")
