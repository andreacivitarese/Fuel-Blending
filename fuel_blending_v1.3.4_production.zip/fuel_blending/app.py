"""
Punto di ingresso dell'applicazione.
"""

import argparse
import logging
from pathlib import Path
from dotenv import load_dotenv

from fuel_blending.config import ConfigManager
from fuel_blending.utils import setup_logging
from fuel_blending.cli import run_cli

def main():
    """Punto di ingresso dell'applicazione."""
    # Caricamento delle variabili d'ambiente
    load_dotenv()
    
    # Parsing degli argomenti
    parser = argparse.ArgumentParser(description="Fuel Blending CLI")
    parser.add_argument("--config", type=Path, help="Percorso della configurazione personalizzata")
    parser.add_argument("--env", choices=["development", "production"], default="development", help="Ambiente")
    
    args, remaining_args = parser.parse_known_args()
    
    # Caricamento della configurazione
    config_manager = ConfigManager()
    config = config_manager.load(args.env, args.config)
    
    # Creazione delle directory necessarie
    config_manager.ensure_directories()
    
    # Configurazione del logging
    logger = setup_logging(level=config.logging.level, log_file=Path(config.logging.file) if config.logging.file else None)
    
    # Esecuzione della CLI
    run_cli(remaining_args, config, logger)

if __name__ == "__main__":
    main()
