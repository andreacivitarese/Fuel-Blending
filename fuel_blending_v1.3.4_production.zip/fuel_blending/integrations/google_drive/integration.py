"""
Aggiornamento del modulo di integrazione con Google Drive.

Questo modulo aggiorna l'integrazione con Google Drive per supportare:
1. Caricamento dei risultati dell'ottimizzazione su Google Drive
2. Caricamento dei grades da valutare da Google Drive
3. Salvataggio dei risultati della valutazione su Google Drive
"""

import os
import tempfile
from datetime import datetime
from googleapiclient.http import MediaFileUpload

from .auth import GoogleAuthManager
from .drive import GoogleDriveManager
from .excel import ExcelReader
from .grades_loader import GradesToEvaluateLoader
from .output import OptimizationResultsExporter, GradesToEvaluateExporter

class GoogleDriveData:
    """
    Classe per rappresentare i dati caricati da Google Drive.
    """
    
    def __init__(self, components=None, grades=None, additives=None, candidates=None):
        """
        Inizializza i dati.
        
        Args:
            components: Lista dei componenti
            grades: Lista dei grade
            additives: Dizionario degli additivi
            candidates: Lista dei candidati da valutare
        """
        self.components = components or []
        self.grades = grades or []
        self.additives = additives or {}
        self.candidates = candidates or []

class GoogleDriveIntegration:
    """
    Classe per l'integrazione con Google Drive.
    """
    
    def __init__(self, credentials_file=None, token_file=None):
        """
        Inizializza l'integrazione con Google Drive.
        
        Args:
            credentials_file: Percorso del file delle credenziali
            token_file: Percorso del file del token
        """
        self.credentials_file = credentials_file
        self.token_file = token_file
        self.auth_manager = GoogleAuthManager(credentials_file, token_file)
        self.drive_manager = GoogleDriveManager(self.auth_manager)
        self.excel_reader = ExcelReader(self.drive_manager)
        self.grades_loader = GradesToEvaluateLoader(self)
        self.optimization_exporter = OptimizationResultsExporter(self)
        self.evaluation_exporter = GradesToEvaluateExporter(self)
    
    def setup(self):
        """
        Configura l'integrazione con Google Drive.
        """
        self.auth_manager.authenticate()
        self.drive_manager.connect()
    
    def load_data(self, components_file_id=None, grades_file_id=None, additives_file_id=None, candidates_file_id=None, 
                  components_sheet=0, grades_sheet=0, additives_sheet=0, candidates_sheet=0):
        """
        Carica i dati da Google Drive.
        
        Args:
            components_file_id: ID del file dei componenti
            grades_file_id: ID del file dei grade
            additives_file_id: ID del file degli additivi
            candidates_file_id: ID del file dei candidati da valutare
            components_sheet: Indice del foglio dei componenti
            grades_sheet: Indice del foglio dei grade
            additives_sheet: Indice del foglio degli additivi
            candidates_sheet: Indice del foglio dei candidati
            
        Returns:
            Oggetto GoogleDriveData con i dati caricati
        """
        # Assicurati che il servizio sia connesso
        if not self.drive_manager.service:
            self.setup()
        
        # Carica i dati
        components = []
        grades = []
        additives = {}
        candidates = []
        
        if components_file_id:
            components = self.excel_reader.read_components(components_file_id, components_sheet)
        
        if grades_file_id:
            grades = self.excel_reader.read_grades(grades_file_id, grades_sheet)
        
        if additives_file_id:
            additives = self.excel_reader.read_additives(additives_file_id, additives_sheet)
        
        if candidates_file_id:
            candidates = self.grades_loader.load_grades_to_evaluate_from_google_drive(candidates_file_id)
        
        return GoogleDriveData(components, grades, additives, candidates)
    
    def load_data_interactive(self):
        """
        Carica i dati da Google Drive in modo interattivo.
        
        Returns:
            Oggetto GoogleDriveData con i dati caricati
        """
        # Assicurati che il servizio sia connesso
        if not self.drive_manager.service:
            self.setup()
        
        # Ottieni la lista dei file Excel su Google Drive
        files = self.list_files(mime_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        
        # Mostra la lista dei file all'utente
        print("\nFile Excel disponibili su Google Drive:")
        for i, file in enumerate(files):
            print(f"{i+1}. {file['name']} (ID: {file['id']})")
        
        # Chiedi all'utente di selezionare i file
        components_file_id = self._select_file(files, "componenti")
        grades_file_id = self._select_file(files, "grade")
        additives_file_id = self._select_file(files, "additivi")
        candidates_file_id = self._select_file(files, "candidati da valutare", optional=True)
        
        # Carica i dati
        return self.load_data(components_file_id, grades_file_id, additives_file_id, candidates_file_id)
    
    def _select_file(self, files, file_type, optional=False):
        """
        Chiede all'utente di selezionare un file.
        
        Args:
            files: Lista dei file
            file_type: Tipo di file
            optional: Se True, la selezione è opzionale
            
        Returns:
            ID del file selezionato o None se opzionale e non selezionato
        """
        prompt = f"\nSeleziona il numero del file dei {file_type} (0 per saltare): " if optional else f"\nSeleziona il numero del file dei {file_type}: "
        selection = input(prompt)
        
        try:
            index = int(selection) - 1
            
            if optional and (selection == "0" or index < 0):
                print(f"Selezione del file dei {file_type} saltata")
                return None
            
            if index < 0 or index >= len(files):
                raise ValueError("Selezione non valida")
            
            selected_file = files[index]
            print(f"Hai selezionato: {selected_file['name']}")
            
            return selected_file['id']
            
        except (ValueError, IndexError) as e:
            print(f"Errore nella selezione: {str(e)}")
            return None
    
    def list_files(self, mime_type=None, query=None):
        """
        Elenca i file su Google Drive.
        
        Args:
            mime_type: Tipo MIME dei file da elencare
            query: Query di ricerca
            
        Returns:
            Lista dei file
        """
        # Assicurati che il servizio sia connesso
        if not self.drive_manager.service:
            self.setup()
        
        # Costruisci la query
        q = []
        
        if mime_type:
            q.append(f"mimeType='{mime_type}'")
        
        if query:
            q.append(query)
        
        # Esegui la query
        query_string = " and ".join(q) if q else None
        
        return self.drive_manager.list_files(query_string)
    
    def download_file(self, file_id):
        """
        Scarica un file da Google Drive.
        
        Args:
            file_id: ID del file
            
        Returns:
            Percorso del file scaricato
        """
        # Assicurati che il servizio sia connesso
        if not self.drive_manager.service:
            self.setup()
        
        return self.drive_manager.download_file(file_id)
    
    def upload_file(self, local_path, file_name, folder_id=None, mime_type=None):
        """
        Carica un file su Google Drive.
        
        Args:
            local_path: Percorso del file locale
            file_name: Nome del file su Google Drive
            folder_id: ID della cartella su Google Drive (opzionale)
            mime_type: Tipo MIME del file (opzionale)
            
        Returns:
            ID del file caricato
        """
        # Assicurati che il servizio sia connesso
        if not self.drive_manager.service:
            self.setup()
        
        # Determina il tipo MIME
        if mime_type is None:
            file_ext = os.path.splitext(local_path)[1].lower()
            if file_ext == '.xlsx':
                mime_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            elif file_ext == '.xls':
                mime_type = 'application/vnd.ms-excel'
            elif file_ext == '.csv':
                mime_type = 'text/csv'
            elif file_ext == '.json':
                mime_type = 'application/json'
            elif file_ext == '.yaml' or file_ext == '.yml':
                mime_type = 'application/x-yaml'
            else:
                mime_type = 'application/octet-stream'
        
        # Crea i metadati del file
        file_metadata = {
            'name': file_name
        }
        
        if folder_id:
            file_metadata['parents'] = [folder_id]
        
        # Crea l'oggetto media
        media = MediaFileUpload(local_path, mimetype=mime_type, resumable=True)
        
        # Carica il file
        file = self.drive_manager.service.files().create(
            body=file_metadata,
            media_body=media,
            fields='id'
        ).execute()
        
        return file.get('id')
    
    def upload_optimization_results(self, results, components, grades, folder_id=None, file_name=None):
        """
        Carica i risultati dell'ottimizzazione su Google Drive.
        
        Args:
            results: Risultati dell'ottimizzazione
            components: Lista dei componenti
            grades: Lista dei grade
            folder_id: ID della cartella su Google Drive (opzionale)
            file_name: Nome del file su Google Drive (opzionale)
            
        Returns:
            ID del file caricato
        """
        return self.optimization_exporter.upload_results_to_google_drive(
            results, components, grades, folder_id, file_name
        )
    
    def upload_evaluation_results(self, results, candidates, grades, folder_id=None, file_name=None):
        """
        Carica i risultati della valutazione su Google Drive.
        
        Args:
            results: Risultati della valutazione
            candidates: Lista dei candidati
            grades: Lista dei grade
            folder_id: ID della cartella su Google Drive (opzionale)
            file_name: Nome del file su Google Drive (opzionale)
            
        Returns:
            ID del file caricato
        """
        return self.evaluation_exporter.upload_results_to_google_drive(
            results, candidates, grades, folder_id, file_name
        )
    
    def load_grades_to_evaluate(self, file_id=None, interactive=False):
        """
        Carica i grades da valutare da Google Drive.
        
        Args:
            file_id: ID del file su Google Drive
            interactive: Se True, seleziona il file in modo interattivo
            
        Returns:
            Lista di componenti candidati
        """
        # Assicurati che il servizio sia connesso
        if not self.drive_manager.service:
            self.setup()
        
        if interactive:
            return self.grades_loader.select_grades_to_evaluate_interactively()
        elif file_id:
            return self.grades_loader.load_grades_to_evaluate_from_google_drive(file_id)
        else:
            raise ValueError("Devi specificare file_id o impostare interactive=True")
