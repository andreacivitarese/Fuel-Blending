"""
Modulo per l'output dell'ottimizzazione su Google Drive.

Questo modulo implementa le funzionalità per salvare i risultati dell'ottimizzazione
direttamente su Google Drive.
"""

import pandas as pd
import numpy as np
import json
import os
import tempfile
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.utils import get_column_letter

class OptimizationResultsExporter:
    """
    Classe per esportare i risultati dell'ottimizzazione in vari formati,
    incluso Excel su Google Drive.
    """
    
    def __init__(self, google_drive_integration=None):
        """
        Inizializza l'esportatore dei risultati.
        
        Args:
            google_drive_integration: Istanza di GoogleDriveIntegration per l'upload su Google Drive
        """
        self.google_drive_integration = google_drive_integration
    
    def format_excel_workbook(self, workbook, data_frames, sheet_names, titles, descriptions):
        """
        Formatta un workbook Excel con stili professionali.
        
        Args:
            workbook: Workbook di openpyxl
            data_frames: Lista di DataFrame da aggiungere
            sheet_names: Lista di nomi dei fogli
            titles: Lista di titoli per i fogli
            descriptions: Lista di descrizioni per i fogli
            
        Returns:
            Workbook formattato
        """
        # Rimuovi il foglio predefinito
        if 'Sheet' in workbook.sheetnames:
            workbook.remove(workbook['Sheet'])
        
        # Definisci gli stili
        header_fill = PatternFill(start_color="1F4E78", end_color="1F4E78", fill_type="solid")
        title_fill = PatternFill(start_color="DCE6F1", end_color="DCE6F1", fill_type="solid")
        alt_row_fill = PatternFill(start_color="EBF1F8", end_color="EBF1F8", fill_type="solid")
        
        header_font = Font(bold=True, color="FFFFFF", size=12)
        title_font = Font(bold=True, size=14)
        desc_font = Font(italic=True, size=11)
        
        # Aggiungi ogni DataFrame come foglio
        for i, (df, sheet_name, title, description) in enumerate(zip(data_frames, sheet_names, titles, descriptions)):
            # Crea un nuovo foglio
            worksheet = workbook.create_sheet(sheet_name)
            
            # Aggiungi titolo e descrizione
            worksheet.merge_cells('A1:D1')
            title_cell = worksheet['A1']
            title_cell.value = title
            title_cell.font = title_font
            title_cell.alignment = Alignment(horizontal='left', vertical='center')
            title_cell.fill = title_fill
            
            # Aggiungi descrizione
            worksheet.merge_cells('A2:D2')
            desc_cell = worksheet['A2']
            desc_cell.value = description
            desc_cell.font = desc_font
            desc_cell.alignment = Alignment(horizontal='left', vertical='center')
            
            # Aggiungi spazio
            worksheet.append([])
            
            # Aggiungi intestazioni
            headers = list(df.columns)
            worksheet.append(headers)
            
            # Formatta intestazioni
            for cell in worksheet[4]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            
            # Aggiungi dati
            for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
                worksheet.append(row)
                # Formatta righe alternate
                if r_idx % 2 == 0:
                    for cell in worksheet[r_idx + 5]:
                        cell.fill = alt_row_fill
            
            # Imposta larghezza colonne
            for i, column in enumerate(df.columns):
                col_letter = get_column_letter(i + 1)
                # Imposta larghezza in base alla lunghezza massima dei valori
                max_length = max(
                    len(str(column)),
                    df[column].astype(str).map(len).max() if len(df) > 0 else 0
                )
                adjusted_width = max_length + 2
                worksheet.column_dimensions[col_letter].width = adjusted_width
            
            # Aggiungi bordi a tutte le celle
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
                for cell in row:
                    cell.border = thin_border
            
            # Aggiungi filtro alle intestazioni
            worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
            
            # Blocca le intestazioni
            worksheet.freeze_panes = "A5"
        
        return workbook
    
    def create_optimization_results_excel(self, results, components, grades, output_path=None):
        """
        Crea un file Excel con i risultati dell'ottimizzazione.
        
        Args:
            results: Risultati dell'ottimizzazione
            components: Lista dei componenti
            grades: Lista dei grade
            output_path: Percorso del file di output (opzionale)
            
        Returns:
            Percorso del file Excel creato
        """
        # Crea un workbook
        workbook = Workbook()
        
        # Prepara i DataFrame per i risultati
        df_summary = self._create_summary_dataframe(results, grades)
        df_blend = self._create_blend_dataframe(results, components, grades)
        df_properties = self._create_properties_dataframe(results, grades)
        df_economics = self._create_economics_dataframe(results, components, grades)
        
        # Formatta il workbook
        workbook = self.format_excel_workbook(
            workbook,
            [df_summary, df_blend, df_properties, df_economics],
            ['Riepilogo', 'Blend', 'Proprietà', 'Economici'],
            [
                'Riepilogo Ottimizzazione',
                'Composizione Blend',
                'Proprietà dei Grade',
                'Analisi Economica'
            ],
            [
                'Riepilogo dei risultati dell\'ottimizzazione',
                'Percentuali di blend per ogni componente e grade',
                'Proprietà calcolate per ogni grade',
                'Analisi economica dei componenti e grade'
            ]
        )
        
        # Se non è specificato un percorso di output, crea un file temporaneo
        if output_path is None:
            temp_dir = tempfile.gettempdir()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(temp_dir, f"optimization_results_{timestamp}.xlsx")
        
        # Salva il workbook
        workbook.save(output_path)
        
        return output_path
    
    def upload_results_to_google_drive(self, results, components, grades, folder_id=None, file_name=None):
        """
        Carica i risultati dell'ottimizzazione su Google Drive.
        
        Args:
            results: Risultati dell'ottimizzazione
            components: Lista dei componenti
            grades: Lista dei grade
            folder_id: ID della cartella su Google Drive (opzionale)
            file_name: Nome del file su Google Drive (opzionale)
            
        Returns:
            ID del file caricato su Google Drive
        """
        if self.google_drive_integration is None:
            raise ValueError("GoogleDriveIntegration non inizializzato")
        
        # Crea il file Excel localmente
        local_path = self.create_optimization_results_excel(results, components, grades)
        
        # Se non è specificato un nome di file, usa un nome predefinito
        if file_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"Risultati_Ottimizzazione_{timestamp}.xlsx"
        
        # Carica il file su Google Drive
        file_id = self.google_drive_integration.upload_file(
            local_path,
            file_name,
            folder_id,
            mime_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
        # Elimina il file locale temporaneo
        os.remove(local_path)
        
        return file_id
    
    def _create_summary_dataframe(self, results, grades):
        """
        Crea un DataFrame di riepilogo dei risultati dell'ottimizzazione.
        
        Args:
            results: Risultati dell'ottimizzazione
            grades: Lista dei grade
            
        Returns:
            DataFrame di riepilogo
        """
        summary_data = []
        
        for grade_name, grade_result in results.items():
            if grade_result.get('success', False):
                summary_data.append({
                    'Grade': grade_name,
                    'Stato': 'Ottimizzato',
                    'Costo (USD/t)': grade_result.get('cost', 0),
                    'Massa (t)': next((g.target_mass for g in grades if g.name == grade_name), 0),
                    'RON': grade_result.get('properties', {}).get('RON', 0),
                    'MON': grade_result.get('properties', {}).get('MON', 0),
                    'RVP': grade_result.get('properties', {}).get('RVP', 0),
                    'Densità': grade_result.get('properties', {}).get('density', 0)
                })
            else:
                summary_data.append({
                    'Grade': grade_name,
                    'Stato': 'Fallito',
                    'Costo (USD/t)': None,
                    'Massa (t)': next((g.target_mass for g in grades if g.name == grade_name), 0),
                    'RON': None,
                    'MON': None,
                    'RVP': None,
                    'Densità': None
                })
        
        return pd.DataFrame(summary_data)
    
    def _create_blend_dataframe(self, results, components, grades):
        """
        Crea un DataFrame con le percentuali di blend.
        
        Args:
            results: Risultati dell'ottimizzazione
            components: Lista dei componenti
            grades: Lista dei grade
            
        Returns:
            DataFrame con le percentuali di blend
        """
        # Crea una lista di tutti i nomi dei componenti
        component_names = [comp.name for comp in components]
        
        # Crea una lista di tutti i nomi dei grade
        grade_names = [grade.name for grade in grades]
        
        # Crea un DataFrame vuoto con i componenti come indice e i grade come colonne
        blend_data = pd.DataFrame(index=component_names, columns=grade_names)
        
        # Riempi il DataFrame con le percentuali di blend
        for grade_name, grade_result in results.items():
            if grade_result.get('success', False) and 'blend' in grade_result:
                for comp_name, percentage in grade_result['blend'].items():
                    blend_data.loc[comp_name, grade_name] = percentage * 100  # Converti in percentuale
        
        # Resetta l'indice per avere i nomi dei componenti come colonna
        blend_data = blend_data.reset_index().rename(columns={'index': 'Componente'})
        
        return blend_data
    
    def _create_properties_dataframe(self, results, grades):
        """
        Crea un DataFrame con le proprietà dei grade.
        
        Args:
            results: Risultati dell'ottimizzazione
            grades: Lista dei grade
            
        Returns:
            DataFrame con le proprietà dei grade
        """
        properties_data = []
        
        for grade_name, grade_result in results.items():
            if grade_result.get('success', False) and 'properties' in grade_result:
                properties = grade_result['properties']
                
                # Trova il grade corrispondente
                grade = next((g for g in grades if g.name == grade_name), None)
                
                if grade:
                    # Ottieni le specifiche del grade
                    specs = grade.specs
                    
                    # Per ogni proprietà, aggiungi una riga al DataFrame
                    for prop_name, prop_value in properties.items():
                        # Ottieni i limiti della specifica
                        spec_min, spec_max = specs.get(prop_name, (None, None))
                        
                        properties_data.append({
                            'Grade': grade_name,
                            'Proprietà': prop_name,
                            'Valore': prop_value,
                            'Min': spec_min,
                            'Max': spec_max,
                            'Stato': self._check_property_status(prop_value, spec_min, spec_max)
                        })
        
        return pd.DataFrame(properties_data)
    
    def _check_property_status(self, value, min_val, max_val):
        """
        Verifica lo stato di una proprietà rispetto ai limiti.
        
        Args:
            value: Valore della proprietà
            min_val: Valore minimo
            max_val: Valore massimo
            
        Returns:
            Stato della proprietà
        """
        if min_val is not None and value < min_val:
            return 'Sotto limite'
        elif max_val is not None and value > max_val:
            return 'Sopra limite'
        else:
            return 'OK'
    
    def _create_economics_dataframe(self, results, components, grades):
        """
        Crea un DataFrame con l'analisi economica.
        
        Args:
            results: Risultati dell'ottimizzazione
            components: Lista dei componenti
            grades: Lista dei grade
            
        Returns:
            DataFrame con l'analisi economica
        """
        economics_data = []
        
        for grade_name, grade_result in results.items():
            if grade_result.get('success', False) and 'blend' in grade_result and 'cost' in grade_result:
                # Costo totale del grade
                total_cost = grade_result['cost']
                
                # Massa target del grade
                grade_mass = next((g.target_mass for g in grades if g.name == grade_name), 0)
                
                # Per ogni componente nel blend
                for comp_name, percentage in grade_result['blend'].items():
                    # Trova il componente corrispondente
                    component = next((c for c in components if c.name == comp_name), None)
                    
                    if component:
                        # Calcola la massa del componente
                        comp_mass = percentage * grade_mass
                        
                        # Calcola il costo del componente
                        comp_cost = self._calculate_component_cost(component, grade_result.get('flat_price', 0))
                        
                        # Calcola il valore del componente
                        comp_value = comp_cost * comp_mass
                        
                        economics_data.append({
                            'Grade': grade_name,
                            'Componente': comp_name,
                            'Percentuale (%)': percentage * 100,
                            'Massa (t)': comp_mass,
                            'Costo (USD/t)': comp_cost,
                            'Valore (USD)': comp_value
                        })
                
                # Aggiungi una riga per il totale del grade
                economics_data.append({
                    'Grade': grade_name,
                    'Componente': 'TOTALE',
                    'Percentuale (%)': 100,
                    'Massa (t)': grade_mass,
                    'Costo (USD/t)': total_cost,
                    'Valore (USD)': total_cost * grade_mass
                })
        
        return pd.DataFrame(economics_data)
    
    def _calculate_component_cost(self, component, flat_price):
        """
        Calcola il costo di un componente.
        
        Args:
            component: Componente
            flat_price: Prezzo flat
            
        Returns:
            Costo del componente
        """
        if component.delta_type == 'as_is':
            return flat_price + (component.delta_value or 0)
        elif component.delta_type == 'factor':
            return flat_price * (component.multiplier or 1)
        elif component.delta_type == 'escalated':
            # Per escalated, il calcolo è più complesso e dipende dalla densità
            # Qui si assume un calcolo semplificato
            return flat_price
        else:
            return flat_price


class GradesToEvaluateExporter:
    """
    Classe per esportare i risultati della valutazione dei grades.
    """
    
    def __init__(self, google_drive_integration=None):
        """
        Inizializza l'esportatore dei risultati.
        
        Args:
            google_drive_integration: Istanza di GoogleDriveIntegration per l'upload su Google Drive
        """
        self.google_drive_integration = google_drive_integration
    
    def format_excel_workbook(self, workbook, data_frames, sheet_names, titles, descriptions):
        """
        Formatta un workbook Excel con stili professionali.
        
        Args:
            workbook: Workbook di openpyxl
            data_frames: Lista di DataFrame da aggiungere
            sheet_names: Lista di nomi dei fogli
            titles: Lista di titoli per i fogli
            descriptions: Lista di descrizioni per i fogli
            
        Returns:
            Workbook formattato
        """
        # Rimuovi il foglio predefinito
        if 'Sheet' in workbook.sheetnames:
            workbook.remove(workbook['Sheet'])
        
        # Definisci gli stili
        header_fill = PatternFill(start_color="5F497A", end_color="5F497A", fill_type="solid")
        title_fill = PatternFill(start_color="E4DFEC", end_color="E4DFEC", fill_type="solid")
        alt_row_fill = PatternFill(start_color="F2EFF6", end_color="F2EFF6", fill_type="solid")
        
        header_font = Font(bold=True, color="FFFFFF", size=12)
        title_font = Font(bold=True, size=14)
        desc_font = Font(italic=True, size=11)
        
        # Aggiungi ogni DataFrame come foglio
        for i, (df, sheet_name, title, description) in enumerate(zip(data_frames, sheet_names, titles, descriptions)):
            # Crea un nuovo foglio
            worksheet = workbook.create_sheet(sheet_name)
            
            # Aggiungi titolo e descrizione
            worksheet.merge_cells('A1:D1')
            title_cell = worksheet['A1']
            title_cell.value = title
            title_cell.font = title_font
            title_cell.alignment = Alignment(horizontal='left', vertical='center')
            title_cell.fill = title_fill
            
            # Aggiungi descrizione
            worksheet.merge_cells('A2:D2')
            desc_cell = worksheet['A2']
            desc_cell.value = description
            desc_cell.font = desc_font
            desc_cell.alignment = Alignment(horizontal='left', vertical='center')
            
            # Aggiungi spazio
            worksheet.append([])
            
            # Aggiungi intestazioni
            headers = list(df.columns)
            worksheet.append(headers)
            
            # Formatta intestazioni
            for cell in worksheet[4]:
                cell.font = header_font
                cell.fill = header_fill
                cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
            
            # Aggiungi dati
            for r_idx, row in enumerate(dataframe_to_rows(df, index=False, header=False)):
                worksheet.append(row)
                # Formatta righe alternate
                if r_idx % 2 == 0:
                    for cell in worksheet[r_idx + 5]:
                        cell.fill = alt_row_fill
            
            # Imposta larghezza colonne
            for i, column in enumerate(df.columns):
                col_letter = get_column_letter(i + 1)
                # Imposta larghezza in base alla lunghezza massima dei valori
                max_length = max(
                    len(str(column)),
                    df[column].astype(str).map(len).max() if len(df) > 0 else 0
                )
                adjusted_width = max_length + 2
                worksheet.column_dimensions[col_letter].width = adjusted_width
            
            # Aggiungi bordi a tutte le celle
            thin_border = Border(
                left=Side(style='thin'),
                right=Side(style='thin'),
                top=Side(style='thin'),
                bottom=Side(style='thin')
            )
            
            for row in worksheet.iter_rows(min_row=4, max_row=worksheet.max_row, min_col=1, max_col=len(df.columns)):
                for cell in row:
                    cell.border = thin_border
            
            # Aggiungi filtro alle intestazioni
            worksheet.auto_filter.ref = f"A4:{get_column_letter(len(df.columns))}{4}"
            
            # Blocca le intestazioni
            worksheet.freeze_panes = "A5"
        
        return workbook
    
    def create_evaluation_results_excel(self, results, candidates, grades, output_path=None):
        """
        Crea un file Excel con i risultati della valutazione dei grades.
        
        Args:
            results: Risultati della valutazione
            candidates: Lista dei candidati
            grades: Lista dei grade
            output_path: Percorso del file di output (opzionale)
            
        Returns:
            Percorso del file Excel creato
        """
        # Crea un workbook
        workbook = Workbook()
        
        # Prepara i DataFrame per i risultati
        df_summary = self._create_summary_dataframe(results, candidates, grades)
        df_details = self._create_details_dataframe(results, candidates, grades)
        
        # Formatta il workbook
        workbook = self.format_excel_workbook(
            workbook,
            [df_summary, df_details],
            ['Riepilogo', 'Dettagli'],
            [
                'Riepilogo Valutazione',
                'Dettagli Valutazione'
            ],
            [
                'Riepilogo dei risultati della valutazione dei grades',
                'Dettagli dei risultati della valutazione dei grades'
            ]
        )
        
        # Se non è specificato un percorso di output, crea un file temporaneo
        if output_path is None:
            temp_dir = tempfile.gettempdir()
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = os.path.join(temp_dir, f"evaluation_results_{timestamp}.xlsx")
        
        # Salva il workbook
        workbook.save(output_path)
        
        return output_path
    
    def upload_results_to_google_drive(self, results, candidates, grades, folder_id=None, file_name=None):
        """
        Carica i risultati della valutazione su Google Drive.
        
        Args:
            results: Risultati della valutazione
            candidates: Lista dei candidati
            grades: Lista dei grade
            folder_id: ID della cartella su Google Drive (opzionale)
            file_name: Nome del file su Google Drive (opzionale)
            
        Returns:
            ID del file caricato su Google Drive
        """
        if self.google_drive_integration is None:
            raise ValueError("GoogleDriveIntegration non inizializzato")
        
        # Crea il file Excel localmente
        local_path = self.create_evaluation_results_excel(results, candidates, grades)
        
        # Se non è specificato un nome di file, usa un nome predefinito
        if file_name is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            file_name = f"Risultati_Valutazione_{timestamp}.xlsx"
        
        # Carica il file su Google Drive
        file_id = self.google_drive_integration.upload_file(
            local_path,
            file_name,
            folder_id,
            mime_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        )
        
        # Elimina il file locale temporaneo
        os.remove(local_path)
        
        return file_id
    
    def _create_summary_dataframe(self, results, candidates, grades):
        """
        Crea un DataFrame di riepilogo dei risultati della valutazione.
        
        Args:
            results: Risultati della valutazione
            candidates: Lista dei candidati
            grades: Lista dei grade
            
        Returns:
            DataFrame di riepilogo
        """
        summary_data = []
        
        for candidate_name, candidate_results in results.items():
            for grade_name, grade_result in candidate_results.items():
                summary_data.append({
                    'Candidato': candidate_name,
                    'Grade': grade_name,
                    'MV_usd_t': grade_result.get('MV_usd_t', 0),
                    'delta_neut': grade_result.get('delta_neut', None),
                    'mult_neut': grade_result.get('mult_neut', None)
                })
        
        return pd.DataFrame(summary_data)
    
    def _create_details_dataframe(self, results, candidates, grades):
        """
        Crea un DataFrame con i dettagli dei risultati della valutazione.
        
        Args:
            results: Risultati della valutazione
            candidates: Lista dei candidati
            grades: Lista dei grade
            
        Returns:
            DataFrame con i dettagli
        """
        details_data = []
        
        for candidate_name, candidate_results in results.items():
            # Trova il candidato corrispondente
            candidate = next((c for c in candidates if c.name == candidate_name), None)
            
            if candidate:
                for grade_name, grade_result in candidate_results.items():
                    # Trova il grade corrispondente
                    grade = next((g for g in grades if g.name == grade_name), None)
                    
                    if grade:
                        details_data.append({
                            'Candidato': candidate_name,
                            'Grade': grade_name,
                            'delta_type': candidate.delta_type,
                            'MV_usd_t': grade_result.get('MV_usd_t', 0),
                            'delta_neut': grade_result.get('delta_neut', None),
                            'mult_neut': grade_result.get('mult_neut', None),
                            'RON': candidate.ron,
                            'MON': candidate.mon,
                            'RVP': candidate.rvp,
                            'Densità': candidate.density,
                            'Zolfo': candidate.sulfur_ppm,
                            'Benzene': candidate.benzene,
                            'Aromatici': candidate.aromatics,
                            'Olefine': candidate.olefins
                        })
        
        return pd.DataFrame(details_data)
