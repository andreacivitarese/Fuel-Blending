"""
Modulo per il caricamento dei grades da valutare da Google Drive.

Questo modulo implementa le funzionalità per caricare i grades da valutare
direttamente da Google Drive.
"""

import pandas as pd
import numpy as np
import os
import tempfile
from datetime import datetime
from openpyxl import load_workbook

class GradesToEvaluateLoader:
    """
    Classe per caricare i grades da valutare da Google Drive.
    """
    
    def __init__(self, google_drive_integration=None):
        """
        Inizializza il caricatore dei grades da valutare.
        
        Args:
            google_drive_integration: Istanza di GoogleDriveIntegration per il download da Google Drive
        """
        self.google_drive_integration = google_drive_integration
    
    def load_grades_to_evaluate_from_file(self, file_path):
        """
        Carica i grades da valutare da un file locale.
        
        Args:
            file_path: Percorso del file Excel
            
        Returns:
            Lista di componenti candidati
        """
        # Determina il tipo di file
        file_ext = os.path.splitext(file_path)[1].lower()
        
        if file_ext == '.xlsx' or file_ext == '.xls':
            # Carica il file Excel
            df = pd.read_excel(file_path)
        elif file_ext == '.csv':
            # Carica il file CSV
            df = pd.read_csv(file_path)
        else:
            raise ValueError(f"Formato file non supportato: {file_ext}")
        
        # Converti il DataFrame in una lista di componenti candidati
        candidates = self._convert_dataframe_to_candidates(df)
        
        return candidates
    
    def load_grades_to_evaluate_from_google_drive(self, file_id):
        """
        Carica i grades da valutare da Google Drive.
        
        Args:
            file_id: ID del file su Google Drive
            
        Returns:
            Lista di componenti candidati
        """
        if self.google_drive_integration is None:
            raise ValueError("GoogleDriveIntegration non inizializzato")
        
        # Scarica il file da Google Drive
        local_path = self.google_drive_integration.download_file(file_id)
        
        # Carica i grades da valutare dal file locale
        candidates = self.load_grades_to_evaluate_from_file(local_path)
        
        # Elimina il file locale temporaneo
        os.remove(local_path)
        
        return candidates
    
    def _convert_dataframe_to_candidates(self, df):
        """
        Converte un DataFrame in una lista di componenti candidati.
        
        Args:
            df: DataFrame con i dati dei candidati
            
        Returns:
            Lista di componenti candidati
        """
        from fuel_blending.models import Component
        
        candidates = []
        
        for _, row in df.iterrows():
            # Crea un nuovo componente candidato
            candidate = Component(
                name=row.get('name'),
                delta_type=row.get('delta_type'),
                delta_value=row.get('delta_value') if 'delta_value' in row else None,
                multiplier=row.get('multiplier') if 'multiplier' in row else None,
                base_density_component=row.get('base_density_component') if 'base_density_component' in row else None,
                density=row.get('density'),
                ron=row.get('ron'),
                mon=row.get('mon'),
                rvp=row.get('rvp'),
                sulfur_ppm=row.get('sulfur_ppm'),
                benzene=row.get('benzene'),
                aromatics=row.get('aromatics'),
                olefins=row.get('olefins'),
                mtbe=row.get('mtbe'),
                t10=row.get('t10'),
                t50=row.get('t50'),
                e70=row.get('e70'),
                oxy_wt=row.get('oxy_wt'),
                is_ethanol=row.get('is_ethanol', False)
            )
            
            candidates.append(candidate)
        
        return candidates
    
    def select_grades_to_evaluate_interactively(self):
        """
        Seleziona interattivamente i grades da valutare da Google Drive.
        
        Returns:
            Lista di componenti candidati
        """
        if self.google_drive_integration is None:
            raise ValueError("GoogleDriveIntegration non inizializzato")
        
        # Ottieni la lista dei file Excel su Google Drive
        files = self.google_drive_integration.list_files(mime_type='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet')
        
        # Mostra la lista dei file all'utente
        print("\nFile Excel disponibili su Google Drive:")
        for i, file in enumerate(files):
            print(f"{i+1}. {file['name']} (ID: {file['id']})")
        
        # Chiedi all'utente di selezionare un file
        selection = input("\nSeleziona il numero del file dei grades da valutare: ")
        
        try:
            index = int(selection) - 1
            if index < 0 or index >= len(files):
                raise ValueError("Selezione non valida")
            
            selected_file = files[index]
            print(f"\nHai selezionato: {selected_file['name']}")
            
            # Carica i grades da valutare dal file selezionato
            candidates = self.load_grades_to_evaluate_from_google_drive(selected_file['id'])
            
            return candidates
            
        except (ValueError, IndexError) as e:
            print(f"Errore nella selezione: {str(e)}")
            return None
