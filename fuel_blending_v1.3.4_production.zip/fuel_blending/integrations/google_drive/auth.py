"""
Modulo di autenticazione per Google Drive.

Questo modulo gestisce l'autenticazione con Google API per accedere a Google Drive.
Versione 1.2.1: Migliorata gestione errori.
"""

import os
import json
import logging
from pathlib import Path
from typing import List, Optional, Dict, Any

from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.auth.exceptions import RefreshError, GoogleAuthError

from ...utils.exceptions import AuthenticationError

class GoogleAuthManager:
    """
    Gestisce l'autenticazione con Google API.
    """

    def __init__(
        self,
        credentials_file: Optional[str] = None,
        token_file: Optional[str] = None,
        scopes: Optional[List[str]] = None
    ):
        """
        Inizializza il gestore dell'autenticazione.

        Args:
            credentials_file: Percorso del file delle credenziali
            token_file: Percorso del file del token
            scopes: Lista degli scope richiesti
        """
        self.credentials_file = credentials_file or os.environ.get(
            "GOOGLE_CREDENTIALS_FILE",
            str(Path.home() / ".fuel_blending" / "credentials.json")
        )
        self.token_file = token_file or os.environ.get(
            "GOOGLE_TOKEN_FILE",
            str(Path.home() / ".fuel_blending" / "token.json")
        )
        self.scopes = scopes or [
            "https://www.googleapis.com/auth/drive.readonly"
        ]
        self.credentials = None
        self.logger = logging.getLogger("fuel_blending.integrations.google_drive.auth")
        self.logger.debug(f"GoogleAuthManager initialized. Credentials: {self.credentials_file}, Token: {self.token_file}")

    def authenticate(self, interactive: bool = True) -> Credentials:
        """
        Esegue l'autenticazione con Google API.

        Args:
            interactive: Se True, permette l'interazione utente per il flusso OAuth.
                         Se False, tenta solo di usare/rinnovare il token esistente.

        Returns:
            Credentials: Credenziali autenticate

        Raises:
            AuthenticationError: Se l'autenticazione fallisce
        """
        self.logger.info("Tentativo di autenticazione Google Drive...")
        try:
            # Verifica se esiste già un token valido
            if Path(self.token_file).exists():
                self.logger.debug(f"Trovato file token: {self.token_file}")
                try:
                    creds_data = json.loads(Path(self.token_file).read_text())
                    self.credentials = Credentials.from_authorized_user_info(creds_data, self.scopes)
                    self.logger.debug("Credenziali caricate dal file token.")
                except json.JSONDecodeError:
                    self.logger.error(f"Errore nel decodificare il file token JSON: {self.token_file}. Il file potrebbe essere corrotto.")
                    self.credentials = None # Forza ri-autenticazione
                except Exception as e:
                    self.logger.error(f"Errore imprevisto nel caricare le credenziali dal token: {e}")
                    self.credentials = None # Forza ri-autenticazione

            # Se non ci sono credenziali o non sono valide, tenta il refresh o il flusso OAuth
            if not self.credentials or not self.credentials.valid:
                self.logger.debug("Credenziali non trovate, non valide o token non caricato.")
                if self.credentials and self.credentials.expired and self.credentials.refresh_token:
                    self.logger.info("Credenziali scadute, tentativo di refresh del token...")
                    self.refresh_token() # Questo solleva AuthenticationError in caso di fallimento
                elif interactive:
                    self.logger.info("Nessuna credenziale valida trovata. Avvio del flusso di autenticazione interattiva...")
                    # Esegui il flusso OAuth 2.0
                    if not Path(self.credentials_file).exists():
                        self.logger.error(f"File delle credenziali non trovato: {self.credentials_file}")
                        raise AuthenticationError(
                            f"File delle credenziali Google (credentials.json) non trovato in '{self.credentials_file}'. "
                            "Assicurati che il file esista e sia accessibile. "
                            "Puoi scaricarlo dalla Google Cloud Platform Console per il tuo progetto."
                        )

                    try:
                        flow = InstalledAppFlow.from_client_secrets_file(
                            self.credentials_file,
                            self.scopes
                        )
                        # Nota: run_local_server apre un browser per l'utente
                        self.credentials = flow.run_local_server(port=0)
                        self.logger.info("Autenticazione interattiva completata con successo.")
                        # Salva il token per usi futuri
                        self._save_token()
                    except FileNotFoundError:
                         # Questo non dovrebbe accadere grazie al check precedente, ma per sicurezza
                         raise AuthenticationError(f"File delle credenziali non trovato (FileNotFoundError): {self.credentials_file}")
                    except Exception as e:
                         # Cattura altri errori durante il flusso (es. problemi di rete, porta occupata)
                         self.logger.error(f"Errore durante il flusso di autenticazione interattiva: {e}", exc_info=True)
                         raise AuthenticationError(f"Il flusso di autenticazione interattiva è fallito: {e}")
                else:
                    # Non interattivo e nessuna credenziale valida/rinnovabile
                    self.logger.error("Autenticazione non interattiva richiesta, ma non sono disponibili credenziali valide o rinnovabili.")
                    raise AuthenticationError(
                        "Autenticazione fallita: modalità non interattiva e token non valido o mancante. "
                        "Prova ad eseguire in modalità interattiva (--interactive) la prima volta."
                    )
            else:
                self.logger.info("Autenticazione Google Drive riuscita utilizzando credenziali esistenti.")

            # Verifica finale
            if not self.credentials or not self.credentials.valid:
                 self.logger.error("Autenticazione fallita: credenziali non valide dopo il processo.")
                 raise AuthenticationError("Autenticazione fallita: le credenziali non sono valide dopo il tentativo.")

            return self.credentials

        except AuthenticationError: # Rilancia le eccezioni specifiche già sollevate
            raise
        except GoogleAuthError as e:
            self.logger.error(f"Errore di autenticazione Google: {e}", exc_info=True)
            raise AuthenticationError(f"Errore durante l'autenticazione Google: {e}")
        except Exception as e:
            self.logger.error(f"Errore imprevisto durante l'autenticazione: {e}", exc_info=True)
            raise AuthenticationError(f"Errore imprevisto durante l'autenticazione Google: {e}")

    def get_credentials(self, interactive: bool = True) -> Credentials:
        """
        Ottiene le credenziali autenticate, eseguendo l'autenticazione se necessario.

        Args:
            interactive: Passato a self.authenticate se l'autenticazione è necessaria.

        Returns:
            Credentials: Credenziali autenticate

        Raises:
            AuthenticationError: Se non ci sono credenziali valide
        """
        if not self.credentials:
            self.logger.debug("Nessuna credenziale in memoria, avvio autenticazione...")
            return self.authenticate(interactive=interactive)

        if not self.credentials.valid:
            self.logger.debug("Credenziali in memoria non valide.")
            if self.credentials.expired and self.credentials.refresh_token:
                self.logger.info("Credenziali scadute, tentativo di refresh...")
                try:
                    self.refresh_token()
                except AuthenticationError:
                    self.logger.warning("Refresh fallito, tentativo di ri-autenticazione completa...")
                    return self.authenticate(interactive=interactive)
            else:
                self.logger.info("Credenziali non valide e non rinnovabili, tentativo di ri-autenticazione completa...")
                return self.authenticate(interactive=interactive)

        self.logger.debug("Restituzione credenziali valide dalla memoria.")
        return self.credentials

    def refresh_token(self) -> None:
        """
        Aggiorna il token di accesso.

        Raises:
            AuthenticationError: Se il refresh del token fallisce
        """
        if not self.credentials or not self.credentials.refresh_token:
             self.logger.error("Impossibile aggiornare: refresh token mancante.")
             raise AuthenticationError("Impossibile aggiornare il token: refresh token non disponibile.")

        try:
            self.logger.info("Aggiornamento token Google API...")
            self.credentials.refresh(Request())
            self.logger.info("Token aggiornato con successo.")
            self._save_token()
        except RefreshError as e:
            self.logger.error(f"Errore durante il refresh del token: {e}. Potrebbe essere necessario ri-autenticarsi.")
            # Rimuovi il token potenzialmente corrotto per forzare ri-autenticazione al prossimo tentativo
            if Path(self.token_file).exists():
                try:
                    os.remove(self.token_file)
                    self.logger.info(f"File token {self.token_file} rimosso a causa di errore di refresh.")
                except OSError as remove_err:
                    self.logger.error(f"Impossibile rimuovere il file token {self.token_file}: {remove_err}")
            self.credentials = None # Invalida credenziali in memoria
            raise AuthenticationError(
                f"Impossibile aggiornare il token Google: {e}. "
                "L'autorizzazione potrebbe essere scaduta o revocata. Prova a ri-eseguire in modalità interattiva."
            )
        except Exception as e:
            self.logger.error(f"Errore imprevisto durante il refresh del token: {e}", exc_info=True)
            raise AuthenticationError(f"Errore imprevisto durante l'aggiornamento del token: {e}")

    def revoke_token(self) -> None:
        """
        Revoca il token di accesso e rimuove il file token locale.

        Raises:
            AuthenticationError: Se la revoca del token fallisce
        """
        if not self.credentials or not self.credentials.token:
            self.logger.warning("Nessun token da revocare.")
            # Rimuovi comunque il file locale se esiste
            if Path(self.token_file).exists():
                try:
                    os.remove(self.token_file)
                    self.logger.info(f"File token locale {self.token_file} rimosso (nessuna credenziale attiva).")
                except OSError as e:
                    self.logger.error(f"Impossibile rimuovere il file token {self.token_file}: {e}")
            return

        try:
            self.logger.info("Revoca del token Google API in corso...")
            # Usa la sessione della richiesta per inviare la richiesta di revoca
            revoke_response = Request().session.post(
                "https://oauth2.googleapis.com/revoke",
                params={"token": self.credentials.token},
                headers={"content-type": "application/x-www-form-urlencoded"}
            )
            revoke_response.raise_for_status() # Solleva eccezione per errori HTTP
            self.logger.info("Token revocato con successo su Google.")

        except Exception as e:
            # Non bloccare la rimozione locale se la revoca remota fallisce
            self.logger.error(f"Errore durante la revoca del token su Google: {e}. Procedo con la rimozione locale.")
            # Potrebbe essere utile sollevare comunque un'eccezione qui?
            # Per ora logghiamo e continuiamo per rimuovere il file locale.

        finally:
            # Rimuovi il file del token locale in ogni caso dopo il tentativo di revoca
            if Path(self.token_file).exists():
                try:
                    os.remove(self.token_file)
                    self.logger.info(f"File token locale {self.token_file} rimosso.")
                except OSError as e:
                    self.logger.error(f"Impossibile rimuovere il file token {self.token_file}: {e}")
                    # Solleva errore qui perché la rimozione locale è importante
                    raise AuthenticationError(f"Token revocato (o tentativo fallito), ma impossibile rimuovere il file token locale: {e}")
            self.credentials = None # Invalida credenziali in memoria

    def _save_token(self) -> None:
        """
        Salva le credenziali correnti (token) in un file JSON.

        Raises:
            AuthenticationError: Se il salvataggio del token fallisce
        """
        if not self.credentials:
            self.logger.error("Tentativo di salvare un token nullo.")
            raise AuthenticationError("Impossibile salvare il token: nessuna credenziale disponibile.")

        try:
            token_path = Path(self.token_file)
            # Crea la directory genitore se non esiste
            token_path.parent.mkdir(parents=True, exist_ok=True)

            # Salva il token
            token_path.write_text(self.credentials.to_json())
            self.logger.debug(f"Token salvato in {self.token_file}")

        except OSError as e:
            self.logger.error(f"Errore OS durante il salvataggio del token in {self.token_file}: {e}", exc_info=True)
            raise AuthenticationError(f"Impossibile salvare il file token in {self.token_file}: {e}")
        except Exception as e:
            self.logger.error(f"Errore imprevisto durante il salvataggio del token: {e}", exc_info=True)
            raise AuthenticationError(f"Errore imprevisto durante il salvataggio del token: {e}")

