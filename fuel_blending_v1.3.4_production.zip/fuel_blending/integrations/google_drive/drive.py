"""
Modulo di accesso ai file su Google Drive.

Questo modulo gestisce l'accesso ai file su Google Drive.
"""

import os
import io
import logging
import tempfile
from typing import List, Dict, Any, Optional, Tuple

from googleapiclient.discovery import build
from googleapiclient.http import MediaIoBaseDownload
from googleapiclient.errors import HttpError

from .auth import GoogleAuthManager
from ...utils.exceptions import GoogleDriveError

class GoogleDriveManager:
    """
    Gestisce l'accesso ai file su Google Drive.
    """
    
    def __init__(self, auth_manager: GoogleAuthManager):
        """
        Inizializza il gestore di Google Drive.
        
        Args:
            auth_manager: Gestore dell'autenticazione
        """
        self.auth_manager = auth_manager
        self.service = None
        self.logger = logging.getLogger("fuel_blending.integrations.google_drive.drive")
    
    def connect(self) -> None:
        """
        Connette al servizio Google Drive.
        
        Raises:
            GoogleDriveError: Se la connessione fallisce
        """
        try:
            credentials = self.auth_manager.get_credentials()
            self.service = build('drive', 'v3', credentials=credentials)
            self.logger.debug("Connesso al servizio Google Drive")
        except Exception as e:
            self.logger.error(f"Errore durante la connessione a Google Drive: {str(e)}")
            raise GoogleDriveError(f"Impossibile connettersi a Google Drive: {str(e)}")
    
    def ensure_connected(self) -> None:
        """
        Assicura che la connessione al servizio Google Drive sia attiva.
        
        Raises:
            GoogleDriveError: Se la connessione fallisce
        """
        if not self.service:
            self.connect()
    
    def list_excel_files(self, query: str = None) -> List[Dict[str, Any]]:
        """
        Elenca i file Excel disponibili su Google Drive.
        
        Args:
            query: Query di ricerca aggiuntiva
            
        Returns:
            List[Dict[str, Any]]: Lista dei file Excel
            
        Raises:
            GoogleDriveError: Se l'elenco dei file fallisce
        """
        try:
            self.ensure_connected()
            
            # Query di base per i file Excel
            base_query = "mimeType='application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' or mimeType='application/vnd.ms-excel'"
            
            # Aggiungi la query aggiuntiva se specificata
            if query:
                full_query = f"({base_query}) and ({query})"
            else:
                full_query = base_query
            
            # Esegui la query
            results = self.service.files().list(
                q=full_query,
                spaces='drive',
                fields='files(id, name, mimeType, createdTime, modifiedTime, size)',
                orderBy='modifiedTime desc'
            ).execute()
            
            files = results.get('files', [])
            
            self.logger.debug(f"Trovati {len(files)} file Excel su Google Drive")
            return files
            
        except HttpError as e:
            self.logger.error(f"Errore HTTP durante l'elenco dei file Excel: {str(e)}")
            raise GoogleDriveError(f"Impossibile elencare i file Excel: {str(e)}")
        except Exception as e:
            self.logger.error(f"Errore durante l'elenco dei file Excel: {str(e)}")
            raise GoogleDriveError(f"Impossibile elencare i file Excel: {str(e)}")
    
    def get_file_metadata(self, file_id: str) -> Dict[str, Any]:
        """
        Ottiene i metadati di un file da Google Drive.
        
        Args:
            file_id: ID del file
            
        Returns:
            Dict[str, Any]: Metadati del file
            
        Raises:
            GoogleDriveError: Se l'ottenimento dei metadati fallisce
        """
        try:
            self.ensure_connected()
            
            file = self.service.files().get(
                fileId=file_id,
                fields='id, name, mimeType, createdTime, modifiedTime, size'
            ).execute()
            
            self.logger.debug(f"Ottenuti metadati per il file {file.get('name')} ({file_id})")
            return file
            
        except HttpError as e:
            self.logger.error(f"Errore HTTP durante l'ottenimento dei metadati del file: {str(e)}")
            raise GoogleDriveError(f"Impossibile ottenere i metadati del file: {str(e)}")
        except Exception as e:
            self.logger.error(f"Errore durante l'ottenimento dei metadati del file: {str(e)}")
            raise GoogleDriveError(f"Impossibile ottenere i metadati del file: {str(e)}")
    
    def download_file(self, file_id: str, destination: str = None) -> str:
        """
        Scarica un file da Google Drive.
        
        Args:
            file_id: ID del file
            destination: Percorso di destinazione (opzionale)
            
        Returns:
            str: Percorso del file scaricato
            
        Raises:
            GoogleDriveError: Se il download fallisce
        """
        try:
            self.ensure_connected()
            
            # Se non è specificata una destinazione, crea un file temporaneo
            if not destination:
                # Ottieni i metadati del file per determinare l'estensione
                file_metadata = self.get_file_metadata(file_id)
                file_name = file_metadata.get('name', 'downloaded_file')
                
                # Estrai l'estensione dal nome del file
                _, ext = os.path.splitext(file_name)
                if not ext:
                    # Se non c'è estensione, determina in base al mimeType
                    mime_type = file_metadata.get('mimeType', '')
                    if 'spreadsheetml.sheet' in mime_type:
                        ext = '.xlsx'
                    elif 'ms-excel' in mime_type:
                        ext = '.xls'
                    else:
                        ext = '.bin'
                
                # Crea un file temporaneo con l'estensione corretta
                fd, destination = tempfile.mkstemp(suffix=ext)
                os.close(fd)
            
            # Scarica il file
            request = self.service.files().get_media(fileId=file_id)
            with open(destination, 'wb') as f:
                downloader = MediaIoBaseDownload(f, request)
                done = False
                while not done:
                    status, done = downloader.next_chunk()
                    self.logger.debug(f"Download {int(status.progress() * 100)}%")
            
            self.logger.debug(f"File {file_id} scaricato in {destination}")
            return destination
            
        except HttpError as e:
            self.logger.error(f"Errore HTTP durante il download del file: {str(e)}")
            raise GoogleDriveError(f"Impossibile scaricare il file: {str(e)}")
        except Exception as e:
            self.logger.error(f"Errore durante il download del file: {str(e)}")
            raise GoogleDriveError(f"Impossibile scaricare il file: {str(e)}")
    
    def interactive_file_selection(self, file_type: str = "Excel") -> Optional[str]:
        """
        Permette all'utente di selezionare un file in modo interattivo.
        
        Args:
            file_type: Tipo di file da selezionare
            
        Returns:
            Optional[str]: ID del file selezionato o None se l'utente annulla
            
        Raises:
            GoogleDriveError: Se la selezione fallisce
        """
        try:
            # Elenca i file Excel
            files = self.list_excel_files()
            
            if not files:
                print(f"Nessun file {file_type} trovato su Google Drive.")
                return None
            
            # Mostra i file all'utente
            print(f"\nFile {file_type} disponibili su Google Drive:")
            for i, file in enumerate(files):
                print(f"{i+1}. {file.get('name')} (Modificato: {file.get('modifiedTime')})")
            
            # Chiedi all'utente di selezionare un file
            while True:
                try:
                    choice = input("\nSeleziona un file (numero) o 'q' per annullare: ")
                    
                    if choice.lower() == 'q':
                        return None
                    
                    index = int(choice) - 1
                    if 0 <= index < len(files):
                        selected_file = files[index]
                        print(f"Selezionato: {selected_file.get('name')}")
                        return selected_file.get('id')
                    else:
                        print("Selezione non valida. Riprova.")
                except ValueError:
                    print("Inserisci un numero valido.")
            
        except Exception as e:
            self.logger.error(f"Errore durante la selezione interattiva del file: {str(e)}")
            raise GoogleDriveError(f"Impossibile selezionare il file: {str(e)}")
