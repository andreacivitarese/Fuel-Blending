"""
Modulo di lettura dei dati da file Excel su Google Drive.

Questo modulo gestisce la lettura e la conversione dei dati da file Excel.
"""

import os
import logging
import pandas as pd
import json
from typing import List, Dict, Any, Optional, Tuple, Union

from .drive import GoogleDriveManager
from ...models import Component, Grade, Additive, ForceEthanol
from ...utils.exceptions import DataLoadError

class ExcelReader:
    """
    Legge i dati dai file Excel.
    """
    
    def __init__(self, drive_manager: GoogleDriveManager):
        """
        Inizializza il lettore Excel.
        
        Args:
            drive_manager: Gestore di Google Drive
        """
        self.drive_manager = drive_manager
        self.logger = logging.getLogger("fuel_blending.integrations.google_drive.excel")
    
    def read_components(self, file_id: str, sheet_name: str = 0) -> List[Component]:
        """
        Legge i dati dei componenti da un file Excel.
        
        Args:
            file_id: ID del file
            sheet_name: Nome del foglio o indice (default: 0)
            
        Returns:
            List[Component]: Lista dei componenti
            
        Raises:
            DataLoadingError: Se la lettura dei dati fallisce
        """
        try:
            # Scarica il file
            file_path = self.drive_manager.download_file(file_id)
            
            # Leggi il file Excel
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Rimuovi il file temporaneo
            os.unlink(file_path)
            
            # Verifica che le colonne necessarie siano presenti
            required_columns = [
                'name', 'delta_type', 'density', 'ron', 'mon', 'rvp', 
                'sulfur_ppm', 'benzene', 'aromatics', 'olefins', 'mtbe', 
                't10', 't50', 'e70', 'oxy_wt', 'is_ethanol'
            ]
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise DataLoadingError(
                    f"Colonne mancanti nel file dei componenti: {', '.join(missing_columns)}"
                )
            
            # Converti i dati in oggetti Component
            components = []
            for _, row in df.iterrows():
                # Gestisci i valori NaN
                row_dict = row.fillna('').to_dict()
                
                # Converti is_ethanol in booleano
                is_ethanol = row_dict.get('is_ethanol', 0)
                if isinstance(is_ethanol, str):
                    is_ethanol = is_ethanol.lower() in ('true', 't', 'yes', 'y', '1')
                else:
                    is_ethanol = bool(is_ethanol)
                
                # Crea il componente
                component = Component(
                    name=row_dict.get('name', ''),
                    delta_type=row_dict.get('delta_type', 'as_is'),
                    delta_value=row_dict.get('delta_value', 0.0) if row_dict.get('delta_value') != '' else None,
                    multiplier=row_dict.get('multiplier', 1.0) if row_dict.get('multiplier') != '' else None,
                    base_density_component=row_dict.get('base_density_component', '') or None,
                    density=float(row_dict.get('density', 0.0)),
                    ron=float(row_dict.get('ron', 0.0)),
                    mon=float(row_dict.get('mon', 0.0)),
                    rvp=float(row_dict.get('rvp', 0.0)),
                    sulfur_ppm=float(row_dict.get('sulfur_ppm', 0.0)),
                    benzene=float(row_dict.get('benzene', 0.0)),
                    aromatics=float(row_dict.get('aromatics', 0.0)),
                    olefins=float(row_dict.get('olefins', 0.0)),
                    mtbe=float(row_dict.get('mtbe', 0.0)),
                    t10=float(row_dict.get('t10', 0.0)),
                    t50=float(row_dict.get('t50', 0.0)),
                    e70=float(row_dict.get('e70', 0.0)),
                    oxy_wt=float(row_dict.get('oxy_wt', 0.0)),
                    is_ethanol=is_ethanol
                )
                
                components.append(component)
            
            self.logger.debug(f"Letti {len(components)} componenti dal file Excel")
            return components
            
        except Exception as e:
            self.logger.error(f"Errore durante la lettura dei componenti: {str(e)}")
            raise DataLoadingError(f"Impossibile leggere i componenti: {str(e)}")
    
    def read_grades(self, file_id: str, sheet_name: str = 0) -> List[Grade]:
        """
        Legge i dati dei grade da un file Excel.
        
        Args:
            file_id: ID del file
            sheet_name: Nome del foglio o indice (default: 0)
            
        Returns:
            List[Grade]: Lista dei grade
            
        Raises:
            DataLoadingError: Se la lettura dei dati fallisce
        """
        try:
            # Scarica il file
            file_path = self.drive_manager.download_file(file_id)
            
            # Leggi il file Excel
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Rimuovi il file temporaneo
            os.unlink(file_path)
            
            # Verifica che le colonne necessarie siano presenti
            required_columns = ['name', 'specs', 'target_mass', 'price_mode']
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise DataLoadingError(
                    f"Colonne mancanti nel file dei grade: {', '.join(missing_columns)}"
                )
            
            # Converti i dati in oggetti Grade
            grades = []
            for _, row in df.iterrows():
                # Gestisci i valori NaN
                row_dict = row.fillna('').to_dict()
                
                # Converti le specifiche da JSON a dizionario
                specs_str = row_dict.get('specs', '{}')
                if isinstance(specs_str, str) and specs_str:
                    try:
                        specs = json.loads(specs_str)
                    except json.JSONDecodeError:
                        raise DataLoadingError(
                            f"Formato JSON non valido per le specifiche del grade {row_dict.get('name')}"
                        )
                else:
                    # Se non è una stringa o è vuota, cerca colonne specifiche per min/max
                    specs = {}
                    for col in df.columns:
                        if col.endswith('_min') or col.endswith('_max'):
                            prop_name = col[:-4]  # Rimuovi _min o _max
                            if prop_name not in specs:
                                specs[prop_name] = [None, None]
                            
                            if col.endswith('_min'):
                                specs[prop_name][0] = row_dict.get(col, None)
                            else:
                                specs[prop_name][1] = row_dict.get(col, None)
                
                # Converti force_ethanol
                force_ethanol = None
                if 'force_ethanol_enabled' in row_dict or 'force_ethanol_mass_frac' in row_dict:
                    enabled = row_dict.get('force_ethanol_enabled', False)
                    if isinstance(enabled, str):
                        enabled = enabled.lower() in ('true', 't', 'yes', 'y', '1')
                    else:
                        enabled = bool(enabled)
                    
                    mass_frac = float(row_dict.get('force_ethanol_mass_frac', 0.0))
                    
                    force_ethanol = ForceEthanol(
                        enabled=enabled,
                        mass_frac=mass_frac
                    )
                
                # Crea il grade
                grade = Grade(
                    name=row_dict.get('name', ''),
                    specs=specs,
                    target_mass=float(row_dict.get('target_mass', 1000.0)),
                    price_mode=row_dict.get('price_mode', 'as_is'),
                    ron_linear_min=float(row_dict.get('ron_linear_min', 0.0)) if row_dict.get('ron_linear_min') != '' else None,
                    force_ethanol=force_ethanol
                )
                
                grades.append(grade)
            
            self.logger.debug(f"Letti {len(grades)} grade dal file Excel")
            return grades
            
        except Exception as e:
            self.logger.error(f"Errore durante la lettura dei grade: {str(e)}")
            raise DataLoadingError(f"Impossibile leggere i grade: {str(e)}")
    
    def read_additives(self, file_id: str, sheet_name: str = 0) -> Dict[str, Additive]:
        """
        Legge i dati degli additivi da un file Excel.
        
        Args:
            file_id: ID del file
            sheet_name: Nome del foglio o indice (default: 0)
            
        Returns:
            Dict[str, Additive]: Dizionario degli additivi
            
        Raises:
            DataLoadingError: Se la lettura dei dati fallisce
        """
        try:
            # Scarica il file
            file_path = self.drive_manager.download_file(file_id)
            
            # Leggi il file Excel
            df = pd.read_excel(file_path, sheet_name=sheet_name)
            
            # Rimuovi il file temporaneo
            os.unlink(file_path)
            
            # Verifica che le colonne necessarie siano presenti
            required_columns = ['name', 'cost_usd_per_litre', 'density_add']
            
            missing_columns = [col for col in required_columns if col not in df.columns]
            if missing_columns:
                raise DataLoadingError(
                    f"Colonne mancanti nel file degli additivi: {', '.join(missing_columns)}"
                )
            
            # Converti i dati in oggetti Additive
            additives = {}
            for _, row in df.iterrows():
                # Gestisci i valori NaN
                row_dict = row.fillna('').to_dict()
                
                # Crea l'additivo
                name = row_dict.get('name', '')
                additive = Additive(
                    name=name,
                    cost_usd_per_litre=float(row_dict.get('cost_usd_per_litre', 0.0)),
                    density_add=float(row_dict.get('density_add', 0.0))
                )
                
                additives[name] = additive
            
            self.logger.debug(f"Letti {len(additives)} additivi dal file Excel")
            return additives
            
        except Exception as e:
            self.logger.error(f"Errore durante la lettura degli additivi: {str(e)}")
            raise DataLoadingError(f"Impossibile leggere gli additivi: {str(e)}")
