"""
Modulo di inizializzazione per il sottopacchetto integrations.

Questo modulo esporta le funzionalità di integrazione con servizi esterni,
come Google Drive.
"""

# Importa solo il sottopacchetto google_drive, non le singole classi
# per evitare import circolari
from . import google_drive

__all__ = ["google_drive"]
