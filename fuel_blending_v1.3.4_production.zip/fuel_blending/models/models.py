"""
Data-model di base per componenti, grade e additivi.

Incorpora la logica di pricing, le proprietà aggiornate, i vincoli sull'etanolo e gli additivi.
Versione 1.2.3: Aggiunta densità base per escalation configurabile per grade.
Versione 1.3.3: Aggiunto campo shadow_prices a OptimizationResultModel.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, Optional, Literal, Tuple

# Costanti per il tipo di delta di prezzo
DELTA_TYPE_AS_IS = "as_is"
DELTA_TYPE_FACTOR = "factor"
DELTA_TYPE_ESCALATED = "escalated"

# Costanti per la modalità di prezzo del grade
PRICE_MODE_AS_IS = "as_is"
PRICE_MODE_ESCALATED = "escalated"

@dataclass(slots=True)
class ForceEthanol:
    """
    Modello per la configurazione della forzatura dell'etanolo.

    Attributes:
        enabled: Flag che indica se la forzatura è abilitata
        mass_frac: Frazione di massa dell'etanolo da forzare
    """
    enabled: bool = False
    mass_frac: float = 0.0

@dataclass(slots=True)
class Component:
    """
    Modello per un componente, con logica di pricing.

    Attributes:
        name: Nome del componente
        delta_type: Tipo di differenziale (as_is, factor, escalated)
        density: Densità (kg/m3 o altra unità consistente)
        properties: Dizionario delle proprietà (ron, mon, rvp, t10, etc.)
        delta_value: Valore del differenziale (per as_is, in USD/mt)
        multiplier: Moltiplicatore (per factor)
        base_density_component: Densità base specifica per escalation di questo componente (opzionale, sovrascrive quella del grade/globale)
        max_qty_mt: Quantità massima disponibile in mt (opzionale)
        is_ethanol: Flag che indica se il componente è etanolo
    """
    name: str
    delta_type: Literal[DELTA_TYPE_AS_IS, DELTA_TYPE_FACTOR, DELTA_TYPE_ESCALATED]
    density: float
    properties: Dict[str, float]
    delta_value: Optional[float] = None
    multiplier: Optional[float] = None
    base_density_component: Optional[float] = None # Questo campo permette l'override per componente
    max_qty_mt: Optional[float] = None
    is_ethanol: bool = False

    def __post_init__(self):
        # Validazione basata su delta_type
        if self.delta_type == DELTA_TYPE_AS_IS and self.delta_value is None:
            raise ValueError(f"Component '{self.name}' has delta_type 'as_is' but is missing 'delta_value'.")
        elif self.delta_type == DELTA_TYPE_FACTOR and self.multiplier is None:
            raise ValueError(f"Component '{self.name}' has delta_type 'factor' but is missing 'multiplier'.")
        # La validazione per 'escalated' (es. delta_value non None) e 'base_density_component'
        # viene gestita nel BlendingContext dove sono disponibili più informazioni.

@dataclass(slots=True)
class Additive:
    """
    Modello per un additivo.

    Attributes:
        name: Nome dell'additivo
        cost_usd_per_litre: Costo in USD per litro
        density_add: Densità dell'additivo (kg/m3 o unità consistente)
    """
    name: str
    cost_usd_per_litre: float
    density_add: float

@dataclass(slots=True)
class Grade:
    """
    Modello per un grade target.

    Attributes:
        name: Nome del grade
        specs: Dizionario delle specifiche {nome_proprietà: (min, max)}
        target_mass: Massa target (mt)
        price_mode: Modalità di prezzo (as_is, escalated)
        base_density_escalation: Densità base per escalation specifica per questo grade (opzionale, sovrascrive quella globale)
        ron_linear_min: Specifica minima per RON Lineare (opzionale)
        force_ethanol: Configurazione per la forzatura dell'etanolo (opzionale)
        additives: Dizionario degli additivi da utilizzare {nome_additivo: dosaggio_ppm}
    """
    name: str
    specs: Dict[str, Tuple[Optional[float], Optional[float]]] = field(default_factory=dict)
    target_mass: float = 1.0 # Default a 1 mt se non specificato
    price_mode: Literal[PRICE_MODE_AS_IS, PRICE_MODE_ESCALATED] = PRICE_MODE_AS_IS
    base_density_escalation: Optional[float] = None # Aggiunto campo per densità base specifica del grade
    ron_linear_min: Optional[float] = None
    force_ethanol: Optional[ForceEthanol] = None
    additives: Dict[str, float] = field(default_factory=dict)

# Facoltativo: piccolo wrapper che raggruppa i risultati di ottimizzazione
@dataclass(slots=True)
class OptimizationResultModel:
    """
    Modello per i risultati dell'ottimizzazione.

    Attributes:
        grade_name: Nome del grade ottimizzato.
        success: Flag che indica se l'ottimizzazione ha avuto successo.
        message: Messaggio di stato dal solver.
        component_fractions: Dizionario {nome_componente: frazione_massica}.
        blend_properties: Dizionario {nome_proprietà: valore_calcolato}.
        total_cost_usd_mt: Costo totale del blend in USD/mt.
        shadow_prices: Dizionario {nome_vincolo: prezzo_ombra} (Lagrange multipliers).
    """
    grade_name: str
    success: bool
    message: str
    component_fractions: Dict[str, float] = field(default_factory=dict)
    blend_properties: Dict[str, float] = field(default_factory=dict)
    total_cost_usd_mt: float = 0.0
    shadow_prices: Dict[str, float] = field(default_factory=dict) # Aggiunto campo per shadow prices

