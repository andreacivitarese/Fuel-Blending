"""
Implementazione dei comandi CLI per il fuel blending.
"""

import argparse
import logging
import pandas as pd
import numpy as np
from pathlib import Path
from typing import Dict, List, Any, Optional
import copy

# Import per output formattato
from rich.console import Console
from rich.table import Table

# Import necessari dalla nuova struttura
from ..config.config import Config, ConfigManager # Import ConfigManager
from ..loaders import DataLoader
from ..blending import BlendingContext, PropertyCalculator, ConstraintManager
from ..optimization import Optimizer, OptimizerConfig
from ..analysis import EconomicAnalyzer
from ..models import OptimizationResultModel, Component, Grade, Additive
from ..utils.exceptions import DataLoadError, OptimizationError
from ..integrations.google_drive import GoogleDriveIntegration

# Logger
logger = logging.getLogger("fuel_blending.commands")
console = Console() # Rich console for printing tables

def _load_data_from_source(args: argparse.Namespace, config: Config, data_type: str, file_arg: str, interactive: bool = False) -> Any:
    """Carica dati da file locale o Google Drive."""
    file_path_or_id = getattr(args, file_arg, None)
    if not file_path_or_id:
        # Corrected f-string with single quotes inside replace()
        raise DataLoadError(f"Argomento --{file_arg.replace('_', '-')} non specificato.")

    loader = DataLoader(config)
    gdrive_integration = None
    local_path = None # Initialize local_path

    if getattr(args, "from_google_drive", False):
        # Initialize GoogleDriveIntegration only if needed
        credentials_file = getattr(args, "credentials_file", None) or getattr(config.google_drive, "credentials_file", None)
        token_file = getattr(args, "token_file", None) or getattr(config.google_drive, "token_file", None)
        gdrive_integration = GoogleDriveIntegration(credentials_file=credentials_file, token_file=token_file)
        gdrive_integration.connect() # Ensure connection

        try:
            # Use interactive selection if path is not provided and interactive is True
            if not file_path_or_id and interactive:
                file_id = gdrive_integration.interactive_file_selection()
                if not file_id:
                    raise DataLoadError("Selezione file annullata dall'utente.")
                file_path_or_id = file_id

            # Download the file and get the local path
            local_path = gdrive_integration.download_file(file_path_or_id)
            logger.info(f"File {file_path_or_id} scaricato da Google Drive in {local_path}")
            file_to_load = local_path
        except Exception as e:
            logger.error(f"Errore durante il caricamento di {data_type} da Google Drive (ID: {file_path_or_id}): {e}", exc_info=True)
            raise DataLoadError(f"Impossibile caricare {data_type} da Google Drive.") from e
    else:
        file_to_load = Path(file_path_or_id)
        if not file_to_load.exists():
            raise DataLoadError(f"File {data_type} non trovato: {file_to_load}")

    try:
        if data_type == "components":
            data = loader.load_components(file_to_load)
        elif data_type == "grades":
            data = loader.load_grades(file_to_load)
        elif data_type == "additives":
            data = loader.load_additives(file_to_load)
        elif data_type == "candidates":
            data = loader.load_candidates(file_to_load)
        elif data_type == "results":
            # Assuming results are stored in JSON format compatible with OptimizationResultModel
            # DataLoader needs a method to load these, e.g., load_optimization_results
            data = loader.load_optimization_results(file_to_load)
        else:
            raise ValueError(f"Tipo di dato non supportato: {data_type}")
        logger.info(f"Dati {data_type} caricati con successo da {file_to_load}")
        return data
    finally:
        # Clean up temporary file if downloaded from Google Drive
        if gdrive_integration and local_path and Path(local_path).exists() and str(local_path) != str(file_path_or_id):
            try:
                Path(local_path).unlink()
                logger.debug(f"File temporaneo {local_path} eliminato.")
            except OSError as e:
                logger.warning(f"Impossibile eliminare il file temporaneo {local_path}: {e}")

def _save_dataframe(df: pd.DataFrame, output_path: Path, format: str):
    """Salva un DataFrame in CSV o JSON."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    if format == "csv":
        df.to_csv(output_path, index=False)
    elif format == "json":
        df.to_json(output_path, orient="records", indent=2)
    else:
        raise ValueError(f"Formato output non supportato: {format}")
    logger.info(f"DataFrame salvato in {output_path} (formato: {format})")

def _print_optimize_results_table(results: List[OptimizationResultModel]):
    """Stampa i risultati dell'ottimizzazione in una tabella Rich (summary)."""
    summary_table = Table(title="Optimization Results Summary", show_header=True, header_style="bold magenta")
    summary_table.add_column("Grade", style="dim", width=15)
    summary_table.add_column("Status", justify="center")
    summary_table.add_column("Cost (USD/mt)", justify="right")
    summary_table.add_column("Message", max_width=60)

    for res in results:
        status = "[bold green]SUCCESS[/]" if res.success else "[bold red]FAILED[/]"
        cost_str = f"{res.total_cost_usd_mt:.4f}" if res.success else "N/A"
        message = res.message if res.message else ""
        # Truncate long messages for console display
        if len(message) > 57:
            message = message[:57] + "..."
        summary_table.add_row(res.grade_name, status, cost_str, message)

    console.print(summary_table)

def _print_shadow_prices_table(result: OptimizationResultModel):
    """Stampa i prezzi ombra (moltiplicatori di Lagrange) per un risultato di ottimizzazione."""
    if not result.success or not result.shadow_prices:
        return # Non stampare nulla se l'ottimizzazione è fallita o non ci sono prezzi ombra

    shadow_table = Table(title=f"Shadow Prices for Grade: {result.grade_name}", show_header=True, header_style="bold cyan")
    shadow_table.add_column("Constraint Name", style="dim", width=30)
    shadow_table.add_column("Shadow Price (USD/mt per unit)", justify="right")

    for name, price in result.shadow_prices.items():
        shadow_table.add_row(name, f"{price:.4f}")

    console.print(shadow_table)

def _print_neutral_prices_table(neutral_prices: Dict[str, float], grade_name: str):
    """Stampa i prezzi neutrali per un grade."""
    if not neutral_prices:
        return

    neutral_table = Table(title=f"Neutral Prices for Grade: {grade_name}", show_header=True, header_style="bold green")
    neutral_table.add_column("Component Name", style="dim", width=20)
    neutral_table.add_column("Neutral Price (USD/mt)", justify="right")

    for name, price in neutral_prices.items():
        neutral_table.add_row(name, f"{price:.4f}")

    console.print(neutral_table)

def _print_eval_results_table(results_df: pd.DataFrame):
    """Stampa i risultati della valutazione candidati in una tabella Rich."""
    table = Table(title="Candidate Evaluation Summary", show_header=True, header_style="bold magenta")
    table.add_column("Candidate ID", style="dim", width=12)
    table.add_column("Grade", width=12)
    table.add_column("Cost (USD/mt)", justify="right")
    table.add_column("Optimal Cost", justify="right")
    table.add_column("Delta Cost", justify="right")
    table.add_column("Constraints OK?", justify="center")
    # Add more columns as needed, e.g., key properties or violations

    for _, row in results_df.iterrows():
        cost_str = f"{row['cost_usd_mt']:.4f}" if pd.notna(row['cost_usd_mt']) else "N/A"
        opt_cost_str = f"{row['optimal_cost_usd_mt']:.4f}" if pd.notna(row['optimal_cost_usd_mt']) else "N/A"
        delta_cost_str = f"{row['delta_cost']:.4f}" if pd.notna(row['delta_cost']) else "N/A"
        constraints_ok_str = "[bold green]Yes[/]" if row.get('constraints_ok', False) else "[bold red]No[/]"
        if 'error' in row and pd.notna(row['error']):
             constraints_ok_str = "[bold red]ERROR[/]"

        table.add_row(
            row.get('candidate_id', 'N/A'),
            row.get('grade_name', 'N/A'),
            cost_str,
            opt_cost_str,
            delta_cost_str,
            constraints_ok_str
        )

    console.print(table)

def _print_sensitivity_results_table(results_df: pd.DataFrame):
    """Stampa i risultati dell'analisi di sensitività in una tabella Rich."""
    table = Table(title="Sensitivity Analysis Summary", show_header=True, header_style="bold magenta")
    table.add_column("Param Name", style="dim", width=20)
    table.add_column("Param Value", justify="right")
    table.add_column("Grade", width=12)
    table.add_column("Status", justify="center")
    table.add_column("Cost (USD/mt)", justify="right")
    # Add more columns like key properties/fractions if needed

    for _, row in results_df.iterrows():
        status = "[bold green]SUCCESS[/]" if row['success'] else "[bold red]FAILED[/]"
        cost_str = f"{row['cost_usd_mt']:.4f}" if row['success'] and pd.notna(row['cost_usd_mt']) else "N/A"
        param_val_str = f"{row['param_value']:.4g}" # Format value nicely

        table.add_row(
            row.get('param_name', 'N/A'),
            param_val_str,
            row.get('grade_name', 'N/A'),
            status,
            cost_str
        )

    console.print(table)

def command_optimize(args: argparse.Namespace, config: Config):
    """Esegue il comando optimize."""
    logger.info("Avvio comando optimize...")

    try:
        components = _load_data_from_source(args, config, "components", "components_file", interactive=args.interactive)
        grades = _load_data_from_source(args, config, "grades", "grades_file", interactive=args.interactive)
        additives = _load_data_from_source(args, config, "additives", "additives_file", interactive=args.interactive) if args.additives_file else []

        all_results: List[OptimizationResultModel] = []
        all_attempts: Dict[str, List[Any]] = {}

        for grade in grades:
            logger.info(f"--- Ottimizzazione per Grade: {grade.name} ---")
            try:
                context = BlendingContext(components, grade, additives, config.flat_price, config.blending.rvp_exp)
                optimizer = Optimizer(context, config.optimizer)
                result, attempts = optimizer.optimize()
                all_results.append(result)
                all_attempts[grade.name] = attempts

                if not result.success:
                    logger.error(f"Ottimizzazione fallita per {grade.name}: {result.message}")
                    if not args.continue_on_error:
                        raise OptimizationError(grade.name, f"Ottimizzazione fallita: {result.message}")
                else:
                    logger.info(f"Ottimizzazione completata con successo per {grade.name}. Costo: {result.total_cost_usd_mt:.4f} USD/mt")
                    # Calcola e stampa prezzi ombra e neutri se non si salva su file
                    if not args.output_file:
                        _print_shadow_prices_table(result)
                        # Calcola prezzi neutri
                        try:
                            analyzer = EconomicAnalyzer(context, result)
                            neutral_prices = analyzer.calculate_neutral_prices()
                            _print_neutral_prices_table(neutral_prices, grade.name)
                        except Exception as analysis_err:
                            logger.error(f"Errore durante il calcolo o la stampa dei prezzi neutri per {grade.name}: {analysis_err}", exc_info=True)

            except OptimizationError as e:
                logger.error(f"Errore durante l'ottimizzazione per {grade.name}: {e}")
                if not args.continue_on_error:
                    raise
                # Ensure a placeholder result is added even on OptimizationError
                all_results.append(OptimizationResultModel(grade_name=grade.name, success=False, message=str(e), component_fractions={}, blend_properties={}, total_cost_usd_mt=-1.0, shadow_prices={}))
                all_attempts[grade.name] = getattr(e, 'attempts', [])
            except Exception as e:
                 logger.error(f"Errore imprevisto durante l'ottimizzazione per {grade.name}: {e}", exc_info=True)
                 if not args.continue_on_error:
                     raise
                 # Ensure a placeholder result is added even on unexpected errors
                 all_results.append(OptimizationResultModel(grade_name=grade.name, success=False, message=f"Errore imprevisto: {e}", component_fractions={}, blend_properties={}, total_cost_usd_mt=-1.0, shadow_prices={}))
                 all_attempts[grade.name] = []

        if args.output_file:
            output_path = Path(args.output_file)
            logger.info(f"Salvataggio risultati in {output_path}")
            # Convert results to list of dicts for saving
            output_data = [res.model_dump(exclude_none=True) for res in all_results]
            # Use pandas for saving to handle different formats easily
            df_output = pd.DataFrame(output_data)
            # Flatten nested dicts if needed for CSV
            if args.format == 'csv':
                # Example: Flatten shadow_prices (adjust as needed)
                df_output = pd.json_normalize(output_data, sep='_')

            _save_dataframe(df_output, output_path, args.format)
        else:
            logger.info("Nessun percorso di output specificato. Stampa riepilogo risultati:")
            # Stampa tabella Rich di riepilogo (già fatto sopra per ogni grade, ma qui per il summary finale)
            _print_optimize_results_table(all_results)
            # Shadow prices are printed per grade during the loop

    except (DataLoadError, OptimizationError) as e:
        logger.error(f"Errore nel comando optimize: {e}")
        console.print(f"[bold red]Errore nel comando optimize:[/bold red] {e}")
    except Exception as e:
        logger.error(f"Errore imprevisto nel comando optimize: {e}", exc_info=True)
        console.print(f"[bold red]Errore imprevisto nel comando optimize:[/bold red] {e}")

def command_eval_candidate(args: argparse.Namespace, config: Config):
    """Esegue il comando eval-candidate."""
    logger.info("Avvio comando eval-candidate...")

    try:
        grades = _load_data_from_source(args, config, "grades", "grades_file", interactive=args.interactive)
        additives = _load_data_from_source(args, config, "additives", "additives_file", interactive=args.interactive) if args.additives_file else []
        # Load components specified for neutral price calculation
        components_for_neutral_price = _load_data_from_source(args, config, "components", "components_for_neutral_price", interactive=args.interactive)
        # Load original components used for optimization (needed for context)
        # Assuming the results file or another source provides this, or add a new argument
        # For now, let's assume results contain enough info or we need the original components file.
        # Let's add a placeholder load for original components, maybe from the optimize command's input?
        # This needs clarification - assuming the results file is sufficient for now or we load the same file again.
        original_components = _load_data_from_source(args, config, "components", "components_for_neutral_price", interactive=args.interactive) # Placeholder - needs correct source
        # candidates_data = _load_data_from_source(args, config, "candidates", "candidates_file", interactive=args.interactive) # No longer needed
        opt_results_list = _load_data_from_source(args, config, "results", "from_results", interactive=args.interactive)

        calculator = PropertyCalculator() # Keep calculator for potential future use?
        # analyzer = EconomicAnalyzer() # Analyzer is instantiated per result
        all_neutral_prices_data = [] # List to store dicts for DataFrame
        optimal_map = {res.grade_name: res for res in opt_results_list if res.success}
        grades_map = {g.name: g for g in grades}

        # Get the names of components for which neutral prices are requested
        target_component_names = {c.name for c in components_for_neutral_price}

        logger.info(f"Calculating neutral prices for {len(target_component_names)} components across {len(optimal_map)} successful optimization results...")

        for grade_name, opt_result in optimal_map.items():
            if grade_name not in grades_map:
                logger.warning(f"Grade 	{grade_name}	 from results file not found in grades file. Skipping neutral price calculation.")
                continue

            grade = grades_map[grade_name]
            logger.info(f"Processing grade: {grade_name}")

            try:
                # Create context using the components specified for neutral price calculation
                # This assumes these components are representative or sufficient for the analyzer
                # Ensure flat_price from args is used if provided, otherwise from config
                current_flat_price = args.flat_price if hasattr(args, 'flat_price') and args.flat_price is not None else config.flat_price
                context = BlendingContext(
                    components=components_for_neutral_price, # Use the components loaded for this purpose
                    grade=grade,
                    available_additives=additives,
                    flat_price=current_flat_price,
                    rvp_exp=config.blending.rvp_exp # Assuming rvp_exp from config is sufficient
                )

                # Instantiate analyzer with the specific context and result
                # EconomicAnalyzer needs the context used for optimization, or be robust enough
                analyzer = EconomicAnalyzer(context, opt_result)

                # Calculate neutral prices for all components available in the context
                neutral_prices = analyzer.calculate_neutral_prices()

                # Filter and store results for the target components
                for comp_name, price in neutral_prices.items():
                    if comp_name in target_component_names:
                        all_neutral_prices_data.append({
                            "grade_name": grade_name,
                            "component_name": comp_name,
                            "neutral_price_usd_mt": price
                        })
                    else:
                        logger.debug(f"Skipping neutral price for component 	{comp_name}	 (not in target list) for grade {grade_name}")

            except Exception as e:
                logger.error(f"Error calculating neutral prices for grade {grade_name}: {e}", exc_info=True)
                # Add error info to output for each target component for this grade
                for comp_name in target_component_names:
                     all_neutral_prices_data.append({
                         "grade_name": grade_name,
                         "component_name": comp_name,
                         "neutral_price_usd_mt": np.nan, # Indicate error
                         "error": str(e)
                     })

        # --- Output Results --- 
        if not all_neutral_prices_data:
            logger.warning("No neutral prices were calculated.")
            console.print("[yellow]Warning: No neutral prices were calculated. Check input files and logs.[/yellow]")
            return # Exit if no data

        results_df = pd.DataFrame(all_neutral_prices_data)

        if args.output:
            output_path = Path(args.output)
            logger.info(f"Saving neutral prices results to {output_path}")
            _save_dataframe(results_df, output_path, args.format)
        else:
            logger.info("Nessun percorso di output specificato. Stampa tabella prezzi neutri aggregata:")
            # Pivot the table for better readability if printed to console
            try:
                pivot_df = results_df.pivot(index='component_name', columns='grade_name', values='neutral_price_usd_mt')
                # Create a Rich table from the pivoted DataFrame
                table = Table(title="Neutral Prices (USD/mt)", show_header=True, header_style="bold magenta")
                table.add_column("Component", style="dim", width=20)
                for col in pivot_df.columns:
                    table.add_column(col, justify="right")
                
                for index, row in pivot_df.iterrows():
                    row_data = [index] + [f"{val:.4f}" if pd.notna(val) else "N/A" for val in row]
                    table.add_row(*row_data)
                console.print(table)
            except Exception as pivot_err:
                 logger.error(f"Could not pivot table for console output: {pivot_err}. Printing raw data.")
                 console.print(results_df) # Print raw data if pivot fails

    except (DataLoadError, TypeError) as e:
        logger.error(f"Errore nel comando eval-candidate: {e}")
        console.print(f"[bold red]Errore nel comando eval-candidate:[/bold red] {e}")
    except Exception as e:
        logger.error(f"Errore imprevisto nel comando eval-candidate: {e}", exc_info=True)
        console.print(f"[bold red]Errore imprevisto nel comando eval-candidate:[/bold red] {e}")

def command_sensitivity(args: argparse.Namespace, config: Config):
    """Esegue il comando sensitivity."""
    logger.info("Avvio comando sensitivity...")

    try:
        base_components = _load_data_from_source(args, config, "components", "components_file", interactive=args.interactive)
        base_grades = _load_data_from_source(args, config, "grades", "grades_file", interactive=args.interactive)
        base_additives = _load_data_from_source(args, config, "additives", "additives_file", interactive=args.interactive) if args.additives_file else []

        results_list = []
        analysis_type = args.analysis_type

        # Filter grades and components if lists are provided
        grades_to_run = [g for g in base_grades if not args.grades_list or g.name in args.grades_list]
        components_to_analyze = [c for c in base_components if not args.components_list or c.name in args.components_list]

        if not grades_to_run:
            logger.warning("Nessun grade selezionato per l'analisi di sensibilità.")
            return
        if not components_to_analyze and analysis_type != "base": # Base case doesn't need component list
             logger.warning("Nessun componente selezionato per l'analisi di sensibilità.")
             return

        # --- Run Base Case Optimization --- 
        base_results_map = {}
        logger.info("--- Esecuzione caso base per analisi di sensibilità ---")
        for grade in grades_to_run:
            try:
                context = BlendingContext(base_components, grade, base_additives, config.flat_price, config.blending.rvp_exp)
                optimizer = Optimizer(context, config.optimizer)
                result, _ = optimizer.optimize()
                base_results_map[grade.name] = result
                if result.success:
                    logger.info(f"Caso base per {grade.name} completato. Costo: {result.total_cost_usd_mt:.4f}")
                else:
                    logger.warning(f"Caso base per {grade.name} fallito: {result.message}")
            except Exception as e:
                logger.error(f"Errore nel caso base per {grade.name}: {e}")
                base_results_map[grade.name] = OptimizationResultModel(grade_name=grade.name, success=False, message=f"Errore caso base: {e}", component_fractions={}, blend_properties={}, total_cost_usd_mt=-1.0, shadow_prices={})

        # --- Run Sensitivity Cases --- 
        param_variations = []
        if analysis_type == "presence":
            param_variations = [(comp.name, 0) for comp in components_to_analyze] # 0 indicates removal
        elif analysis_type == "price":
            delta = args.price_delta
            delta_type = args.delta_type
            direction = args.direction
            for comp in components_to_analyze:
                # Ensure price_differential is treated as float
                base_price_diff = float(comp.price_differential) if comp.price_differential is not None else 0.0
                if delta_type == "percent":
                    change_up = base_price_diff * (1 + delta / 100.0)
                    change_down = base_price_diff * (1 - delta / 100.0)
                else: # absolute
                    change_up = base_price_diff + delta
                    change_down = base_price_diff - delta
                
                if direction in ["up", "both"]:
                    param_variations.append((comp.name, change_up))
                if direction in ["down", "both"]:
                    param_variations.append((comp.name, change_down))
        
        total_runs = len(grades_to_run) * len(param_variations)
        logger.info(f"Avvio {total_runs} run di sensibilità ({len(grades_to_run)} grades x {len(param_variations)} variazioni)... ")

        run_count = 0
        for grade in grades_to_run:
            base_result = base_results_map.get(grade.name)
            base_cost = base_result.total_cost_usd_mt if base_result and base_result.success else None

            for param_name, param_value in param_variations:
                run_count += 1
                logger.info(f"Run {run_count}/{total_runs}: Grade={grade.name}, Param={param_name}, Value={param_value:.4g}")
                
                current_components = copy.deepcopy(base_components)
                current_additives = copy.deepcopy(base_additives)
                
                # Apply variation
                component_found = False
                if analysis_type == "presence":
                    # Remove component
                    current_components = [c for c in current_components if c.name != param_name]
                    component_found = True # Assume it was present initially
                elif analysis_type == "price":
                    for comp in current_components:
                        if comp.name == param_name:
                            comp.price_differential = float(param_value) # Ensure float
                            component_found = True
                            break
                
                if not component_found and analysis_type != "base":
                    logger.warning(f"Componente {param_name} non trovato per applicare variazione. Salto.")
                    continue

                try:
                    context = BlendingContext(current_components, grade, current_additives, config.flat_price, config.blending.rvp_exp)
                    optimizer = Optimizer(context, config.optimizer)
                    result, _ = optimizer.optimize()
                    
                    results_list.append({
                        "param_name": param_name,
                        "param_value": param_value,
                        "grade_name": grade.name,
                        "success": result.success,
                        "cost_usd_mt": result.total_cost_usd_mt if result.success else None,
                        "base_cost_usd_mt": base_cost,
                        "delta_cost_vs_base": (result.total_cost_usd_mt - base_cost) if result.success and base_cost is not None else None,
                        "message": result.message,
                        # Optionally add fractions/properties
                        # "shadow_prices": result.shadow_prices if result.success else None # Could add shadow prices here too
                    })
                except Exception as e:
                    logger.error(f"Errore run sensibilità (Grade={grade.name}, Param={param_name}): {e}")
                    results_list.append({
                        "param_name": param_name,
                        "param_value": param_value,
                        "grade_name": grade.name,
                        "success": False,
                        "message": f"Errore run: {e}",
                    })

        df_results = pd.DataFrame(results_list)

        if args.output_file:
            output_path = Path(args.output_file)
            logger.info(f"Salvataggio risultati sensibilità in {output_path}")
            _save_dataframe(df_results, output_path, args.format)
        else:
            logger.info("Nessun percorso di output specificato. Stampa riepilogo sensibilità:")
            _print_sensitivity_results_table(df_results)

    except (DataLoadError, OptimizationError) as e:
        logger.error(f"Errore nel comando sensitivity: {e}")
        console.print(f"[bold red]Errore nel comando sensitivity:[/bold red] {e}")
    except Exception as e:
        logger.error(f"Errore imprevisto nel comando sensitivity: {e}", exc_info=True)
        console.print(f"[bold red]Errore imprevisto nel comando sensitivity:[/bold red] {e}")

