"""
Fuel Blending - Pacchetto per l'ottimizzazione della miscelazione di carburanti.

Questo pacchetto fornisce strumenti per:
- Ottimizzazione della miscelazione di carburanti
- Analisi economica dei blend
- Analisi di sensibilità
- Integrazione con Google Drive
"""

__version__ = "1.0.0"

# Esporta le classi e funzioni principali per un accesso più semplice
from .utils.exceptions import (
    FuelBlendingError,
    OptimizationError,
    PropertyCalculationError,
    SensitivityAnalysisError,
)
from .utils.logging_setup import setup_logging

# Inizializza il logging di base
setup_logging()
