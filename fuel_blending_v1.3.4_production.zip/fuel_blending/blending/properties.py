"""
Modulo per il calcolo delle proprietà di blending.

Questo modulo definisce la classe PropertyCalculator che implementa
i calcoli delle varie proprietà di blending (RON, MON, RVP, ecc.)
con ottimizzazioni per le prestazioni, inclusa la logica non-lineare
per RON e MON recuperata dalla v5.7.

Include anche il calcolo delle derivate (Jacobiani) rispetto alle frazioni massiche.
Versione 1.2: Fine-tuning per robustezza e logging.
"""

from __future__ import annotations

import inspect as _ins
import warnings
import numpy as np
from numba import njit
from typing import Dict, List, Tuple, Optional, Union, Any
import logging

# Import costanti e eccezioni
from ..utils.constants import (
    PROPERTY_RON, PROPERTY_MON, PROPERTY_RVP, PROPERTY_DENSITY,
    PROPERTY_SULFUR_PPM, PROPERTY_BENZENE, PROPERTY_AROMATICS,
    PROPERTY_OLEFINS, PROPERTY_E150, PROPERTY_E70, PROPERTY_OXY_WT,
    PROPERTY_T50, PROPERTY_MTBE, PROPERTY_RON_AVERAGE
)
from ..utils.exceptions import PropertyCalculationError
from ..models import Component # Import Component per accedere alle proprietà

# --- fix: abilita cache Numba solo se il file NON è in uno zip -------------
_IS_ZIP = ".zip" in (__file__ or "")
_NJIT_CACHE = not _IS_ZIP
# ---------------------------------------------------------------------------

# Sopprime warning di performance di Numba quando la cache è disabilitata
if not _NJIT_CACHE:
    warnings.filterwarnings("ignore", category=UserWarning, module="numba")

# Logger per questo modulo
logger = logging.getLogger(__name__)

# Costante piccola per evitare divisioni per zero o log(0)
EPSILON = 1e-9

# --- Funzioni Numba per calcoli non lineari (da v5.7, con aggiunta EPSILON) ---
@njit(cache=_NJIT_CACHE)
def _ron_to_rl(ron: float, ron_linear_min: Optional[float] = None) -> float:
    """Converte RON in RON lineare."""
    if ron_linear_min is not None and ron < ron_linear_min:
        return ron
    # Limite superiore per evitare overflow in 10**(x)
    if ron / 100.0 > 70: # 10^70 è enorme
        return np.inf
    return 10**(ron / 100.0)

@njit(cache=_NJIT_CACHE)
def _rl_to_ron(rl: float, ron_linear_min: Optional[float] = None) -> float:
    """Converte RON lineare in RON."""
    threshold_rl = np.inf
    if ron_linear_min is not None:
        threshold_rl = _ron_to_rl(ron_linear_min, ron_linear_min)

    if ron_linear_min is not None and rl < threshold_rl:
        return rl

    safe_rl = max(rl, EPSILON)
    # Evita overflow nel log10
    log10_rl = np.log10(safe_rl)
    if log10_rl > 3: # Corrisponde a RON > 300, limite ragionevole
        return np.inf
    return 100.0 * log10_rl

@njit(cache=_NJIT_CACHE)
def _mon_to_ml(mon: float) -> float:
    """Converte MON in MON lineare."""
    if mon / 100.0 > 70:
        return np.inf
    return 10**(mon / 100.0)

@njit(cache=_NJIT_CACHE)
def _ml_to_mon(ml: float) -> float:
    """Converte MON lineare in MON."""
    safe_ml = max(ml, EPSILON)
    log10_ml = np.log10(safe_ml)
    if log10_ml > 3:
        return np.inf
    return 100.0 * log10_ml

@njit(cache=_NJIT_CACHE)
def _calculate_rvp_numba(values: np.ndarray, fractions: np.ndarray, rvp_exp: float) -> float:
    """Implementazione Numba del calcolo della RVP (basato su frazioni volumetriche)."""
    rvp_blend_index = 0.0
    for i in range(len(values)):
        if fractions[i] > EPSILON:
            rvp_i = max(values[i], EPSILON)
            rvp_blend_index += fractions[i] * (rvp_i ** rvp_exp)

    if rvp_blend_index <= EPSILON or rvp_exp == 0:
        return 0.0

    # Evita overflow nella potenza inversa usando logaritmi
    try:
        log_val = (1.0 / rvp_exp) * np.log(rvp_blend_index)
        # Limite superiore per exp() - exp(709) è circa il limite float64
        if log_val > 700:
             return np.inf
        result = np.exp(log_val) # Equivalente a rvp_blend_index ** (1.0 / rvp_exp)
        # Verifica NaN/Inf finale
        if not np.isfinite(result):
            return np.inf # O un altro valore indicativo di errore
        return result
    except: # Cattura potenziali errori matematici in log/exp
        return np.inf # Ritorna Inf in caso di errore numerico

# --------------------------------------------------------

# Define sets of linear properties
_LINEAR_VOLUME_PROPERTIES = {
    PROPERTY_DENSITY, PROPERTY_SULFUR_PPM, PROPERTY_BENZENE,
    PROPERTY_AROMATICS, PROPERTY_OLEFINS, PROPERTY_E150,
    PROPERTY_E70, PROPERTY_T50, PROPERTY_MTBE
}
_LINEAR_MASS_PROPERTIES = {PROPERTY_OXY_WT}

def is_linear_property(property_name: str) -> bool:
    """Verifica se una proprietà blenda linearmente (per massa o volume)."""
    return property_name in _LINEAR_VOLUME_PROPERTIES or property_name in _LINEAR_MASS_PROPERTIES

class PropertyCalculator:
    """
    Calcolatore delle proprietà di blending.
    Include calcoli non-lineari e derivate.
    Versione 1.2: Fine-tuning per robustezza e logging.
    """

    def __init__(self, rvp_exp: float = 1.25, ron_linear_min: Optional[float] = None):
        """Inizializza il calcolatore delle proprietà."""
        self.rvp_exp = rvp_exp
        self.ron_linear_min = ron_linear_min
        self.logger = logging.getLogger(f"{__name__}.PropertyCalculator")
        self.logger.debug(f"PropertyCalculator initialized with rvp_exp={rvp_exp}, ron_linear_min={ron_linear_min}")

    def _mass_to_volume(self, components: List[Component], w: np.ndarray) -> Tuple[np.ndarray, np.ndarray]:
        """Converte le frazioni di massa in frazioni volumetriche (da v5.7).
           Restituisce anche le densità sicure utilizzate.
        """
        densities = np.array([c.density for c in components], dtype=np.float64)
        # Evita divisione per zero se densità è 0
        safe_densities = np.maximum(densities, EPSILON)
        w_over_d = w / safe_densities
        v_sum = np.sum(w_over_d)
        if v_sum < EPSILON:
            # Se la somma è zero (es. w è tutto zero), ritorna zero per evitare NaN
            self.logger.debug("_mass_to_volume: Sum of w/density is near zero, returning zero volumes.")
            return np.zeros_like(w), safe_densities
        v = w_over_d / v_sum
        return v, safe_densities

    def calculate_properties(self, components: List[Component], w: np.ndarray) -> Dict[str, float]:
        """
        Calcola le proprietà del blend in modo vettorizzato (input: frazioni massiche w).
        """
        if not components or len(w) == 0:
            self.logger.error("Calculate_properties called with no components or fractions.")
            raise PropertyCalculationError("Impossibile calcolare: nessun componente o frazione")
        if len(components) != len(w):
             msg = f"Lunghezze diverse: {len(components)} componenti vs {len(w)} frazioni"
             self.logger.error(msg)
             raise PropertyCalculationError(msg)

        # Assicura che w sia un array numpy
        w = np.array(w, dtype=np.float64)
        # Verifica NaN/Inf in input
        if not np.all(np.isfinite(w)):
            self.logger.warning(f"Input fractions contain NaN/Inf: {w}")
            w = np.nan_to_num(w, nan=0.0, posinf=0.0, neginf=0.0) # Sostituisci con 0

        # Normalizza w se necessario (anche se l'ottimizzatore dovrebbe garantirlo)
        w_sum = np.sum(w)
        if abs(w_sum - 1.0) > 1e-6:
            self.logger.warning(f"Input mass fractions sum to {w_sum:.6f}, normalizing to 1.0.")
            if w_sum > EPSILON:
                w = w / w_sum
            else: # Se w è tutto zero, mantienilo zero
                w = np.zeros_like(w)

        # Conversione massa-volume
        v, _ = self._mass_to_volume(components, w)
        if not np.all(np.isfinite(v)):
             self.logger.error(f"Volume fractions calculation resulted in NaN/Inf. Input w: {w}")
             # Potrebbe indicare densità zero o problemi numerici
             # Tentativo di recupero o sollevare errore?
             # Per ora, solleviamo errore per rendere visibile il problema
             raise PropertyCalculationError("Volume fraction calculation resulted in NaN/Inf")

        properties = {}
        component_props_cache = {} # Cache locale per i valori delle proprietà

        def get_prop_values(prop_name: str) -> np.ndarray:
            if prop_name not in component_props_cache:
                try:
                    # Modifica: Accedi tramite dizionario properties
                    values = np.array([c.properties.get(prop_name, 0.0) for c in components], dtype=np.float64)
                    if not np.all(np.isfinite(values)):
                         self.logger.warning(f"Component values for property \'{prop_name}\' "
                                            "contain NaN/Inf. Replacing with 0.")
                         values = np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)
                    component_props_cache[prop_name] = values
                except AttributeError:
                    self.logger.error(f"AttributeError getting property \'{prop_name}\' from components.")
                    raise PropertyCalculationError(f"Errore nell'accesso alla proprietà \'{prop_name}\'")
            return component_props_cache[prop_name]

        try:
            # Proprietà che blendano linearmente per VOLUME (calcolate usando v)
            for prop in _LINEAR_VOLUME_PROPERTIES:
                values = get_prop_values(prop)
                properties[prop] = np.sum(v * values)

            # Proprietà che blendano linearmente per MASSA (calcolate usando w)
            for prop in _LINEAR_MASS_PROPERTIES:
                values = get_prop_values(prop)
                properties[prop] = np.sum(w * values)

            # Proprietà non lineari (basate su volume v)
            # RON
            ron_values = get_prop_values(PROPERTY_RON)
            ron_linear_values = np.array([_ron_to_rl(r, self.ron_linear_min) for r in ron_values])
            ron_linear_blend = np.sum(v * ron_linear_values)
            properties[PROPERTY_RON] = _rl_to_ron(ron_linear_blend, self.ron_linear_min)
            properties[PROPERTY_RON_AVERAGE] = properties[PROPERTY_RON] # Stesso valore

            # MON
            mon_values = get_prop_values(PROPERTY_MON)
            mon_linear_values = np.array([_mon_to_ml(m) for m in mon_values])
            mon_linear_blend = np.sum(v * mon_linear_values)
            properties[PROPERTY_MON] = _ml_to_mon(mon_linear_blend)

            # RVP
            rvp_values = get_prop_values(PROPERTY_RVP)
            properties[PROPERTY_RVP] = _calculate_rvp_numba(rvp_values, v, self.rvp_exp)

            # Verifica finale NaN/Inf nei risultati
            for prop, value in properties.items():
                if not np.isfinite(value):
                    self.logger.error(f"Calculation for property \'{prop}\' resulted in NaN/Inf. Value: {value}")
                    # Sostituisci con un valore grande per segnalare problema all'ottimizzatore
                    properties[prop] = np.inf if value > 0 else -np.inf
                    # O solleva eccezione:
                    # raise PropertyCalculationError(f"Calculation for property \'{prop}\' resulted in NaN/Inf")

        except Exception as e:
            self.logger.error(f"Unexpected error during property calculation: {e}", exc_info=True)
            raise PropertyCalculationError(f"Errore inaspettato nel calcolo delle proprietà: {e}")

        return properties

    # --- Calcolo Derivate (Jacobiani) --- 

    @staticmethod
    @njit(cache=_NJIT_CACHE)
    def _calculate_dv_dw(v: np.ndarray, densities: np.ndarray, w: np.ndarray) -> np.ndarray:
        """Calcola le derivate dv_i / dw_j (logica da v5.7 adattata)."""
        n = len(v)
        dv_dw = np.zeros((n, n))
        # Densità già verificate in _mass_to_volume, qui usiamo quelle sicure
        inv_densities = 1.0 / densities # densities sono già safe_densities

        # Calcola Sum(w_k / d_k)
        w_over_d = w * inv_densities
        sum_w_over_d = np.sum(w_over_d)

        if sum_w_over_d < EPSILON:
            # logger.debug("_calculate_dv_dw: Sum of w/density is near zero, returning zero Jacobian.") # Non si può loggare da Numba
            return dv_dw # Se somma è zero, derivate sono zero

        inv_sum_w_over_d = 1.0 / sum_w_over_d

        # Formula: dv_i / dw_j = [delta_ij / d_i - v_i * (1/d_j)] / Sum(w_k/d_k)
        for i in range(n):
            term_vi_inv_sum = v[i] * inv_sum_w_over_d
            for j in range(n):
                delta_ij = 1.0 if i == j else 0.0
                dv_dw[i, j] = (delta_ij * inv_densities[i] - term_vi_inv_sum * inv_densities[j])
                # La divisione per Sum(w_k/d_k) è già in term_vi_inv_sum e nel delta_ij term?
                # Rivediamo: dv_i / dw_j = [delta_ij / d_i - v_i * (1/d_j)] * inv_sum_w_over_d
                dv_dw[i, j] = (delta_ij * inv_densities[i] - v[i] * inv_densities[j]) * inv_sum_w_over_d
        return dv_dw

    def calculate_property_derivatives(self, components: List[Component], w: np.ndarray) -> Dict[str, np.ndarray]:
        """
        Calcola le derivate delle proprietà rispetto alle frazioni di massa (w).
        Adattato da v5.7 e fine-tuned per v1.2.
        """
        n = len(components)
        if n == 0 or len(w) != n:
            self.logger.error("Calculate_property_derivatives called with invalid input size.")
            return {} # Ritorna dizionario vuoto

        w = np.array(w, dtype=np.float64)
        # Verifica NaN/Inf in input
        if not np.all(np.isfinite(w)):
            self.logger.warning(f"Input fractions for derivatives contain NaN/Inf: {w}. Replacing with 0.")
            w = np.nan_to_num(w, nan=0.0, posinf=0.0, neginf=0.0)

        # Normalizza w se necessario (coerente con calculate_properties)
        w_sum = np.sum(w)
        if abs(w_sum - 1.0) > 1e-6:
            self.logger.warning(f"Input mass fractions sum to {w_sum:.6f} in derivatives, normalizing.")
            if w_sum > EPSILON:
                w = w / w_sum
            else:
                w = np.zeros_like(w)

        v, safe_densities = self._mass_to_volume(components, w)
        if not np.all(np.isfinite(v)):
             self.logger.error(f"Volume fractions calculation resulted in NaN/Inf during derivative calculation. Input w: {w}")
             raise PropertyCalculationError("Volume fraction calculation resulted in NaN/Inf in derivatives")

        dv_dw = self._calculate_dv_dw(v, safe_densities, w)
        if not np.all(np.isfinite(dv_dw)):
             self.logger.error(f"dv/dw calculation resulted in NaN/Inf. Input w: {w}, v: {v}")
             raise PropertyCalculationError("dv/dw calculation resulted in NaN/Inf")

        derivatives: Dict[str, np.ndarray] = {}
        component_props_cache = {} # Cache locale

        def get_prop_values(prop_name: str) -> np.ndarray:
            # Usa la stessa logica di calculate_properties per coerenza
            if prop_name not in component_props_cache:
                try:
                    # Modifica: Accedi tramite dizionario properties
                    values = np.array([c.properties.get(prop_name, 0.0) for c in components], dtype=np.float64)
                    if not np.all(np.isfinite(values)):
                         self.logger.warning(f"Component values for property \'{prop_name}\' (derivatives) contain NaN/Inf. Replacing with 0.")
                         values = np.nan_to_num(values, nan=0.0, posinf=0.0, neginf=0.0)
                    component_props_cache[prop_name] = values
                except AttributeError:
                    self.logger.error(f"AttributeError getting property \'{prop_name}\' for derivatives.")
                    raise PropertyCalculationError(f"Errore nell'accesso alla proprietà \'{prop_name}\' per derivate")
            return component_props_cache[prop_name]

        try:
            # 1. Proprietà lineari per MASSA (derivata è costante)
            for prop in _LINEAR_MASS_PROPERTIES:
                values = get_prop_values(prop)
                derivatives[prop] = values # d(Sum w_i*P_i)/dw_j = P_j

            # 2. Proprietà lineari per VOLUME (richiedono dv/dw)
            for prop in _LINEAR_VOLUME_PROPERTIES:
                values = get_prop_values(prop)
                # d(Sum v_i*P_i)/dw_j = Sum_i (dv_i/dw_j * P_i)
                derivatives[prop] = np.dot(dv_dw.T, values) # Transpose dv_dw to sum over i

            # 3. Proprietà non lineari (RON, MON, RVP)
            # RON
            ron_values = get_prop_values(PROPERTY_RON)
            ron_linear_values = np.array([_ron_to_rl(r, self.ron_linear_min) for r in ron_values])
            ron_linear_blend = np.sum(v * ron_linear_values)
            dRL_dv = ron_linear_values
            dRL_dw = np.dot(dv_dw.T, dRL_dv)
            # dRON/dRL = 100 / (RL * ln(10))
            safe_ron_linear_blend = max(ron_linear_blend, EPSILON)
            dRON_dRL = 100.0 / (safe_ron_linear_blend * np.log(10))
            # Gestione caso lineare sotto soglia
            if self.ron_linear_min is not None:
                threshold_rl = _ron_to_rl(self.ron_linear_min, self.ron_linear_min)
                if ron_linear_blend < threshold_rl:
                    dRON_dRL = 1.0 # Derivata è 1 nella zona lineare
            derivatives[PROPERTY_RON] = dRL_dw * dRON_dRL
            derivatives[PROPERTY_RON_AVERAGE] = derivatives[PROPERTY_RON] # Stessa derivata

            # MON
            mon_values = get_prop_values(PROPERTY_MON)
            mon_linear_values = np.array([_mon_to_ml(m) for m in mon_values])
            mon_linear_blend = np.sum(v * mon_linear_values)
            dML_dv = mon_linear_values
            dML_dw = np.dot(dv_dw.T, dML_dv)
            # dMON/dML = 100 / (ML * ln(10))
            safe_mon_linear_blend = max(mon_linear_blend, EPSILON)
            dMON_dML = 100.0 / (safe_mon_linear_blend * np.log(10))
            derivatives[PROPERTY_MON] = dML_dw * dMON_dML

            # RVP
            rvp_values = get_prop_values(PROPERTY_RVP)
            rvp_blend_index = 0.0
            for i in range(n):
                if v[i] > EPSILON:
                    rvp_i = max(rvp_values[i], EPSILON)
                    rvp_blend_index += v[i] * (rvp_i ** self.rvp_exp)
            
            safe_rvp_blend_index = max(rvp_blend_index, EPSILON)
            rvp_blend = safe_rvp_blend_index ** (1.0 / self.rvp_exp)
            
            # dRVP/dRVP_index = (1/exp) * RVP_index^(1/exp - 1)
            #                 = (1/exp) * RVP / RVP_index
            if self.rvp_exp == 0:
                 dRVP_dRVPidx = 0.0 # Evita divisione per zero
            else:
                 dRVP_dRVPidx = (1.0 / self.rvp_exp) * rvp_blend / safe_rvp_blend_index
            
            # dRVP_index / dv_i = RVP_i^exp
            dRVPidx_dv = np.array([max(r, EPSILON)**self.rvp_exp for r in rvp_values])
            
            # dRVP_index / dw_j = Sum_i (dRVP_index/dv_i * dv_i/dw_j)
            dRVPidx_dw = np.dot(dv_dw.T, dRVPidx_dv)
            
            derivatives[PROPERTY_RVP] = dRVPidx_dw * dRVP_dRVPidx

            # Verifica finale NaN/Inf nei risultati delle derivate
            for prop, jac in derivatives.items():
                if not np.all(np.isfinite(jac)):
                    self.logger.error(f"Derivative calculation for property \'{prop}\' resulted in NaN/Inf. Jacobian: {jac}")
                    # Sostituisci con zero per evitare problemi al solver
                    derivatives[prop] = np.nan_to_num(jac, nan=0.0, posinf=0.0, neginf=0.0)
                    # O solleva eccezione:
                    # raise PropertyCalculationError(f"Derivative calculation for property \'{prop}\' resulted in NaN/Inf")

        except Exception as e:
            self.logger.error(f"Unexpected error during derivative calculation: {e}", exc_info=True)
            raise PropertyCalculationError(f"Errore inaspettato nel calcolo delle derivate: {e}")

        return derivatives

    def calculate_property(self, property_name: str, component_values: np.ndarray, fractions: np.ndarray) -> float:
        """
        Calcola il valore di una singola proprietà del blend.
        Questo metodo è meno efficiente di calculate_properties ma può essere utile.
        Assume che le frazioni siano già del tipo corretto (massa o volume) per la proprietà.
        """
        if len(component_values) != len(fractions):
            raise ValueError("Lunghezze diverse per valori componenti e frazioni")

        if property_name in _LINEAR_MASS_PROPERTIES or property_name in _LINEAR_VOLUME_PROPERTIES:
            return np.sum(fractions * component_values)
        elif property_name == PROPERTY_RON or property_name == PROPERTY_RON_AVERAGE:
            ron_linear_values = np.array([_ron_to_rl(r, self.ron_linear_min) for r in component_values])
            ron_linear_blend = np.sum(fractions * ron_linear_values)
            return _rl_to_ron(ron_linear_blend, self.ron_linear_min)
        elif property_name == PROPERTY_MON:
            mon_linear_values = np.array([_mon_to_ml(m) for m in component_values])
            mon_linear_blend = np.sum(fractions * mon_linear_values)
            return _ml_to_mon(mon_linear_blend)
        elif property_name == PROPERTY_RVP:
            # Assume fractions sono volumetriche per RVP
            return _calculate_rvp_numba(component_values, fractions, self.rvp_exp)
        else:
            self.logger.warning(f"Calcolo per proprietà sconosciuta o non gestita singolarmente: {property_name}. Assumendo blending lineare.")
            return np.sum(fractions * component_values)

    def calculate_property_jacobian(self, property_name: str, component_values: np.ndarray, fractions: np.ndarray) -> np.ndarray:
        """
        Calcola il Jacobiano di una singola proprietà rispetto alle frazioni.
        Meno efficiente di calculate_property_derivatives.
        Assume che le frazioni siano del tipo corretto (massa o volume) e che le derivate
        siano rispetto a quel tipo di frazione (non gestisce la conversione dv/dw qui).
        """
        n = len(fractions)
        if len(component_values) != n:
            raise ValueError("Lunghezze diverse per valori componenti e frazioni")

        if property_name in _LINEAR_MASS_PROPERTIES or property_name in _LINEAR_VOLUME_PROPERTIES:
            return component_values
        elif property_name == PROPERTY_RON or property_name == PROPERTY_RON_AVERAGE:
            ron_linear_values = np.array([_ron_to_rl(r, self.ron_linear_min) for r in component_values])
            ron_linear_blend = np.sum(fractions * ron_linear_values)
            dRL_df = ron_linear_values # Derivata rispetto alla frazione (volumetrica)
            safe_ron_linear_blend = max(ron_linear_blend, EPSILON)
            dRON_dRL = 100.0 / (safe_ron_linear_blend * np.log(10))
            if self.ron_linear_min is not None:
                threshold_rl = _ron_to_rl(self.ron_linear_min, self.ron_linear_min)
                if ron_linear_blend < threshold_rl:
                    dRON_dRL = 1.0
            return dRL_df * dRON_dRL
        elif property_name == PROPERTY_MON:
            mon_linear_values = np.array([_mon_to_ml(m) for m in component_values])
            mon_linear_blend = np.sum(fractions * mon_linear_values)
            dML_df = mon_linear_values
            safe_mon_linear_blend = max(mon_linear_blend, EPSILON)
            dMON_dML = 100.0 / (safe_mon_linear_blend * np.log(10))
            return dML_df * dMON_dML
        elif property_name == PROPERTY_RVP:
            # Assume fractions sono volumetriche
            rvp_blend_index = 0.0
            for i in range(n):
                if fractions[i] > EPSILON:
                    rvp_i = max(component_values[i], EPSILON)
                    rvp_blend_index += fractions[i] * (rvp_i ** self.rvp_exp)
            
            safe_rvp_blend_index = max(rvp_blend_index, EPSILON)
            rvp_blend = safe_rvp_blend_index ** (1.0 / self.rvp_exp)
            
            if self.rvp_exp == 0:
                 dRVP_dRVPidx = 0.0
            else:
                 dRVP_dRVPidx = (1.0 / self.rvp_exp) * rvp_blend / safe_rvp_blend_index
            
            dRVPidx_df = np.array([max(r, EPSILON)**self.rvp_exp for r in component_values])
            return dRVPidx_df * dRVP_dRVPidx
        else:
            self.logger.warning(f"Jacobiano per proprietà sconosciuta: {property_name}. Assumendo lineare.")
            return component_values

