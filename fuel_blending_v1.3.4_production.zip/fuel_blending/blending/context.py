"""
Modulo per la gestione del contesto di blending.

Questo modulo definisce la classe BlendingContext che rappresenta il contesto
completo per un'operazione di blending, inclusi componenti, grade target,
additivi e altri parametri.

Include la logica di validazione per verificare la coerenza dei dati di input.
Versione 1.3.0: Fine-tuning finale, incl. uso densità base grade per costo blend escalato
             e implementazione Jacobiano analitico costo totale.
"""

from __future__ import annotations

import logging
import numpy as np
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Union, Tuple, Callable

from ..models.models import (
    Component, Grade,
    DELTA_TYPE_AS_IS, DELTA_TYPE_FACTOR, DELTA_TYPE_ESCALATED,
    PRICE_MODE_AS_IS, PRICE_MODE_ESCALATED
)
from ..utils.exceptions import ConfigurationError, PropertyCalculationError
from ..utils.constants import PROPERTY_DENSITY # Importa la costante per la densità

# Logger per questo modulo
logger = logging.getLogger(__name__)

# Costante piccola per evitare divisioni per zero
EPSILON = 1e-9

# Valore di default per la densità base di escalation se non specificato altrove
DEFAULT_BASE_DENSITY_ESCALATION = 755.0

@dataclass
class BlendingContext:
    """
    Contesto per l'ottimizzazione del blending.

    Contiene tutti i dati necessari per definire un problema di blending:
    componenti disponibili, grade target, additivi, prezzi, ecc.
    Include la validazione post-inizializzazione.

    Attributes:
        components: Lista dei componenti disponibili.
        grade: Il grade target.
        additives: Dizionario degli additivi disponibili {nome: quantità}.
        flat_price: Prezzo base per il calcolo dei costi (USD/mt).
        base_density_escalation_default: Densità base di escalation globale di default.
        rvp_exp: Esponente per il calcolo della RVP.
        fixed_components: Componenti con frazione massica fissa {nome: frazione}.
        hc_mass: Massa di idrocarburi liberi (calcolata se non fornita).
        _component_costs: Cache per i costi componenti calcolati (USD/mt).
    """
    components: List[Component]
    grade: Grade
    available_additives: List[Additive] = field(default_factory=list)
    flat_price: float = 700.0
    base_density_escalation_default: float = DEFAULT_BASE_DENSITY_ESCALATION
    rvp_exp: float = 1.25
    fixed_components: Dict[str, float] = field(default_factory=dict)
    hc_mass: float = 1.0
    _component_costs: Optional[np.ndarray] = field(init=False, default=None)

    def __post_init__(self):
        """Esegue la validazione dopo l'inizializzazione della dataclass."""
        self._validate()
        # Pre-calcola e valida i costi dei componenti
        self._calculate_and_validate_component_costs()

    def _validate(self):
        """Valida la coerenza del contesto (logica adattata da v5.7)."""
        logger.debug(f"Validating BlendingContext for grade '{self.grade.name}'...")
        component_names = {c.name for c in self.components}
        fixed_component_names = set(self.fixed_components.keys())

        # Verifica che i componenti fissi esistano nella lista dei componenti
        missing_fixed = fixed_component_names - component_names
        if missing_fixed:
            logger.warning(f"I seguenti componenti fissi non sono presenti nella lista dei componenti: {missing_fixed}")
            # Rimuovi i componenti fissi mancanti per evitare errori successivi
            for name in missing_fixed:
                del self.fixed_components[name]

        # Verifica che la somma dei componenti fissi non superi 1 (usando solo quelli validi)
        valid_fixed_sum = sum(self.fixed_components.values())
        if valid_fixed_sum > 1.0 + 1e-6: # Aggiunta tolleranza
            logger.warning(f"La somma delle frazioni dei componenti fissi ({valid_fixed_sum:.4f}) supera 1.0")

        # Verifica che hc_mass sia coerente con i componenti fissi
        expected_hc_mass = 1.0 - valid_fixed_sum
        if abs(self.hc_mass - expected_hc_mass) > 1e-6:
            logger.warning(f"hc_mass fornito ({self.hc_mass:.4f}) non è coerente con i componenti fissi (atteso: {expected_hc_mass:.4f}). Aggiornamento di hc_mass.")
            # Correggi hc_mass per coerenza
            self.hc_mass = max(0.0, expected_hc_mass) # Assicura che non sia negativo

        # Verifica che gli additivi specificati nel grade esistano nel contesto
        grade_required_additives = set(self.grade.additives.keys())
        available_additive_names = {a.name for a in self.available_additives}
        missing_grade_additives = grade_required_additives - available_additive_names
        if missing_grade_additives:
             logger.warning(f"I seguenti additivi richiesti dal grade '{self.grade.name}' non sono disponibili nel contesto: {missing_grade_additives}")

        # Verifica che l'etanolo sia presente se force_ethanol è abilitato
        if self.grade.force_ethanol and self.grade.force_ethanol.enabled:
            ethanol_component = next((c for c in self.components if c.is_ethanol), None)
            if ethanol_component is None:
                logger.warning(f"force_ethanol è abilitato per il grade '{self.grade.name}', ma nessun componente è marcato come is_ethanol=True")
            elif ethanol_component.name not in self.fixed_components:
                logger.warning(f"force_ethanol è abilitato per il grade '{self.grade.name}', ma l'etanolo ('{ethanol_component.name}') non è tra i componenti fissi.")
            elif abs(self.fixed_components[ethanol_component.name] - self.grade.force_ethanol.mass_frac) > 1e-6:
                logger.warning(f"force_ethanol è abilitato per il grade '{self.grade.name}', ma la frazione fissa dell'etanolo ({self.fixed_components[ethanol_component.name]:.4f}) non corrisponde a quella specificata nel grade ({self.grade.force_ethanol.mass_frac:.4f})")
        logger.debug("BlendingContext validation complete.")

    def _calculate_and_validate_component_costs(self) -> None:
        """Calcola i costi dei componenti in base al delta_type, usando la densità base corretta per l'escalation."""
        costs = []
        for i, comp in enumerate(self.components):
            cost = 0.0
            try:
                if comp.delta_type == DELTA_TYPE_AS_IS:
                    if comp.delta_value is None:
                        raise ConfigurationError(f"Componente '{comp.name}' (indice {i}) è 'as_is' ma manca 'delta_value'.")
                    cost = self.flat_price + comp.delta_value
                elif comp.delta_type == DELTA_TYPE_FACTOR:
                    if comp.multiplier is None:
                        raise ConfigurationError(f"Componente '{comp.name}' (indice {i}) è 'factor' ma manca 'multiplier'.")
                    cost = self.flat_price * comp.multiplier
                elif comp.delta_type == DELTA_TYPE_ESCALATED:
                    if comp.delta_value is None:
                        raise ConfigurationError(f"Componente '{comp.name}' (indice {i}) è 'escalated' ma manca 'delta_value'.")
                    if comp.density < EPSILON:
                        logger.warning(f"Componente '{comp.name}' (indice {i}) ha densità vicina a zero ({comp.density}), impossibile calcolare costo escalato. Costo impostato a infinito.")
                        cost = np.inf
                    else:
                        # Determina la densità base da usare secondo la gerarchia
                        base_density_to_use = None
                        source = "unknown"
                        if comp.base_density_component is not None:
                            base_density_to_use = comp.base_density_component
                            source = "component"
                        elif self.grade.base_density_escalation is not None:
                            base_density_to_use = self.grade.base_density_escalation
                            source = "grade"
                        else:
                            base_density_to_use = self.base_density_escalation_default
                            source = "default"
                            logger.debug(f"Usando densità base di escalation di default ({base_density_to_use}) per componente '{comp.name}'.")

                        if base_density_to_use is None or base_density_to_use < EPSILON:
                             logger.warning(f"Densità base di escalation non valida ({base_density_to_use} da {source}) per componente '{comp.name}'. Costo impostato a infinito.")
                             cost = np.inf
                        else:
                            # Formula di escalation
                            cost = (self.flat_price + comp.delta_value) * (base_density_to_use / comp.density)
                            logger.debug(f"Costo escalato per '{comp.name}': ({self.flat_price} + {comp.delta_value}) * ({base_density_to_use} [{source}] / {comp.density}) = {cost:.2f}")
                else:
                    raise ConfigurationError(f"Tipo delta non valido '{comp.delta_type}' per componente '{comp.name}' (indice {i}).")

                # Verifica costi non finiti
                if not np.isfinite(cost):
                    logger.warning(f"Costo calcolato per componente '{comp.name}' (indice {i}) non è finito ({cost}). Impostato a infinito.")
                    cost = np.inf

                costs.append(cost)

            except ConfigurationError as e:
                logger.error(f"Errore di configurazione nel calcolo costo componente: {e}")
                raise # Rilancia l'errore
            except Exception as e:
                logger.error(f"Errore imprevisto nel calcolo costo per componente '{comp.name}' (indice {i}): {e}", exc_info=True)
                costs.append(np.inf) # Imposta a infinito in caso di errore imprevisto

        self._component_costs = np.array(costs)
        logger.debug(f"Costi componenti finali calcolati: {self._component_costs}")

    @classmethod
    def from_components(
        cls,
        components: List[Component],
        grade: Grade,
        *,
        flat_price: float = 700.0,
        base_density_escalation_default: float = DEFAULT_BASE_DENSITY_ESCALATION, # Rinominato per chiarezza
        available_additives: Optional[List[Additive]] = None,
        rvp_exp: float = 1.25,
        fixed_components: Optional[Dict[str, float]] = None,
        hc_mass: Optional[float] = None
    ) -> BlendingContext:
        """
        Factory method per creare un contesto di blending dai componenti.
        Calcola hc_mass automaticamente se non fornito.

        Args:
            components: Lista dei componenti disponibili.
            grade: Grade target.
            flat_price: Prezzo base per il calcolo dei costi.
            base_density_escalation_default: Densità base di escalation globale di default.
            additives: Dizionario degli additivi disponibili (nome -> quantità).
            rvp_exp: Esponente per il calcolo della RVP.
            fixed_components: Componenti con frazione fissa (nome -> frazione).
            hc_mass: Massa di idrocarburi (opzionale, calcolata se None).

        Returns:
            Un nuovo contesto di blending validato.
        """
        fixed_components_dict = fixed_components or {}

        # Calcola hc_mass se non fornito
        calculated_hc_mass = 1.0 - sum(fixed_components_dict.values())
        if hc_mass is None:
            hc_mass_to_use = max(0.0, calculated_hc_mass)
            logger.info(f"hc_mass non fornito, calcolato automaticamente a: {hc_mass_to_use:.4f}")
        else:
            hc_mass_to_use = hc_mass

        # Crea l'istanza (la validazione e il calcolo costi avverranno in __post_init__)
        return cls(
            components=components,
            grade=grade,
            available_additives=available_additives or [],
            flat_price=flat_price,
            base_density_escalation_default=base_density_escalation_default,
            rvp_exp=rvp_exp,
            fixed_components=fixed_components_dict,
            hc_mass=hc_mass_to_use
        )

    def get_component_by_name(self, name: str) -> Optional[Component]:
        """Trova un componente per nome."""
        for component in self.components:
            if component.name == name:
                return component
        return None

    def get_components_without(self, excluded_component: str) -> List[Component]:
        """Restituisce una lista di componenti escludendo quello specificato."""
        return [c for c in self.components if c.name != excluded_component]

    # --- Metodi aggiunti per l'ottimizzatore ---

    def get_component_indices(self) -> Dict[str, int]:
        """Restituisce un dizionario nome_componente -> indice."""
        return {comp.name: i for i, comp in enumerate(self.components)}

    @property
    def free_indices(self) -> List[int]:
        """Indici dei componenti con frazione libera."""
        component_indices = self.get_component_indices()
        fixed_names = set(self.fixed_components.keys())
        return [idx for name, idx in component_indices.items() if name not in fixed_names]

    @property
    def fixed_indices_map(self) -> Dict[int, float]:
        """Mappa indice_componente_fisso -> frazione_fissa."""
        component_indices = self.get_component_indices()
        return {component_indices[name]: frac for name, frac in self.fixed_components.items() if name in component_indices}

    def reconstruct_fractions(self, free_fractions: np.ndarray) -> np.ndarray:
        """Ricostruisce l'array completo delle frazioni dai componenti liberi."""
        n_components = len(self.components)
        all_fractions = np.zeros(n_components)

        fixed_map = self.fixed_indices_map
        free_idxs = self.free_indices

        if len(free_fractions) != len(free_idxs):
             raise ValueError(f"Numero di frazioni libere ({len(free_fractions)}) non corrisponde agli indici liberi ({len(free_idxs)})")

        all_fractions[free_idxs] = free_fractions
        for idx, frac in fixed_map.items():
            all_fractions[idx] = frac

        return all_fractions

    def get_component_costs(self) -> np.ndarray:
        """Restituisce l'array dei costi dei componenti pre-calcolati (USD/mt)."""
        if self._component_costs is None:
            logger.error("Tentativo di accedere ai costi componenti prima del calcolo.")
            # Ritorna array di Inf per segnalare errore grave
            return np.full(len(self.components), np.inf)

        return self._component_costs

    def calculate_total_cost(
        self,
        all_fractions: np.ndarray,
        blend_properties: Optional[Dict[str, float]] = None
    ) -> float:
        """
        Calcola il costo totale del blend (USD/mt).

        Se il price_mode del grade è 'escalated', il costo viene calcolato
        usando la densità del blend fornita in blend_properties e la densità base
        specifica del grade (se disponibile) o quella di default.
        Altrimenti, viene calcolato come somma pesata dei costi componenti.

        Args:
            all_fractions: Array completo delle frazioni di massa dei componenti.
            blend_properties: Dizionario delle proprietà calcolate del blend.
                              Necessario solo se price_mode è 'escalated'.

        Returns:
            Costo totale del blend (USD/mt).
        """
        if self.grade.price_mode == PRICE_MODE_ESCALATED:
            if blend_properties is None or PROPERTY_DENSITY not in blend_properties:
                logger.error(f"Il calcolo del costo totale per il grade '{self.grade.name}' con price_mode='escalated' richiede la densità del blend, che non è stata fornita.")
                return np.inf

            blend_density = blend_properties[PROPERTY_DENSITY]
            if blend_density < EPSILON:
                logger.warning(f"Densità del blend ({blend_density:.4f}) è vicina a zero, impossibile calcolare costo totale escalato. Costo impostato a infinito.")
                return np.inf

            # Usa la densità base del grade se disponibile, altrimenti quella di default
            base_density = self.grade.base_density_escalation
            source = "grade"
            if base_density is None or base_density < EPSILON:
                base_density = self.base_density_escalation_default
                source = "default"
                logger.debug(f"Usando densità base di escalation di default ({base_density}) per calcolo costo blend escalato (grade '{self.grade.name}').")

            if base_density < EPSILON:
                 logger.warning(f"Densità base di escalation ({base_density} da {source}) non è valida per calcolo costo blend escalato. Costo impostato a infinito.")
                 return np.inf

            blend_cost = self.flat_price * (base_density / blend_density)
            logger.debug(f"Costo totale blend (escalated): {self.flat_price} * ({base_density} [{source}] / {blend_density:.4f}) = {blend_cost:.2f}")

        elif self.grade.price_mode == PRICE_MODE_AS_IS:
            component_costs = self.get_component_costs()
            if not np.all(np.isfinite(component_costs)):
                 logger.error("Costi componenti contengono valori non finiti, impossibile calcolare costo totale.")
                 return np.inf # Ritorna infinito se i costi non sono validi
            blend_cost = np.dot(all_fractions, component_costs)
            logger.debug(f"Costo totale blend (as_is): Somma pesata = {blend_cost:.2f}")
        else:
            logger.warning(f"Modalità di prezzo '{self.grade.price_mode}' non riconosciuta per il grade '{self.grade.name}'. Calcolo costo come 'as_is'.")
            component_costs = self.get_component_costs()
            if not np.all(np.isfinite(component_costs)):
                 logger.error("Costi componenti contengono valori non finiti, impossibile calcolare costo totale.")
                 return np.inf
            blend_cost = np.dot(all_fractions, component_costs)

        # TODO: Aggiungere costo additivi se necessario

        return blend_cost

    def calculate_total_cost_jacobian(
        self,
        all_fractions: np.ndarray,
        blend_properties: Optional[Dict[str, float]] = None,
        property_derivatives: Optional[Dict[str, np.ndarray]] = None
    ) -> Optional[np.ndarray]:
        """
        Calcola il Jacobiano (gradiente) del costo totale del blend rispetto alle frazioni di massa.

        Args:
            all_fractions: Array completo delle frazioni di massa dei componenti.
            blend_properties: Dizionario delle proprietà calcolate del blend (necessario per 'escalated').
            property_derivatives: Dizionario delle derivate delle proprietà (necessario per 'escalated').

        Returns:
            np.ndarray: Gradiente del costo totale rispetto alle frazioni di massa, o None se non calcolabile.
        """
        n_components = len(self.components)
        if len(all_fractions) != n_components:
            logger.error("Dimensione frazioni non corretta per Jacobiano costo totale.")
            return None

        if self.grade.price_mode == PRICE_MODE_ESCALATED:
            if blend_properties is None or PROPERTY_DENSITY not in blend_properties:
                logger.error(f"Jacobiano costo totale (escalated) richiede densità blend.")
                return None
            if property_derivatives is None or PROPERTY_DENSITY not in property_derivatives:
                logger.error(f"Jacobiano costo totale (escalated) richiede derivate densità.")
                return None

            blend_density = blend_properties[PROPERTY_DENSITY]
            if blend_density < EPSILON:
                logger.warning(f"Densità blend vicina a zero ({blend_density:.4f}), impossibile calcolare Jacobiano costo escalato.")
                return np.full(n_components, np.nan) # Ritorna NaN per indicare problema

            # Usa la stessa logica di calculate_total_cost per la densità base
            base_density = self.grade.base_density_escalation
            source = "grade"
            if base_density is None or base_density < EPSILON:
                base_density = self.base_density_escalation_default
                source = "default"

            if base_density < EPSILON:
                 logger.warning(f"Densità base ({base_density} da {source}) non valida per Jacobiano costo escalato.")
                 return np.full(n_components, np.nan)

            # Derivata del costo rispetto alla densità
            d_cost_d_density = -self.flat_price * base_density / (blend_density ** 2)

            # Derivate della densità rispetto alle frazioni di massa
            d_density_dw = property_derivatives[PROPERTY_DENSITY]
            if d_density_dw is None or len(d_density_dw) != n_components:
                 logger.error("Derivate densità non valide per Jacobiano costo escalato.")
                 return None
            if not np.all(np.isfinite(d_density_dw)):
                 logger.warning("Derivate densità contengono NaN/Inf, Jacobiano costo escalato potrebbe essere inaffidabile.")
                 # Non ritorniamo NaN qui, lasciamo che il calcolo proceda

            # Jacobiano del costo totale (chain rule)
            cost_jacobian = d_cost_d_density * d_density_dw
            logger.debug(f"Jacobiano costo totale (escalated, base_dens={base_density} [{source}]): {cost_jacobian}")
            return cost_jacobian

        elif self.grade.price_mode == PRICE_MODE_AS_IS:
            # Il Jacobiano è semplicemente l'array dei costi componenti
            component_costs = self.get_component_costs()
            if not np.all(np.isfinite(component_costs)):
                 logger.error("Costi componenti non finiti, impossibile calcolare Jacobiano costo 'as_is'.")
                 return None
            logger.debug(f"Jacobiano costo totale (as_is): {component_costs}")
            return component_costs
        else:
            logger.warning(f"Modalità prezzo '{self.grade.price_mode}' non riconosciuta per Jacobiano costo. Calcolo come 'as_is'.")
            component_costs = self.get_component_costs()
            if not np.all(np.isfinite(component_costs)):
                 logger.error("Costi componenti non finiti, impossibile calcolare Jacobiano costo.")
                 return None
            return component_costs

    def get_properties_dict(self) -> Dict[str, np.ndarray]:
        """Restituisce un dizionario {nome_proprietà: array_valori_componenti}."""
        props_dict = {}
        if not self.components:
            return props_dict

        prop_names = set()
        for comp in self.components:
             for attr, value in comp.__dict__.items():
                 # Include solo attributi numerici non privati
                 if isinstance(value, (int, float)) and not attr.startswith('_'):
                     prop_names.add(attr)
             # Include proprietà dal dizionario 'properties' se esiste
             if hasattr(comp, 'properties') and isinstance(comp.properties, dict):
                 for prop_key in comp.properties.keys():
                     prop_names.add(prop_key)

        # Escludi attributi che non sono proprietà fisiche
        non_prop_attrs = {
            'delta_value', 'multiplier', 'base_density_component',
            'max_qty_mt', 'is_ethanol' # Aggiunto is_ethanol per sicurezza
        }
        prop_names -= non_prop_attrs

        for prop_name in sorted(list(prop_names)): # Ordina per output consistente
            values = []
            for comp in self.components:
                value = np.nan # Default a NaN se non trovato
                # Prova a ottenere il valore dall'attributo diretto
                if hasattr(comp, prop_name):
                    attr_val = getattr(comp, prop_name)
                    if isinstance(attr_val, (int, float)):
                        value = float(attr_val)
                # Se non trovato come attributo, prova nel dizionario 'properties'
                elif hasattr(comp, 'properties') and isinstance(comp.properties, dict) and prop_name in comp.properties:
                    prop_val = comp.properties[prop_name]
                    if isinstance(prop_val, (int, float)):
                        value = float(prop_val)

                # Gestisci None o altri tipi non numerici trovati
                if not isinstance(value, (int, float)) or not np.isfinite(value):
                    # Logga un warning se una proprietà attesa non è un numero valido
                    # logger.warning(f"Valore non numerico o non finito per '{prop_name}' in componente '{comp.name}'. Usato NaN.")
                    value = np.nan # Usa NaN per indicare valore mancante/non valido

                values.append(value)
            props_dict[prop_name] = np.array(values, dtype=np.float64)

        return props_dict




    def get_additive_by_name(self, name: str) -> Optional[Additive]:
        """Trova un additivo disponibile per nome."""
        for additive in self.available_additives:
            if additive.name == name:
                return additive
        logger.warning(f"Additivo 	{name}	 non trovato tra quelli disponibili.")
        return None

