"""
Modulo per la gestione dei vincoli di blending.

Questo modulo definisce la classe ConstraintManager che gestisce
i vincoli per l'ottimizzazione del blending.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from typing import Dict, List, Tuple, Optional, Union, Any, Callable

import numpy as np

from ..utils.constants import (
    CONSTRAINT_MIN, CONSTRAINT_MAX, CONSTRAINT_EQUAL,
    PROPERTY_RON, PROPERTY_MON, PROPERTY_RVP, PROPERTY_DENSITY,
    PROPERTY_SULFUR_PPM, PROPERTY_BENZENE, PROPERTY_AROMATICS,
    PROPERTY_OLEFINS, PROPERTY_E150, PROPERTY_E70, PROPERTY_OXY_WT,
    PROPERTY_T50, PROPERTY_MTBE, PROPERTY_RON_AVERAGE
)
from ..models import Grade
from ..blending.properties import PropertyCalculator, is_linear_property

logger = logging.getLogger("fuel_blending.blending.constraints")

@dataclass
class Constraint:
    """
    Rappresenta un singolo vincolo per una proprietà.

    Attributes:
        property_name: Nome della proprietà (es. "ron", "rvp", "ron_average")
        constraint_type: Tipo di vincolo ("min", "max", "equal")
        value: Valore del vincolo
        weight: Peso del vincolo per l'ottimizzazione
        active: Se il vincolo è attivo
    """
    property_name: str
    constraint_type: str
    value: float
    weight: float = 1.0
    active: bool = True

    def __str__(self) -> str:
        """Rappresentazione stringa del vincolo."""
        op = {CONSTRAINT_MIN: ">=", CONSTRAINT_MAX: "<=", CONSTRAINT_EQUAL: "=="}[self.constraint_type]
        return f"{self.property_name} {op} {self.value}"


class ConstraintManager:
    """
    Gestisce i vincoli per l'ottimizzazione del blending.

    Questa classe mantiene una lista di vincoli per ciascuna proprietà
    e fornisce metodi per aggiungere, rimuovere e verificare i vincoli.
    """

    def __init__(self):
        """Inizializza il gestore dei vincoli."""
        self.constraints: List[Constraint] = []

    def add_constraint(
        self,
        property_name: str,
        constraint_type: str,
        value: float,
        weight: float = 1.0,
        active: bool = True
    ) -> Constraint:
        """
        Aggiunge un nuovo vincolo.

        Args:
            property_name: Nome della proprietà (es. "ron", "rvp", "ron_average")
            constraint_type: Tipo di vincolo ("min", "max", "equal")
            value: Valore del vincolo
            weight: Peso del vincolo per l'ottimizzazione
            active: Se il vincolo è attivo

        Returns:
            Il vincolo creato

        Raises:
            ValueError: Se il tipo di vincolo non è valido
        """
        if constraint_type not in (CONSTRAINT_MIN, CONSTRAINT_MAX, CONSTRAINT_EQUAL):
            raise ValueError(f"Tipo di vincolo non valido: {constraint_type}")

        constraint = Constraint(
            property_name=property_name,
            constraint_type=constraint_type,
            value=value,
            weight=weight,
            active=active
        )

        self.constraints.append(constraint)
        logger.debug(f"Aggiunto vincolo: {constraint}")
        return constraint

    def add_constraints_from_grade(self, grade: Grade):
        """
        Aggiunge vincoli basati sulle specifiche di un Grade.

        Args:
            grade: Il Grade da cui estrarre i vincoli.
        """
        logger.debug(f"Aggiunta vincoli per il grade: {grade.name}")
        # Use combined specs dictionary
        for prop, limits in grade.specs.items():
            min_val, max_val = limits
            if min_val is not None:
                self.add_constraint(prop, CONSTRAINT_MIN, min_val)
            if max_val is not None:
                self.add_constraint(prop, CONSTRAINT_MAX, max_val)

        # Add constraint for RON Average if specified
        # Note: The property name used is PROPERTY_RON_AVERAGE, but it constraints the calculated RON value.
        if grade.ron_linear_min is not None:
            self.add_constraint(PROPERTY_RON_AVERAGE, CONSTRAINT_MIN, grade.ron_linear_min)

        # Add constraint for forced ethanol if specified
        if grade.force_ethanol and grade.force_ethanol.enabled:
             # Find the index of the ethanol component (assuming it exists and is marked)
             # This logic might need adjustment based on how components are passed/identified.
             # For now, we assume the caller handles passing the correct component data.
             # We add a placeholder constraint name; the actual implementation happens in the optimizer setup.
             self.add_constraint("force_ethanol", CONSTRAINT_EQUAL, grade.force_ethanol.mass_frac)
             logger.info(f"Aggiunto vincolo forzato per etanolo: {grade.force_ethanol.mass_frac * 100}%")


    def remove_constraint(self, constraint: Constraint) -> None:
        """
        Rimuove un vincolo.

        Args:
            constraint: Il vincolo da rimuovere
        """
        if constraint in self.constraints:
            self.constraints.remove(constraint)
            logger.debug(f"Rimosso vincolo: {constraint}")

    def get_constraints_for_property(self, property_name: str) -> List[Constraint]:
        """
        Ottiene tutti i vincoli per una proprietà.

        Args:
            property_name: Nome della proprietà

        Returns:
            Lista dei vincoli per la proprietà
        """
        return [c for c in self.constraints if c.property_name == property_name and c.active]

    def get_active_constraints(self) -> List[Constraint]:
        """
        Ottiene tutti i vincoli attivi.

        Returns:
            Lista dei vincoli attivi
        """
        return [c for c in self.constraints if c.active]

    def check_constraint(
        self,
        constraint: Constraint,
        property_value: float
    ) -> Tuple[bool, float]:
        """
        Verifica se un vincolo è soddisfatto.

        Args:
            constraint: Il vincolo da verificare
            property_value: Il valore della proprietà

        Returns:
            Tupla (soddisfatto, violazione)
            - soddisfatto: True se il vincolo è soddisfatto
            - violazione: Entità della violazione (0 se soddisfatto)
        """
        # Skip check for placeholder constraints like 'force_ethanol'
        if constraint.property_name == "force_ethanol":
             return True, 0.0

        if constraint.constraint_type == CONSTRAINT_MIN:
            satisfied = property_value >= constraint.value
            violation = max(0, constraint.value - property_value)
        elif constraint.constraint_type == CONSTRAINT_MAX:
            satisfied = property_value <= constraint.value
            violation = max(0, property_value - constraint.value)
        else:  # CONSTRAINT_EQUAL
            # Use a relative or absolute tolerance for float comparison
            tol = 1e-6
            satisfied = abs(property_value - constraint.value) < tol
            violation = abs(property_value - constraint.value)

        return satisfied, violation

    def check_all_constraints(
        self,
        property_values: Dict[str, float]
    ) -> Tuple[bool, Dict[str, float]]:
        """
        Verifica tutti i vincoli attivi.

        Args:
            property_values: Dizionario dei valori delle proprietà calcolate del blend

        Returns:
            Tupla (tutti_soddisfatti, violazioni)
            - tutti_soddisfatti: True se tutti i vincoli sono soddisfatti
            - violazioni: Dizionario delle violazioni per ciascuna proprietà
        """
        all_satisfied = True
        violations = {}

        for constraint in self.get_active_constraints():
            # Skip check for placeholder constraints like 'force_ethanol'
            if constraint.property_name == "force_ethanol":
                 continue

            # The property value for RON_AVERAGE is the calculated RON
            prop_name_in_values = PROPERTY_RON if constraint.property_name == PROPERTY_RON_AVERAGE else constraint.property_name

            if prop_name_in_values not in property_values:
                logger.warning(f"Proprietà vincolata '{constraint.property_name}' (richiede '{prop_name_in_values}') non trovata nei valori calcolati. Impossibile verificare il vincolo.")
                # Consider this a failure? Or just skip?
                # For now, mark as unsatisfied if property is missing.
                all_satisfied = False
                violations[constraint.property_name] = float('inf') # Indicate failure due to missing property
                continue

            property_value = property_values[prop_name_in_values]
            satisfied, violation = self.check_constraint(constraint, property_value)

            if not satisfied:
                all_satisfied = False

            # Use the original constraint name (e.g., ron_average) as the key for violations
            violation_key = constraint.property_name
            if violation_key not in violations:
                violations[violation_key] = 0.0

            # Accumulate weighted violation (use max to report the largest violation if multiple constraints exist for the same property)
            violations[violation_key] = max(
                violations[violation_key],
                violation * constraint.weight
            )

        return all_satisfied, violations

    def create_constraint_functions(
        self,
        property_calculator: PropertyCalculator,
        component_names: List[str],
        component_properties: Dict[str, List[float]],
        ethanol_indices: List[int] # Indices of ethanol components
    ) -> Tuple[List[Dict[str, Any]], List[Dict[str, Any]]]:
        """
        Crea funzioni di vincolo e i loro Jacobiani per l'ottimizzazione (formato SciPy).

        Args:
            property_calculator: Istanza di PropertyCalculator.
            component_names: Lista ordinata dei nomi dei componenti.
            component_properties: Dizionario {nome_proprietà: [valori_componenti]} ordinati come component_names.
            ethanol_indices: Lista degli indici dei componenti che sono etanolo.

        Returns:
            Tupla (eq_constraints, ineq_constraints)
            - eq_constraints: Lista di dizionari per vincoli di uguaglianza ({'type': 'eq', 'fun': callable, 'jac': callable}).
            - ineq_constraints: Lista di dizionari per vincoli di disuguaglianza ({'type': 'ineq', 'fun': callable, 'jac': callable}).
        """
        eq_constraints_list = []
        ineq_constraints_list = []

        num_components = len(component_names)

        # 1. Vincolo somma delle frazioni = 1
        # fun(x) = sum(x) - 1 = 0
        # jac(x) = [1, 1, ..., 1]
        eq_constraints_list.append({
            'type': 'eq',
            'fun': lambda x: np.sum(x) - 1.0,
            'jac': lambda x: np.ones(num_components)
        })

        # 2. Vincoli sulle proprietà dai Grade
        for constraint in self.get_active_constraints():
            if not constraint.active:
                continue

            # Handle special 'force_ethanol' constraint
            if constraint.property_name == "force_ethanol":
                if not ethanol_indices:
                    logger.warning("Vincolo 'force_ethanol' presente ma nessun componente etanolo identificato.")
                    continue
                target_frac = constraint.value
                # fun(x) = sum(x[i] for i in ethanol_indices) - target_frac = 0
                # jac(x) = [1 if i in ethanol_indices else 0 for i in range(num_components)]
                jac_ethanol = np.zeros(num_components)
                for idx in ethanol_indices:
                    jac_ethanol[idx] = 1.0

                eq_constraints_list.append({
                    'type': 'eq',
                    'fun': lambda x, indices=ethanol_indices, target=target_frac: np.sum(x[indices]) - target,
                    'jac': lambda x, jac_val=jac_ethanol: jac_val
                })
                continue # Move to next constraint

            # Handle standard property constraints
            # Special handling for RON_AVERAGE which uses RON values
            prop_name_for_calc = PROPERTY_RON if constraint.property_name == PROPERTY_RON_AVERAGE else constraint.property_name

            if prop_name_for_calc not in component_properties:
                logger.warning(f"Proprietà '{prop_name_for_calc}' per vincolo '{constraint.property_name}' non trovata nei dati dei componenti. Vincolo ignorato.")
                continue

            prop_values = np.array(component_properties[prop_name_for_calc], dtype=np.float64)
            is_linear = is_linear_property(prop_name_for_calc)

            # --- Define Constraint Function 'fun' --- 
            def constraint_fun(x, prop=prop_name_for_calc, values=prop_values, calculator=property_calculator, target=constraint.value, c_type=constraint.constraint_type):
                fracs = np.array(x, dtype=np.float64)
                # Pass numpy arrays to calculator
                prop_value = calculator.calculate_property(prop, values, fracs)
                if c_type == CONSTRAINT_EQUAL:
                    return prop_value - target # fun(x) = 0 => prop - target = 0
                elif c_type == CONSTRAINT_MIN:
                    return prop_value - target # fun(x) >= 0 => prop - target >= 0
                elif c_type == CONSTRAINT_MAX:
                    return target - prop_value # fun(x) >= 0 => target - prop >= 0
                else:
                    # Should not happen due to initial check
                    raise ValueError(f"Tipo vincolo non gestito: {c_type}")

            # --- Define Jacobian Function 'jac' --- 
            def constraint_jac(x, prop=prop_name_for_calc, values=prop_values, calculator=property_calculator, c_type=constraint.constraint_type, linear=is_linear):
                fracs = np.array(x, dtype=np.float64)
                if linear:
                    # For linear: jac = prop_values (or -prop_values for MAX)
                    grad = values
                else:
                    # For non-linear: jac = calculator.calculate_property_jacobian(...)
                    grad = calculator.calculate_property_jacobian(prop, values, fracs)
                
                if c_type == CONSTRAINT_EQUAL or c_type == CONSTRAINT_MIN:
                    return grad # Jacobian of (prop - target) is jac(prop)
                elif c_type == CONSTRAINT_MAX:
                    return -grad # Jacobian of (target - prop) is -jac(prop)
                else:
                     # Should not happen
                    raise ValueError(f"Tipo vincolo non gestito per jac: {c_type}")

            # --- Add to list --- 
            constraint_dict = {'fun': constraint_fun, 'jac': constraint_jac}
            if constraint.constraint_type == CONSTRAINT_EQUAL:
                constraint_dict['type'] = 'eq'
                eq_constraints_list.append(constraint_dict)
            else: # MIN or MAX
                constraint_dict['type'] = 'ineq'
                ineq_constraints_list.append(constraint_dict)

        logger.info(f"Creati {len(eq_constraints_list)} vincoli di uguaglianza e {len(ineq_constraints_list)} vincoli di disuguaglianza.")
        return eq_constraints_list, ineq_constraints_list

