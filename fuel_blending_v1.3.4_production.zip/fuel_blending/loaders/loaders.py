"""
Modulo di caricamento dati aggiornato con supporto per Google Drive.

Questo modulo gestisce il caricamento dei dati da file locali o da Google Drive.
Versione 1.2.1: Migliorata gestione errori.
Versione 1.3.4: Chiarito formato file locali attesi (CSV/JSON/YAML).
"""

import os
import json
import logging
import pandas as pd
import yaml
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple, Union

from ..models import Component, Grade, Additive, ForceEthanol
from ..integrations.google_drive import GoogleDriveIntegration
from ..utils.exceptions import DataLoadError, AuthenticationError

class DataLoader:
    """
    Caricatore di dati per il sistema di fuel blending.

    Gestisce il caricamento da:
    - File locali: Componenti (CSV), Grade (JSON), Additivi (YAML).
    - Google Drive: Utilizza GoogleDriveIntegration che internamente gestisce file Excel.
    """

    logger = logging.getLogger("fuel_blending.loaders")

    @staticmethod
    def load(
        components_path: Union[str, Path],
        grades_path: Union[str, Path],
        additives_path: Optional[Union[str, Path]] = None,
        from_google_drive: bool = False,
        interactive: bool = False,
        credentials_file: Optional[str] = None,
        token_file: Optional[str] = None
    ) -> Any:
        """
        Carica i dati da file locali o da Google Drive.

        Args:
            components_path: Percorso file CSV locale o ID file Google Drive (Excel).
            grades_path: Percorso file JSON locale o ID file Google Drive (Excel).
            additives_path: Percorso file YAML locale o ID file Google Drive (Excel) (opzionale).
            from_google_drive: Flag per caricare da Google Drive.
            interactive: Flag per modalità interattiva Google Drive.
            credentials_file: Percorso file credenziali Google Drive.
            token_file: Percorso file token Google Drive.

        Returns:
            Any: Oggetto contenente i dati caricati (con attributi components, grades, additives).

        Raises:
            DataLoadingError: Se il caricamento dei dati fallisce.
            AuthenticationError: Se l'autenticazione Google Drive fallisce.
        """
        source = "Google Drive" if from_google_drive else "local files"
        DataLoader.logger.info(f"Inizio caricamento dati da {source}...")
        try:
            if from_google_drive:
                # GoogleDriveIntegration gestisce internamente il download e la lettura di file Excel.
                return DataLoader._load_from_google_drive(
                    str(components_path), # Assicura che siano stringhe (ID)
                    str(grades_path),
                    str(additives_path) if additives_path else None,
                    interactive,
                    credentials_file,
                    token_file
                )
            else:
                # I metodi _load_from_local_files usano formati specifici:
                # load_components -> CSV
                # load_grades -> JSON
                # load_additives -> YAML
                # Non è previsto il caricamento diretto di file Excel locali qui.
                return DataLoader._load_from_local_files(
                    components_path,
                    grades_path,
                    additives_path
                )
        except (DataLoadError, AuthenticationError) as e:
            # Rilancia eccezioni specifiche già gestite
            DataLoader.logger.error(f"Errore specifico durante il caricamento dati da {source}: {e}")
            raise
        except Exception as e:
            DataLoader.logger.error(f"Errore imprevisto durante il caricamento dati da {source}: {e}", exc_info=True)
            raise DataLoadError(f"Errore imprevisto durante il caricamento dati da {source}: {e}")

    @staticmethod
    def _load_from_local_files(
        components_path: Union[str, Path],
        grades_path: Union[str, Path],
        additives_path: Optional[Union[str, Path]] = None
    ) -> Any:
        """
        Carica i dati da file locali (CSV per componenti, JSON per grade, YAML per additivi).
        """
        DataLoader.logger.info(f"Caricamento componenti da file CSV locale: {components_path}")
        components = DataLoader.load_components(components_path)

        DataLoader.logger.info(f"Caricamento grade da file JSON locale: {grades_path}")
        grades = DataLoader.load_grades(grades_path)

        additives = None
        if additives_path:
            DataLoader.logger.info(f"Caricamento additivi da file YAML locale: {additives_path}")
            additives = DataLoader.load_additives(additives_path)
        else:
            DataLoader.logger.info("Nessun file additivi specificato.")

        # Crea un oggetto semplice per contenere i dati
        class Data:
            def __init__(self, components, grades, additives):
                self.components = components
                self.grades = grades
                self.additives = additives

        DataLoader.logger.info("Caricamento dati locali completato.")
        return Data(components, grades, additives)

    @staticmethod
    def _load_from_google_drive(
        components_file_id: str,
        grades_file_id: str,
        additives_file_id: Optional[str] = None,
        interactive: bool = False,
        credentials_file: Optional[str] = None,
        token_file: Optional[str] = None
    ) -> Any:
        """
        Carica i dati da Google Drive (presumibilmente file Excel).
        """
        DataLoader.logger.info("Inizializzazione integrazione Google Drive...")
        try:
            integration = GoogleDriveIntegration(credentials_file, token_file)
            # L'autenticazione avviene qui dentro, può sollevare AuthenticationError

            DataLoader.logger.info("Caricamento dati da Google Drive...")
            if interactive:
                # Nota: interactive_load gestisce l'autenticazione al suo interno
                drive_data = integration.interactive_load()
            else:
                # load_data richiede che l'autenticazione sia già avvenuta o avvenga qui
                drive_data = integration.load_data(components_file_id, grades_file_id, additives_file_id)

            # Crea un oggetto semplice per contenere i dati
            class Data:
                def __init__(self, components, grades, additives):
                    self.components = components
                    self.grades = grades
                    self.additives = additives

            DataLoader.logger.info("Caricamento dati da Google Drive completato.")
            return Data(drive_data.components, drive_data.grades, drive_data.additives)

        except AuthenticationError as auth_err:
            # Errore specifico di autenticazione, rilancia
            DataLoader.logger.error(f"Errore di autenticazione Google Drive: {auth_err}")
            raise
        except DataLoadError as load_err:
            # Errore specifico di caricamento dati da GDrive (es. file non trovato)
            DataLoader.logger.error(f"Errore durante il caricamento dati da Google Drive: {load_err}")
            raise
        except Exception as e:
            # Errore generico durante l'operazione con GDrive
            DataLoader.logger.error(f"Errore imprevisto durante l'operazione con Google Drive: {e}", exc_info=True)
            raise DataLoadingError(f"Errore imprevisto durante l'operazione con Google Drive: {e}")

    @staticmethod
    def load_components(path: Union[str, Path]) -> List[Component]:
        """
        Carica i componenti da un file CSV locale.
        """
        try:
            path = Path(path)
            if not path.is_file():
                raise FileNotFoundError(f"File dei componenti CSV non trovato: {path}")

            DataLoader.logger.debug(f"Lettura file CSV componenti: {path}")
            df = pd.read_csv(path)

            components = []
            required_cols = {
                'name', 'delta_type', 'density', 'ron', 'mon', 'rvp', 'sulfur_ppm',
                'benzene', 'aromatics', 'olefins', 'mtbe', 't10', 't50', 'e70', 'e150', 'oxy_wt'
            }
            # delta_value, multiplier, base_density_component, max_qty_mt, is_ethanol sono opzionali
            if not required_cols.issubset(df.columns):
                missing = required_cols - set(df.columns)
                DataLoader.logger.warning(f"Colonne potenzialmente mancanti nel file componenti {path}: {missing}. Verranno usati valori di default o None.")
                # Non sollevare errore, prova a procedere con i default
                # raise DataLoadingError(f"Colonne mancanti nel file componenti {path}: {missing}")

            for index, row in df.iterrows():
                try:
                    row_dict = row.fillna('').to_dict()

                    # Conversione booleana robusta
                    is_ethanol_val = row_dict.get('is_ethanol', False) # Default a False se manca
                    is_ethanol = str(is_ethanol_val).lower() in ('true', 't', 'yes', 'y', '1')

                    # Conversione numerica robusta con valori di default o None
                    def safe_float(key, default=0.0, allow_none=False):
                        val = row_dict.get(key, default if not allow_none else None)
                        if val == '':
                            return default if not allow_none else None
                        try:
                            return float(val)
                        except (ValueError, TypeError):
                            DataLoader.logger.warning(f"Valore non valido per '{key}' nella riga {index+2} del file {path}: '{val}'. Uso {'None' if allow_none else default}.")
                            return default if not allow_none else None

                    def safe_str(key, default=''):
                        return str(row_dict.get(key, default))

                    # Validazione delta_type e valori associati
                    delta_type = safe_str('delta_type', DELTA_TYPE_AS_IS)
                    delta_value = safe_float('delta_value', default=None, allow_none=True)
                    multiplier = safe_float('multiplier', default=None, allow_none=True)

                    if delta_type == DELTA_TYPE_AS_IS and delta_value is None:
                        DataLoader.logger.warning(f"Componente '{row_dict.get('name')}' (riga {index+2}) ha delta_type 'as_is' ma manca 'delta_value'. Assumendo 0.0.")
                        delta_value = 0.0
                    elif delta_type == DELTA_TYPE_FACTOR and multiplier is None:
                        DataLoader.logger.warning(f"Componente '{row_dict.get('name')}' (riga {index+2}) ha delta_type 'factor' ma manca 'multiplier'. Assumendo 1.0.")
                        multiplier = 1.0
                    elif delta_type == DELTA_TYPE_ESCALATED and delta_value is None:
                         DataLoader.logger.warning(f"Componente '{row_dict.get('name')}' (riga {index+2}) ha delta_type 'escalated' ma manca 'delta_value'. Assumendo 0.0.")
                         delta_value = 0.0

                    component = Component(
                        name=safe_str('name'),
                        delta_type=delta_type,
                        delta_value=delta_value,
                        multiplier=multiplier,
                        base_density_component=safe_float('base_density_component', default=None, allow_none=True),
                        max_qty_mt=safe_float('max_qty_mt', default=None, allow_none=True),
                        density=safe_float('density'),
                        ron=safe_float('ron'),
                        mon=safe_float('mon'),
                        rvp=safe_float('rvp'),
                        sulfur_ppm=safe_float('sulfur_ppm'),
                        benzene=safe_float('benzene'),
                        aromatics=safe_float('aromatics'),
                        olefins=safe_float('olefins'),
                        mtbe=safe_float('mtbe'),
                        t10=safe_float('t10', allow_none=True),
                        t50=safe_float('t50', allow_none=True),
                        e70=safe_float('e70', allow_none=True),
                        e150=safe_float('e150', allow_none=True),
                        oxy_wt=safe_float('oxy_wt'),
                        is_ethanol=is_ethanol
                    )
                    components.append(component)
                except (ValueError, TypeError, KeyError) as row_err:
                    DataLoader.logger.error(f"Errore nella riga {index+2} del file componenti {path}: {row_err}. Riga: {row.to_dict()}")
                    raise DataLoadingError(f"Errore nella riga {index+2} del file componenti {path}: {row_err}")

            DataLoader.logger.debug(f"Caricati {len(components)} componenti da {path}")
            return components

        except FileNotFoundError as fnf_err:
            DataLoader.logger.error(f"File componenti CSV non trovato: {fnf_err}")
            raise DataLoadingError(f"File componenti CSV non trovato: {fnf_err}")
        except pd.errors.EmptyDataError:
            DataLoader.logger.error(f"File componenti {path} è vuoto.")
            raise DataLoadingError(f"File componenti {path} è vuoto.")
        except pd.errors.ParserError as parse_err:
            DataLoader.logger.error(f"Errore di parsing nel file componenti {path}: {parse_err}")
            raise DataLoadingError(f"Errore di parsing nel file componenti {path}: {parse_err}")
        except DataLoadingError: # Rilancia errori già specifici
            raise
        except Exception as e:
            DataLoader.logger.error(f"Errore imprevisto durante il caricamento dei componenti da {path}: {e}", exc_info=True)
            raise DataLoadingError(f"Errore imprevisto durante il caricamento dei componenti da {path}: {e}")

    @staticmethod
    def load_grades(path: Union[str, Path]) -> List[Grade]:
        """
        Carica i grade da un file JSON locale.
        """
        try:
            path = Path(path)
            if not path.is_file():
                raise FileNotFoundError(f"File dei grade JSON non trovato: {path}")

            DataLoader.logger.debug(f"Lettura file JSON grade: {path}")
            with open(path, 'r') as f:
                grades_data = json.load(f)

            if not isinstance(grades_data, list):
                raise DataLoadingError(f"Il file JSON dei grade {path} non contiene una lista.")

            grades = []
            for index, grade_data in enumerate(grades_data):
                try:
                    if not isinstance(grade_data, dict):
                        raise DataLoadingError(f"Elemento {index} nel file grade non è un dizionario.")

                    # Gestione specifiche: assicurarsi che siano tuple (min, max)
                    specs_raw = grade_data.get('specs', {})
                    specs_processed = {}
                    if isinstance(specs_raw, dict):
                        for prop, value in specs_raw.items():
                            if isinstance(value, list) and len(value) == 2:
                                specs_processed[prop] = tuple(value)
                            elif isinstance(value, tuple) and len(value) == 2:
                                specs_processed[prop] = value
                            else:
                                DataLoader.logger.warning(f"Specifica '{prop}' per grade '{grade_data.get('name')}' non è una lista/tupla di 2 elementi, ignorata: {value}")
                    else:
                         DataLoader.logger.warning(f"Campo 'specs' per grade '{grade_data.get('name')}' non è un dizionario, ignorato.")

                    force_ethanol = None
                    if 'force_ethanol' in grade_data and grade_data['force_ethanol'] is not None:
                        fe_data = grade_data['force_ethanol']
                        if isinstance(fe_data, dict):
                            try:
                                force_ethanol = ForceEthanol(
                                    enabled=bool(fe_data.get('enabled', False)),
                                    mass_frac=float(fe_data.get('mass_frac', 0.0))
                                )
                            except (ValueError, TypeError) as fe_err:
                                DataLoader.logger.warning(f"Errore nei dati 'force_ethanol' per grade '{grade_data.get('name')}': {fe_err}. Ignorato.")
                        else:
                             DataLoader.logger.warning(f"Campo 'force_ethanol' per grade '{grade_data.get('name')}' non è un dizionario, ignorato.")

                    grade = Grade(
                        name=str(grade_data.get('name', f'UnnamedGrade_{index}')),
                        specs=specs_processed,
                        target_mass=float(grade_data.get('target_mass', 1000.0)),
                        price_mode=str(grade_data.get('price_mode', PRICE_MODE_AS_IS)),
                        base_density_escalation=float(grade_data['base_density_escalation']) if grade_data.get('base_density_escalation') is not None else None,
                        ron_linear_min=float(grade_data['ron_linear_min']) if grade_data.get('ron_linear_min') is not None else None,
                        additives=grade_data.get('additives', {}), # Aggiunto caricamento additivi per grade
                        force_ethanol=force_ethanol
                    )
                    grades.append(grade)
                except (ValueError, TypeError, KeyError) as item_err:
                    DataLoader.logger.error(f"Errore nell'elemento {index} del file grade {path}: {item_err}. Dati: {grade_data}")
                    raise DataLoadingError(f"Errore nell'elemento {index} del file grade {path}: {item_err}")

            DataLoader.logger.debug(f"Caricati {len(grades)} grade da {path}")
            return grades

        except FileNotFoundError as fnf_err:
            DataLoader.logger.error(f"File grade JSON non trovato: {fnf_err}")
            raise DataLoadingError(f"File grade JSON non trovato: {fnf_err}")
        except json.JSONDecodeError as json_err:
            DataLoader.logger.error(f"Errore di decodifica JSON nel file grade {path}: {json_err}")
            raise DataLoadingError(f"Errore di formato JSON nel file grade {path}: {json_err}")
        except DataLoadingError: # Rilancia errori già specifici
            raise
        except Exception as e:
            DataLoader.logger.error(f"Errore imprevisto durante il caricamento dei grade da {path}: {e}", exc_info=True)
            raise DataLoadingError(f"Errore imprevisto durante il caricamento dei grade da {path}: {e}")

    @staticmethod
    def load_additives(path: Union[str, Path]) -> Dict[str, Additive]:
        """
        Carica gli additivi da un file YAML locale.
        """
        try:
            path = Path(path)
            if not path.is_file():
                raise FileNotFoundError(f"File degli additivi YAML non trovato: {path}")

            DataLoader.logger.debug(f"Lettura file YAML additivi: {path}")
            with open(path, 'r') as f:
                additives_data = yaml.safe_load(f)

            if additives_data is None: # File YAML vuoto
                DataLoader.logger.warning(f"File additivi {path} è vuoto o non contiene dati validi.")
                return {}

            if not isinstance(additives_data, dict):
                raise DataLoadingError(f"Il file YAML degli additivi {path} non contiene un dizionario alla radice.")

            additives = {}
            for name, data in additives_data.items():
                try:
                    if not isinstance(data, dict):
                         raise DataLoadingError(f"Dati per additivo '{name}' non sono un dizionario.")

                    additive = Additive(
                        name=str(name),
                        cost_usd_per_litre=float(data.get('cost_usd_per_litre', 0.0)),
                        density_add=float(data.get('density_add', 0.0))
                    )
                    additives[name] = additive
                except (ValueError, TypeError, KeyError) as item_err:
                    DataLoader.logger.error(f"Errore nei dati per l'additivo '{name}' nel file {path}: {item_err}. Dati: {data}")
                    raise DataLoadingError(f"Errore nei dati per l'additivo '{name}' nel file {path}: {item_err}")

            DataLoader.logger.debug(f"Caricati {len(additives)} additivi da {path}")
            return additives

        except FileNotFoundError as fnf_err:
            DataLoader.logger.error(f"File additivi YAML non trovato: {fnf_err}")
            raise DataLoadingError(f"File additivi YAML non trovato: {fnf_err}")
        except yaml.YAMLError as yaml_err:
            DataLoader.logger.error(f"Errore di parsing YAML nel file additivi {path}: {yaml_err}")
            raise DataLoadingError(f"Errore di formato YAML nel file additivi {path}: {yaml_err}")
        except DataLoadingError: # Rilancia errori già specifici
            raise
        except Exception as e:
            DataLoader.logger.error(f"Errore imprevisto durante il caricamento degli additivi da {path}: {e}", exc_info=True)
            raise DataLoadingError(f"Errore imprevisto durante il caricamento degli additivi da {path}: {e}")

