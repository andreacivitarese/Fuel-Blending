"""
Test per l'analisi di sensibilità basata sulla presenza/assenza dei componenti.
"""

import unittest
import pandas as pd
import numpy as np
import tempfile
import os
import json
from pathlib import Path

from ..models import Component, Grade
from ..analysis import EconomicAnalyzer
from ..optimization import OptimizerConfig
from ..utils.exceptions import SensitivityAnalysisError

class TestComponentPresenceAnalysis(unittest.TestCase):
    """
    Test per l'analisi di sensibilità basata sulla presenza/assenza dei componenti.
    """
    
    def setUp(self):
        """
        Inizializza i dati di test.
        """
        # Crea componenti di test
        self.components = [
            Component(
                name="Comp1",
                delta_type="as_is",
                delta_value=5.0,
                density=0.75,
                ron=95,
                mon=85,
                rvp=9,
                sulfur_ppm=10,
                benzene=0.5,
                aromatics=25,
                olefins=10,
                mtbe=0,
                t10=60,
                t50=110,
                e70=20,
                oxy_wt=0,
                is_ethanol=False
            ),
            Component(
                name="Comp2",
                delta_type="as_is",
                delta_value=8.0,
                density=0.78,
                ron=92,
                mon=82,
                rvp=7,
                sulfur_ppm=15,
                benzene=0.8,
                aromatics=30,
                olefins=12,
                mtbe=0,
                t10=65,
                t50=115,
                e70=22,
                oxy_wt=0,
                is_ethanol=False
            ),
            Component(
                name="Comp3",
                delta_type="factor",
                multiplier=1.05,
                density=0.72,
                ron=98,
                mon=88,
                rvp=12,
                sulfur_ppm=5,
                benzene=0.3,
                aromatics=20,
                olefins=8,
                mtbe=0,
                t10=55,
                t50=105,
                e70=18,
                oxy_wt=0,
                is_ethanol=False
            ),
            Component(
                name="Ethanol",
                delta_type="as_is",
                delta_value=15.0,
                density=0.79,
                ron=115,
                mon=90,
                rvp=18,
                sulfur_ppm=0,
                benzene=0,
                aromatics=0,
                olefins=0,
                mtbe=0,
                t10=78,
                t50=78,
                e70=100,
                oxy_wt=35,
                is_ethanol=True
            )
        ]
        
        # Crea grade di test
        self.grades = [
            Grade(
                name="Grade1",
                price_mode="as_is",
                ethanol_pct=5,
                specs={
                    "RON": {"min": 95, "max": 98},
                    "MON": {"min": 85, "max": 89},
                    "RVP": {"min": 7, "max": 9},
                    "sulfur_ppm": {"min": 0, "max": 10},
                    "benzene": {"min": 0, "max": 1.0},
                    "aromatics": {"min": 0, "max": 35},
                    "olefins": {"min": 0, "max": 18},
                    "oxy_wt": {"min": 1.5, "max": 2.7}
                }
            ),
            Grade(
                name="Grade2",
                price_mode="escalated",
                ethanol_pct=10,
                specs={
                    "RON": {"min": 97, "max": 102},
                    "MON": {"min": 87, "max": 92},
                    "RVP": {"min": 7, "max": 10},
                    "sulfur_ppm": {"min": 0, "max": 8},
                    "benzene": {"min": 0, "max": 0.8},
                    "aromatics": {"min": 0, "max": 30},
                    "olefins": {"min": 0, "max": 15},
                    "oxy_wt": {"min": 3.0, "max": 4.0}
                }
            )
        ]
        
        # Crea risultati di ottimizzazione di test
        self.optimization_results = {
            "Grade1": {
                "success": True,
                "objective_value": 700.0,
                "price": 700.0,
                "blend_fractions": {
                    "Comp1": 0.4,
                    "Comp2": 0.3,
                    "Comp3": 0.25,
                    "Ethanol": 0.05
                },
                "blend_properties": {
                    "RON": 96.5,
                    "MON": 85.5,
                    "RVP": 9.0,
                    "sulfur_ppm": 9.5,
                    "benzene": 0.55,
                    "aromatics": 25.0,
                    "olefins": 10.0,
                    "oxy_wt": 1.75
                },
                "lambdas": {
                    "RON_lo": 0.5,
                    "MON_lo": 0.3,
                    "RVP_hi": 1.0,
                    "sulfur_ppm_hi": 0.8,
                    "benzene_hi": 0.2,
                    "aromatics_hi": 0.1,
                    "olefins_hi": 0.05,
                    "oxy_wt_lo": 0.4,
                    "oxy_wt_hi": 0.0,
                    "mass": 1.0
                }
            },
            "Grade2": {
                "success": True,
                "objective_value": 720.0,
                "price": 720.0,
                "blend_fractions": {
                    "Comp1": 0.3,
                    "Comp2": 0.2,
                    "Comp3": 0.4,
                    "Ethanol": 0.1
                },
                "blend_properties": {
                    "RON": 98.0,
                    "MON": 87.0,
                    "RVP": 10.0,
                    "sulfur_ppm": 8.0,
                    "benzene": 0.5,
                    "aromatics": 24.0,
                    "olefins": 9.5,
                    "oxy_wt": 3.5
                },
                "lambdas": {
                    "RON_lo": 0.6,
                    "MON_lo": 0.4,
                    "RVP_hi": 1.2,
                    "sulfur_ppm_hi": 1.0,
                    "benzene_hi": 0.3,
                    "aromatics_hi": 0.15,
                    "olefins_hi": 0.08,
                    "oxy_wt_lo": 0.5,
                    "oxy_wt_hi": 0.2,
                    "mass": 1.0
                }
            }
        }
        
        # Crea un file temporaneo per i risultati dell'ottimizzazione
        self.temp_dir = tempfile.TemporaryDirectory()
        self.results_file = os.path.join(self.temp_dir.name, "results.json")
        with open(self.results_file, "w") as f:
            json.dump(self.optimization_results, f)
        
        # Imposta il prezzo flat
        self.flat_price = 700.0
        
        # Crea una configurazione di ottimizzazione di test
        self.optimizer_config = OptimizerConfig(
            method="trust-constr",
            max_iterations=1000,
            tolerance=1e-6,
            verbose=0
        )
    
    def tearDown(self):
        """
        Pulisce i dati di test.
        """
        self.temp_dir.cleanup()
    
    def test_perform_component_presence_analysis(self):
        """
        Testa l'analisi di sensibilità basata sulla presenza/assenza dei componenti.
        """
        # Esegui l'analisi con la nuova signature
        results = EconomicAnalyzer.perform_component_presence_analysis(
            self.components,
            self.grades,
            self.optimization_results,
            self.flat_price,
            optimizer_cfg=self.optimizer_config
        )
        
        # Verifica che i risultati non siano vuoti
        self.assertFalse(results.empty)
        
        # Verifica che ci siano risultati per ogni componente e grade
        self.assertEqual(len(results), len(self.components) * len(self.grades))
        
        # Verifica che le colonne attese siano presenti
        expected_columns = [
            "component", "grade", "original_fraction", "is_feasible",
            "baseline_cost", "new_cost", "cost_change", "cost_change_percent",
            "impact_score"
        ]
        for col in expected_columns:
            self.assertIn(col, results.columns)
        
        # Verifica che i componenti con frazioni originali più alte abbiano un impatto maggiore
        # Questo è un test euristico, potrebbe non essere sempre vero in casi reali complessi
        high_fraction_components = results.sort_values(by="original_fraction", ascending=False).head(2)["component"].tolist()
        high_impact_components = results.sort_values(by="impact_score", ascending=False).head(2)["component"].tolist()
        
        # Verifica che ci sia almeno una sovrapposizione tra i due elenchi
        self.assertTrue(any(comp in high_impact_components for comp in high_fraction_components))
    
    def test_generate_component_presence_summary(self):
        """
        Testa la generazione del riepilogo dell'analisi di presenza/assenza.
        """
        # Crea dati di test
        data = {
            "component": ["Comp1", "Comp1", "Comp2", "Comp2", "Comp3", "Comp3", "Ethanol", "Ethanol"],
            "grade": ["Grade1", "Grade2", "Grade1", "Grade2", "Grade1", "Grade2", "Grade1", "Grade2"],
            "original_fraction": [0.4, 0.3, 0.3, 0.2, 0.25, 0.4, 0.05, 0.1],
            "is_feasible": [True, True, True, True, True, False, False, False],
            "baseline_cost": [700, 720, 700, 720, 700, 720, 700, 720],
            "new_cost": [710, 730, 705, 725, 720, None, None, None],
            "cost_change": [10, 10, 5, 5, 20, None, None, None],
            "cost_change_percent": [1.43, 1.39, 0.71, 0.69, 2.86, None, None, None],
            "impact_score": [15, 15, 10, 10, 25, 1000.0, 1000.0, 1000.0]
        }
        df = pd.DataFrame(data)
        
        # Genera il riepilogo con la nuova signature
        summary = EconomicAnalyzer.generate_component_presence_summary(
            df,
            group_by=["component"],
            sort_by="impact_score_max",
            top_n=10
        )
        
        # Verifica che il riepilogo non sia vuoto
        self.assertFalse(summary.empty)
        
        # Verifica che ci sia una riga per ogni componente
        self.assertEqual(len(summary), len(set(data["component"])))
        
        # Verifica che le colonne attese siano presenti
        expected_columns = [
            "component", "original_fraction_mean", "original_fraction_max",
            "is_feasible_mean", "cost_change_percent_mean", "cost_change_percent_min",
            "cost_change_percent_max", "impact_score_mean", "impact_score_max"
        ]
        for col in expected_columns:
            self.assertIn(col, summary.columns)
        
        # Verifica che l'ordinamento sia corretto
        self.assertEqual(summary.iloc[0]["component"], "Ethanol")  # Ethanol ha impact_score = 1000.0
        self.assertEqual(summary.iloc[1]["component"], "Comp3")    # Comp3 ha impact_score = 25
    
    def test_plot_component_presence_results(self):
        """
        Testa la creazione del grafico dei risultati dell'analisi di presenza/assenza.
        """
        # Crea dati di test
        data = {
            "component": ["Comp1", "Comp1", "Comp2", "Comp2", "Comp3", "Comp3", "Ethanol", "Ethanol"],
            "grade": ["Grade1", "Grade2", "Grade1", "Grade2", "Grade1", "Grade2", "Grade1", "Grade2"],
            "original_fraction": [0.4, 0.3, 0.3, 0.2, 0.25, 0.4, 0.05, 0.1],
            "is_feasible": [True, True, True, True, True, False, False, False],
            "baseline_cost": [700, 720, 700, 720, 700, 720, 700, 720],
            "new_cost": [710, 730, 705, 725, 720, None, None, None],
            "cost_change": [10, 10, 5, 5, 20, None, None, None],
            "cost_change_percent": [1.43, 1.39, 0.71, 0.69, 2.86, None, None, None],
            "impact_score": [15, 15, 10, 10, 25, 1000.0, 1000.0, 1000.0]
        }
        df = pd.DataFrame(data)
        
        # Crea un file temporaneo per il grafico
        output_file = os.path.join(self.temp_dir.name, "plot.png")
        
        # Crea il grafico
        try:
            # Questo test potrebbe fallire se matplotlib non è disponibile o non può creare grafici
            # in un ambiente headless, quindi lo gestiamo con un try-except
            plot = EconomicAnalyzer.plot_component_presence_results(
                df,
                output_file=output_file,
                plot_type="bar",
                x_column="component",
                y_column="cost_change_percent",
                color_column="is_feasible",
                facet_column="grade",
                title="Test Plot"
            )
            
            # Verifica che il file sia stato creato
            self.assertTrue(os.path.exists(output_file))
            
            # Verifica che il grafico sia stato restituito
            self.assertIsNotNone(plot)
            
        except Exception as e:
            # Se il test fallisce a causa di problemi con matplotlib, lo saltiamo
            self.skipTest(f"Test saltato a causa di problemi con matplotlib: {str(e)}")
    
    def test_empty_components(self):
        """
        Testa il comportamento con una lista di componenti vuota.
        """
        with self.assertRaises(Exception):
            EconomicAnalyzer.perform_component_presence_analysis(
                [],
                self.grades,
                self.optimization_results,
                self.flat_price
            )
    
    def test_empty_grades(self):
        """
        Testa il comportamento con una lista di grade vuota.
        """
        with self.assertRaises(Exception):
            EconomicAnalyzer.perform_component_presence_analysis(
                self.components,
                [],
                self.optimization_results,
                self.flat_price
            )
    
    def test_empty_optimization_results(self):
        """
        Testa il comportamento con risultati di ottimizzazione vuoti.
        """
        with self.assertRaises(Exception):
            EconomicAnalyzer.perform_component_presence_analysis(
                self.components,
                self.grades,
                {},
                self.flat_price
            )
    
    def test_invalid_flat_price(self):
        """
        Testa il comportamento con un prezzo flat non valido.
        """
        # Con un prezzo flat negativo, dovrebbe usare il valore minimo di default
        results = EconomicAnalyzer.perform_component_presence_analysis(
            self.components,
            self.grades,
            self.optimization_results,
            -10.0
        )
        
        # Verifica che i risultati non siano vuoti
        self.assertFalse(results.empty)
    
    def test_end_to_end_workflow(self):
        """
        Testa il flusso di lavoro completo dall'analisi al riepilogo.
        """
        # Esegui l'analisi
        results = EconomicAnalyzer.perform_component_presence_analysis(
            self.components,
            self.grades,
            self.optimization_results,
            self.flat_price
        )
        
        # Genera il riepilogo
        summary = EconomicAnalyzer.generate_component_presence_summary(
            results,
            group_by=["component"],
            sort_by="impact_score_max",
            top_n=10
        )
        
        # Verifica che i risultati e il riepilogo non siano vuoti
        self.assertFalse(results.empty)
        self.assertFalse(summary.empty)
        
        # Verifica che il numero di righe nel riepilogo sia uguale al numero di componenti
        self.assertEqual(len(summary), len(self.components))
        
        # Verifica che le colonne attese siano presenti nel riepilogo
        expected_columns = [
            "component", "original_fraction_mean", "original_fraction_max",
            "is_feasible_mean", "cost_change_percent_mean", "cost_change_percent_min",
            "cost_change_percent_max", "impact_score_mean", "impact_score_max"
        ]
        for col in expected_columns:
            self.assertIn(col, summary.columns)

if __name__ == "__main__":
    unittest.main()
