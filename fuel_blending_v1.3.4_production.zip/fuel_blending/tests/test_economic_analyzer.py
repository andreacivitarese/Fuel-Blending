"""
Tests for the EconomicAnalyzer class, focusing on neutral price calculations.
"""

import pytest
import numpy as np

# Import necessary classes and constants from the fuel_blending package
from fuel_blending.models import Component
from fuel_blending.analysis import EconomicAnalyzer
from fuel_blending.utils.constants import (
    DELTA_TYPE_AS_IS, DELTA_TYPE_FACTOR, DELTA_TYPE_ESCALATED
)

# Test data
FLAT_PRICE = 700.0
MV_USD_T_POSITIVE = 20.0 # Marginal value (cost reduction per unit)
MV_USD_T_NEGATIVE = -15.0 # Marginal cost (cost increase per unit)
MV_USD_T_ZERO = 0.0

# Sample components with different delta types (updated for new Component constructor)
@pytest.fixture
def component_as_is():
    return Component(
        name="CompAsIs",
        delta_type=DELTA_TYPE_AS_IS,
        delta_value=10.0, # Example value, needed for AS_IS
        density=0.7,
        properties={}
    )

@pytest.fixture
def component_factor():
    return Component(
        name="CompFactor",
        delta_type=DELTA_TYPE_FACTOR,
        multiplier=1.05, # Example value, needed for FACTOR
        density=0.8,
        properties={}
    )

@pytest.fixture
def component_escalated():
    return Component(
        name="CompEsc",
        delta_type=DELTA_TYPE_ESCALATED,
        delta_value=15.0, # Example value, needed for ESCALATED
        density=0.75,
        base_density_component=755.0,
        properties={}
    )

@pytest.fixture
def component_escalated_no_base():
    # Test default base density (755.0)
    return Component(
        name="CompEscNoBase",
        delta_type=DELTA_TYPE_ESCALATED,
        delta_value=12.0, # Example value, needed for ESCALATED
        density=0.72,
        properties={}
    )

# --- Test Cases for calculate_neutral_values --- 

def test_neutral_values_as_is_positive_mv(component_as_is):
    """Test neutral values for AS_IS component with positive MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_as_is, MV_USD_T_POSITIVE, FLAT_PRICE
    )
    # delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(-MV_USD_T_POSITIVE)
    assert mult_neut is None

def test_neutral_values_as_is_negative_mv(component_as_is):
    """Test neutral values for AS_IS component with negative MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_as_is, MV_USD_T_NEGATIVE, FLAT_PRICE
    )
    # delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(-MV_USD_T_NEGATIVE)
    assert mult_neut is None

def test_neutral_values_as_is_zero_mv(component_as_is):
    """Test neutral values for AS_IS component with zero MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_as_is, MV_USD_T_ZERO, FLAT_PRICE
    )
    # delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(0.0)
    assert mult_neut is None

def test_neutral_values_factor_positive_mv(component_factor):
    """Test neutral values for FACTOR component with positive MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_factor, MV_USD_T_POSITIVE, FLAT_PRICE
    )
    # mult_neut = 1 - mv_usd_t / flat_price
    expected_mult = 1.0 - (MV_USD_T_POSITIVE / FLAT_PRICE)
    assert delta_neut is None
    assert mult_neut == pytest.approx(expected_mult)

def test_neutral_values_factor_negative_mv(component_factor):
    """Test neutral values for FACTOR component with negative MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_factor, MV_USD_T_NEGATIVE, FLAT_PRICE
    )
    # mult_neut = 1 - mv_usd_t / flat_price
    expected_mult = 1.0 - (MV_USD_T_NEGATIVE / FLAT_PRICE)
    assert delta_neut is None
    assert mult_neut == pytest.approx(expected_mult)

def test_neutral_values_factor_zero_mv(component_factor):
    """Test neutral values for FACTOR component with zero MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_factor, MV_USD_T_ZERO, FLAT_PRICE
    )
    # mult_neut = 1 - mv_usd_t / flat_price
    expected_mult = 1.0
    assert delta_neut is None
    assert mult_neut == pytest.approx(expected_mult)

def test_neutral_values_factor_zero_flat_price(component_factor):
    """Test neutral values for FACTOR component with zero flat price."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_factor, MV_USD_T_POSITIVE, 0.0
    )
    assert delta_neut is None
    assert mult_neut is None # Division by zero

# Note: The current implementation of calculate_neutral_values for ESCALATED
# returns delta_neut = -mv_usd_t, similar to AS_IS, based on the comment
# "Per ora, usiamo delta_neut = -mv_usd_t anche per escalated per coerenza logica."
# We will test this implemented behavior.

def test_neutral_values_escalated_positive_mv(component_escalated):
    """Test neutral values for ESCALATED component with positive MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_escalated, MV_USD_T_POSITIVE, FLAT_PRICE
    )
    # According to current implementation: delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(-MV_USD_T_POSITIVE)
    assert mult_neut is None

def test_neutral_values_escalated_negative_mv(component_escalated):
    """Test neutral values for ESCALATED component with negative MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_escalated, MV_USD_T_NEGATIVE, FLAT_PRICE
    )
    # According to current implementation: delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(-MV_USD_T_NEGATIVE)
    assert mult_neut is None

def test_neutral_values_escalated_zero_mv(component_escalated):
    """Test neutral values for ESCALATED component with zero MV."""
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_escalated, MV_USD_T_ZERO, FLAT_PRICE
    )
    # According to current implementation: delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(0.0)
    assert mult_neut is None

def test_neutral_values_escalated_no_base_density(component_escalated_no_base):
    """Test neutral values for ESCALATED component without explicit base density."""
    # This test mainly ensures it runs without error and confirms the delta_neut logic
    delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
        component_escalated_no_base, MV_USD_T_POSITIVE, FLAT_PRICE
    )
    # According to current implementation: delta_neut = -mv_usd_t
    assert delta_neut == pytest.approx(-MV_USD_T_POSITIVE)
    assert mult_neut is None

# TODO: Add tests for calculate_marginal_value if needed, although it's more complex
#       as it requires a full OptimizationResultModel mock or integration.


