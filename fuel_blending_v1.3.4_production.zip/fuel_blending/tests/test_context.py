"""
Test per il modulo blending.context.

Verifica la logica di validazione e calcolo costi nel BlendingContext,
includendo la densità base di escalation configurabile.
"""

import pytest
import numpy as np
import logging
from typing import List, Dict

from fuel_blending.models.models import Component, Grade, DELTA_TYPE_AS_IS, DELTA_TYPE_FACTOR, DELTA_TYPE_ESCALATED
from fuel_blending.blending.context import BlendingContext, DEFAULT_BASE_DENSITY_ESCALATION
from fuel_blending.utils.exceptions import ConfigurationError

# Dati di test
@pytest.fixture
def sample_components() -> List[Component]:
    return [
        Component(name="CompA", delta_type=DELTA_TYPE_AS_IS, density=750, properties={"ron": 90}, delta_value=10.0),
        Component(name="CompB", delta_type=DELTA_TYPE_FACTOR, density=800, properties={"ron": 95}, multiplier=1.1),
        Component(name="CompC_Esc", delta_type=DELTA_TYPE_ESCALATED, density=700, properties={"ron": 85}, delta_value=-5.0),
        Component(name="CompD_ZeroDens", delta_type=DELTA_TYPE_ESCALATED, density=0.0, properties={"ron": 80}, delta_value=5.0),
        # Component(name="CompE_MissingVal", delta_type=DELTA_TYPE_AS_IS, density=720, properties={"ron": 92}), # Manca delta_value -> Rimosso per ora, il test specifico verifica questo errore
        Component(name="CompF_Esc_CompDens", delta_type=DELTA_TYPE_ESCALATED, density=710, properties={"ron": 88}, delta_value=-2.0, base_density_component=740.0),
        Component(name="CompG_Esc_InvalidCompDens", delta_type=DELTA_TYPE_ESCALATED, density=715, properties={"ron": 89}, delta_value=-3.0, base_density_component=0.0),
    ]

@pytest.fixture
def sample_grade() -> Grade:
    return Grade(name="TestGrade", specs={"ron": (91, 93)})

@pytest.fixture
def grade_with_base_density() -> Grade:
    return Grade(name="GradeWithDensity", specs={"ron": (91, 93)}, base_density_escalation=760.0)

@pytest.fixture
def grade_with_invalid_base_density() -> Grade:
    return Grade(name="GradeInvalidDensity", specs={"ron": (91, 93)}, base_density_escalation=-10.0)

# Test per il calcolo dei costi
def test_component_cost_calculation_as_is(sample_components, sample_grade):
    """Verifica il calcolo del costo per delta_type=\"as_is\"."""
    context = BlendingContext(
        components=[sample_components[0]],
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    expected_cost = 700.0 + 10.0
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isclose(context._component_costs[0], expected_cost)

def test_component_cost_calculation_factor(sample_components, sample_grade):
    """Verifica il calcolo del costo per delta_type=\"factor\"."""
    context = BlendingContext(
        components=[sample_components[1]],
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    expected_cost = 700.0 * 1.1
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isclose(context._component_costs[0], expected_cost)

def test_component_cost_calculation_escalated_default_density(sample_components, sample_grade, caplog):
    """Verifica il calcolo del costo per delta_type=\"escalated\" usando la densità base di default."""
    caplog.set_level(logging.DEBUG)
    context = BlendingContext(
        components=[sample_components[2]], # CompC_Esc
        grade=sample_grade, # Grade senza densità base specifica
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    expected_cost = (700.0 + (-5.0)) * (755.0 / 700.0)
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isclose(context._component_costs[0], expected_cost)
    # Verifica che sia stato loggato l'uso del default
    assert f"Usando densità base di escalation di default ({755.0}) per componente 'CompC_Esc'" in caplog.text

def test_component_cost_calculation_escalated_grade_density(sample_components, grade_with_base_density, caplog):
    """Verifica il calcolo del costo per delta_type=\"escalated\" usando la densità base del grade."""
    caplog.set_level(logging.DEBUG)
    context = BlendingContext(
        components=[sample_components[2]], # CompC_Esc
        grade=grade_with_base_density, # Grade con densità base 760.0
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    expected_cost = (700.0 + (-5.0)) * (760.0 / 700.0)
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isclose(context._component_costs[0], expected_cost)
    # Verifica che NON sia stato loggato l'uso del default
    assert f"Usando densità base di escalation di default" not in caplog.text
    assert f"Costo escalato per 'CompC_Esc': (700.0 + -5.0) * (760.0 [grade] / 700.0)" in caplog.text

def test_component_cost_calculation_escalated_component_density(sample_components, grade_with_base_density, caplog):
    """Verifica il calcolo del costo per delta_type=\"escalated\" usando la densità base del componente (override)."""
    caplog.set_level(logging.DEBUG)
    context = BlendingContext(
        components=[sample_components[5]], # CompF_Esc_CompDens con base_density_component=740.0
        grade=grade_with_base_density, # Grade con densità base 760.0 (che verrà sovrascritta)
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    expected_cost = (700.0 + (-2.0)) * (740.0 / 710.0)
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isclose(context._component_costs[0], expected_cost)
    # Verifica che NON sia stato loggato l'uso del default o del grade
    assert f"Usando densità base di escalation di default" not in caplog.text
    assert f"Costo escalato per 'CompF_Esc_CompDens': (700.0 + -2.0) * (740.0 [component] / 710.0)" in caplog.text

def test_component_cost_calculation_escalated_zero_component_density(sample_components, sample_grade):
    """Verifica che il costo sia infinito per densità componente zero con tipo escalato."""
    context = BlendingContext(
        components=[sample_components[3]], # CompD_ZeroDens
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isinf(context._component_costs[0])

def test_component_cost_calculation_escalated_invalid_component_base_density(sample_components, sample_grade, caplog):
    """Verifica che il costo sia infinito se la densità base del componente non è valida."""
    caplog.set_level(logging.WARNING)
    context = BlendingContext(
        components=[sample_components[6]], # CompG_Esc_InvalidCompDens con base_density_component=0.0
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isinf(context._component_costs[0])
    assert f"Densità base di escalation non valida (0.0 da component) per componente 'CompG_Esc_InvalidCompDens'" in caplog.text

def test_component_cost_calculation_escalated_invalid_grade_base_density(sample_components, grade_with_invalid_base_density, caplog):
    """Verifica che il costo sia infinito se la densità base del grade non è valida e quella del componente è None."""
    caplog.set_level(logging.WARNING)
    context = BlendingContext(
        components=[sample_components[2]], # CompC_Esc senza densità base componente
        grade=grade_with_invalid_base_density, # Grade con densità base -10.0
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    assert context._component_costs is not None
    assert len(context._component_costs) == 1
    assert np.isinf(context._component_costs[0])
    assert f"Densità base di escalation non valida (-10.0 da grade) per componente 'CompC_Esc'" in caplog.text

def test_component_cost_calculation_missing_value(sample_components, sample_grade):
    """Verifica che venga sollevata ConfigurationError se manca un valore richiesto."""
    with pytest.raises(ConfigurationError, match="Componente 'CompE_MissingVal'.*è 'as_is' ma manca 'delta_value'"):
        BlendingContext(
            components=[sample_components[4]],
            grade=sample_grade,
            flat_price=700.0,
            base_density_escalation_default=755.0
        )

def test_get_component_costs(sample_components, grade_with_base_density):
    """Verifica il metodo get_component_costs con diverse densità base."""
    # Usa CompA (as_is), CompB (factor), CompC (escalated, usa grade), CompF (escalated, usa component)
    components_to_test = [sample_components[0], sample_components[1], sample_components[2], sample_components[5]]
    context = BlendingContext(
        components=components_to_test,
        grade=grade_with_base_density, # base_density=760.0
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    costs = context.get_component_costs()
    assert costs is not None
    assert len(costs) == 4
    # CompA (as_is)
    assert np.isclose(costs[0], 700.0 + 10.0)
    # CompB (factor)
    assert np.isclose(costs[1], 700.0 * 1.1)
    # CompC (escalated, usa grade density 760.0)
    assert np.isclose(costs[2], (700.0 - 5.0) * (760.0 / 700.0))
    # CompF (escalated, usa component density 740.0)
    assert np.isclose(costs[3], (700.0 - 2.0) * (740.0 / 710.0))

def test_calculate_total_cost(sample_components, sample_grade):
    """Verifica il calcolo del costo totale del blend."""
    context = BlendingContext(
        components=sample_components[:3],
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    fractions = np.array([0.5, 0.3, 0.2])
    expected_total_cost = (0.5 * context._component_costs[0] +
                           0.3 * context._component_costs[1] +
                           0.2 * context._component_costs[2])
    total_cost = context.calculate_total_cost(fractions)
    assert np.isclose(total_cost, expected_total_cost)

def test_calculate_total_cost_with_inf_component_cost(sample_components, sample_grade):
    """Verifica che il costo totale sia infinito se un costo componente è infinito."""
    context = BlendingContext(
        components=[sample_components[0], sample_components[3]], # Include CompD con costo Inf
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=755.0
    )
    fractions = np.array([0.9, 0.1])
    total_cost = context.calculate_total_cost(fractions)
    assert np.isinf(total_cost)

# Test per la validazione (già presenti in parte, ma aggiungiamo uno specifico)
def test_validation_hc_mass_inconsistency(sample_components, sample_grade):
    """Verifica il warning se hc_mass non è coerente."""
    with pytest.warns(UserWarning, match="hc_mass fornito.*non è coerente"): # BlendingContext usa logger.warning, pytest cattura UserWarning
        context = BlendingContext(
            components=sample_components[:2],
            grade=sample_grade,
            fixed_components={"CompA": 0.1}, # Somma fissi = 0.1
            hc_mass=0.8 # Non coerente, dovrebbe essere 0.9
        )
        # Verifica che hc_mass sia stato corretto
        assert np.isclose(context.hc_mass, 0.9)

# Test per il factory method
def test_factory_method_base_density(sample_components, sample_grade):
    """Verifica che il factory method passi correttamente base_density_escalation_default."""
    base_density_default = 745.0
    context = BlendingContext.from_components(
        components=[sample_components[2]], # CompC_Esc
        grade=sample_grade,
        flat_price=700.0,
        base_density_escalation_default=base_density_default
    )
    assert context.base_density_escalation_default == base_density_default
    # Verifica che il costo sia calcolato usando questo default
    expected_cost = (700.0 - 5.0) * (base_density_default / 700.0)
    assert np.isclose(context.get_component_costs()[0], expected_cost)

