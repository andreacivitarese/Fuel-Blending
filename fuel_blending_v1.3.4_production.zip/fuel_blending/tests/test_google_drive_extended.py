"""
Test per le nuove funzionalità di integrazione con Google Drive.

Questo modulo contiene i test per verificare il corretto funzionamento
delle nuove funzionalità di integrazione con Google Drive:
1. Caricamento dei risultati dell'ottimizzazione su Google Drive
2. Caricamento dei grades da valutare da Google Drive
3. Salvataggio dei risultati della valutazione su Google Drive
"""

import unittest
from unittest.mock import MagicMock, patch
import os
import tempfile
import json
import pandas as pd
from pathlib import Path

from fuel_blending.integrations.google_drive import (
    GoogleDriveIntegration,
    OptimizationResultsExporter,
    GradesToEvaluateExporter,
    GradesToEvaluateLoader
)
from fuel_blending.models import Component, Grade, Additive

class TestGoogleDriveExtendedIntegration(unittest.TestCase):
    """Test per le nuove funzionalità di integrazione con Google Drive."""
    
    def setUp(self):
        """Setup per i test."""
        # Crea un file di credenziali temporaneo
        self.temp_dir = tempfile.TemporaryDirectory()
        self.credentials_path = Path(self.temp_dir.name) / "credentials.json"
        self.token_path = Path(self.temp_dir.name) / "token.json"
        
        # Contenuto del file di credenziali
        credentials_content = {
            "installed": {
                "client_id": "test_client_id",
                "project_id": "test_project_id",
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                "client_secret": "test_client_secret",
                "redirect_uris": ["urn:ietf:wg:oauth:2.0:oob", "http://localhost"]
            }
        }
        
        # Scrivi il file di credenziali
        with open(self.credentials_path, "w") as f:
            json.dump(credentials_content, f)
        
        # Contenuto del file del token
        token_content = {
            "token": "test_token",
            "refresh_token": "test_refresh_token",
            "token_uri": "https://oauth2.googleapis.com/token",
            "client_id": "test_client_id",
            "client_secret": "test_client_secret",
            "scopes": ["https://www.googleapis.com/auth/drive.readonly"]
        }
        
        # Scrivi il file del token
        with open(self.token_path, "w") as f:
            json.dump(token_content, f)
        
        # Crea dati di test
        self.components = [
            Component(
                name="Comp1",
                delta_type="as_is",
                delta_value=5.0,
                density=0.75,
                ron=95.0,
                mon=85.0,
                rvp=10.0,
                sulfur_ppm=10.0,
                benzene=1.0,
                aromatics=20.0,
                olefins=5.0,
                mtbe=0.0,
                t10=50.0,
                t50=100.0,
                e70=30.0,
                oxy_wt=0.0,
                is_ethanol=False
            ),
            Component(
                name="Comp2",
                delta_type="factor",
                multiplier=1.05,
                density=0.73,
                ron=98.0,
                mon=88.0,
                rvp=15.0,
                sulfur_ppm=5.0,
                benzene=0.5,
                aromatics=15.0,
                olefins=3.0,
                mtbe=0.0,
                t10=45.0,
                t50=95.0,
                e70=25.0,
                oxy_wt=0.0,
                is_ethanol=False
            )
        ]
        
        self.grades = [
            Grade(
                name="Grade1",
                specs={
                    "RON": (91, None),
                    "MON": (81, None),
                    "RVP": (None, 60)
                },
                target_mass=1000,
                price_mode="as_is"
            )
        ]
        
        self.candidates = [
            Component(
                name="Candidate1",
                delta_type="as_is",
                density=0.75,
                ron=95.0,
                mon=85.0,
                rvp=10.0,
                sulfur_ppm=10.0,
                benzene=1.0,
                aromatics=20.0,
                olefins=5.0,
                mtbe=0.0,
                t10=50.0,
                t50=100.0,
                e70=30.0,
                oxy_wt=0.0,
                is_ethanol=False
            )
        ]
        
        self.optimization_results = {
            "Grade1": {
                "success": True,
                "cost": 705.0,
                "properties": {
                    "RON": 92.0,
                    "MON": 82.0,
                    "RVP": 12.0,
                    "density": 0.74
                },
                "blend": {
                    "Comp1": 0.6,
                    "Comp2": 0.4
                },
                "flat_price": 700.0
            }
        }
        
        self.evaluation_results = {
            "Candidate1": {
                "Grade1": {
                    "MV_usd_t": 10.0,
                    "delta_neut": 5.0,
                    "mult_neut": None
                }
            }
        }
    
    def tearDown(self):
        """Cleanup dopo i test."""
        self.temp_dir.cleanup()
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleAuthManager')
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveManager')
    @patch('fuel_blending.integrations.google_drive.integration.ExcelReader')
    @patch('fuel_blending.integrations.google_drive.integration.GradesToEvaluateLoader')
    @patch('fuel_blending.integrations.google_drive.integration.OptimizationResultsExporter')
    @patch('fuel_blending.integrations.google_drive.integration.GradesToEvaluateExporter')
    def test_integration_initialization(self, mock_eval_exporter, mock_opt_exporter, mock_grades_loader, 
                                       mock_excel_reader, mock_drive_manager, mock_auth_manager):
        """Test dell'inizializzazione dell'integrazione con Google Drive estesa."""
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Verifica che i gestori siano stati creati correttamente
        mock_auth_manager.assert_called_once_with(str(self.credentials_path), str(self.token_path))
        mock_drive_manager.assert_called_once()
        mock_excel_reader.assert_called_once()
        mock_grades_loader.assert_called_once()
        mock_opt_exporter.assert_called_once()
        mock_eval_exporter.assert_called_once()
    
    @patch('fuel_blending.integrations.google_drive.output.Workbook')
    @patch('fuel_blending.integrations.google_drive.output.pd.DataFrame')
    def test_optimization_results_exporter(self, mock_dataframe, mock_workbook):
        """Test dell'esportatore dei risultati dell'ottimizzazione."""
        # Crea un mock per GoogleDriveIntegration
        mock_integration = MagicMock()
        mock_integration.upload_file.return_value = "test_file_id"
        
        # Crea un OptimizationResultsExporter
        exporter = OptimizationResultsExporter(mock_integration)
        
        # Crea un file Excel con i risultati dell'ottimizzazione
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as temp_file:
            temp_path = temp_file.name
        
        # Configura il mock di Workbook
        mock_workbook_instance = MagicMock()
        mock_workbook.return_value = mock_workbook_instance
        
        # Configura il mock di DataFrame
        mock_dataframe_instance = MagicMock()
        mock_dataframe.return_value = mock_dataframe_instance
        
        # Esegui il metodo da testare
        exporter.create_optimization_results_excel(
            self.optimization_results,
            self.components,
            self.grades,
            temp_path
        )
        
        # Verifica che il workbook sia stato salvato
        mock_workbook_instance.save.assert_called_once_with(temp_path)
        
        # Pulisci
        os.remove(temp_path)
    
    @patch('fuel_blending.integrations.google_drive.output.Workbook')
    @patch('fuel_blending.integrations.google_drive.output.pd.DataFrame')
    def test_evaluation_results_exporter(self, mock_dataframe, mock_workbook):
        """Test dell'esportatore dei risultati della valutazione."""
        # Crea un mock per GoogleDriveIntegration
        mock_integration = MagicMock()
        mock_integration.upload_file.return_value = "test_file_id"
        
        # Crea un GradesToEvaluateExporter
        exporter = GradesToEvaluateExporter(mock_integration)
        
        # Crea un file Excel con i risultati della valutazione
        with tempfile.NamedTemporaryFile(suffix=".xlsx", delete=False) as temp_file:
            temp_path = temp_file.name
        
        # Configura il mock di Workbook
        mock_workbook_instance = MagicMock()
        mock_workbook.return_value = mock_workbook_instance
        
        # Configura il mock di DataFrame
        mock_dataframe_instance = MagicMock()
        mock_dataframe.return_value = mock_dataframe_instance
        
        # Esegui il metodo da testare
        exporter.create_evaluation_results_excel(
            self.evaluation_results,
            self.candidates,
            self.grades,
            temp_path
        )
        
        # Verifica che il workbook sia stato salvato
        mock_workbook_instance.save.assert_called_once_with(temp_path)
        
        # Pulisci
        os.remove(temp_path)
    
    @patch('fuel_blending.integrations.google_drive.grades_loader.pd.read_excel')
    def test_grades_to_evaluate_loader(self, mock_read_excel):
        """Test del caricatore dei grades da valutare."""
        # Configura il mock
        mock_df = pd.DataFrame({
            'name': ['Candidate1', 'Candidate2'],
            'delta_type': ['as_is', 'factor'],
            'delta_value': [5.0, None],
            'multiplier': [None, 1.05],
            'density': [0.75, 0.73],
            'ron': [95.0, 98.0],
            'mon': [85.0, 88.0],
            'rvp': [10.0, 15.0],
            'sulfur_ppm': [10.0, 5.0],
            'benzene': [1.0, 0.5],
            'aromatics': [20.0, 15.0],
            'olefins': [5.0, 3.0],
            'mtbe': [0.0, 0.0],
            't10': [50.0, 45.0],
            't50': [100.0, 95.0],
            'e70': [30.0, 25.0],
            'oxy_wt': [0.0, 0.0],
            'is_ethanol': [False, False]
        })
        mock_read_excel.return_value = mock_df
        
        # Crea un mock per GoogleDriveIntegration
        mock_integration = MagicMock()
        mock_integration.download_file.return_value = "test_file.xlsx"
        
        # Crea un GradesToEvaluateLoader
        loader = GradesToEvaluateLoader(mock_integration)
        
        # Carica i grades da valutare
        candidates = loader.load_grades_to_evaluate_from_file("test_file.xlsx")
        
        # Verifica che i grades da valutare siano stati caricati correttamente
        self.assertEqual(len(candidates), 2)
        self.assertEqual(candidates[0].name, "Candidate1")
        self.assertEqual(candidates[0].delta_type, "as_is")
        self.assertEqual(candidates[0].delta_value, 5.0)
        self.assertEqual(candidates[1].name, "Candidate2")
        self.assertEqual(candidates[1].delta_type, "factor")
        self.assertEqual(candidates[1].multiplier, 1.05)
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveIntegration.upload_file')
    def test_upload_optimization_results(self, mock_upload_file):
        """Test del caricamento dei risultati dell'ottimizzazione su Google Drive."""
        # Configura il mock
        mock_upload_file.return_value = "test_file_id"
        
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Sostituisci i metodi reali con mock
        integration.optimization_exporter = MagicMock()
        integration.optimization_exporter.upload_results_to_google_drive.return_value = "test_file_id"
        
        # Carica i risultati dell'ottimizzazione su Google Drive
        file_id = integration.upload_optimization_results(
            self.optimization_results,
            self.components,
            self.grades,
            folder_id="test_folder_id",
            file_name="test_file_name"
        )
        
        # Verifica che il metodo upload_results_to_google_drive sia stato chiamato
        integration.optimization_exporter.upload_results_to_google_drive.assert_called_once_with(
            self.optimization_results,
            self.components,
            self.grades,
            "test_folder_id",
            "test_file_name"
        )
        
        # Verifica che l'ID del file sia stato restituito
        self.assertEqual(file_id, "test_file_id")
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveIntegration.upload_file')
    def test_upload_evaluation_results(self, mock_upload_file):
        """Test del caricamento dei risultati della valutazione su Google Drive."""
        # Configura il mock
        mock_upload_file.return_value = "test_file_id"
        
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Sostituisci i metodi reali con mock
        integration.evaluation_exporter = MagicMock()
        integration.evaluation_exporter.upload_results_to_google_drive.return_value = "test_file_id"
        
        # Carica i risultati della valutazione su Google Drive
        file_id = integration.upload_evaluation_results(
            self.evaluation_results,
            self.candidates,
            self.grades,
            folder_id="test_folder_id",
            file_name="test_file_name"
        )
        
        # Verifica che il metodo upload_results_to_google_drive sia stato chiamato
        integration.evaluation_exporter.upload_results_to_google_drive.assert_called_once_with(
            self.evaluation_results,
            self.candidates,
            self.grades,
            "test_folder_id",
            "test_file_name"
        )
        
        # Verifica che l'ID del file sia stato restituito
        self.assertEqual(file_id, "test_file_id")
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveIntegration.download_file')
    def test_load_grades_to_evaluate(self, mock_download_file):
        """Test del caricamento dei grades da valutare da Google Drive."""
        # Configura il mock
        mock_download_file.return_value = "test_file.xlsx"
        
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Sostituisci i metodi reali con mock
        integration.grades_loader = MagicMock()
        integration.grades_loader.load_grades_to_evaluate_from_google_drive.return_value = self.candidates
        
        # Carica i grades da valutare da Google Drive
        candidates = integration.load_grades_to_evaluate(file_id="test_file_id")
        
        # Verifica che il metodo load_grades_to_evaluate_from_google_drive sia stato chiamato
        integration.grades_loader.load_grades_to_evaluate_from_google_drive.assert_called_once_with("test_file_id")
        
        # Verifica che i grades da valutare siano stati restituiti
        self.assertEqual(candidates, self.candidates)

if __name__ == "__main__":
    unittest.main()
