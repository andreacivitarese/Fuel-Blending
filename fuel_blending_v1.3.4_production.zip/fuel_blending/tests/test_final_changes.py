# -*- coding: utf-8 -*-
"""
Test per le modifiche finali richieste per la produzione:
- Gestione additivi in ppm per volume e inclusione nel costo.
- Rimozione output non necessari (sensitivity, vecchia eval-candidate).
- Calcolo automatico prezzi neutri nel comando eval-candidate.
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path
import argparse
import copy
from typing import List, Dict # Aggiunto import

# Import necessari dal modulo fuel_blending
from fuel_blending.models import Component, Grade, Additive, OptimizationResultModel
from fuel_blending.blending import BlendingContext, PropertyCalculator
from fuel_blending.optimization import Optimizer, OptimizerConfig
from fuel_blending.analysis import EconomicAnalyzer
from fuel_blending.loaders import DataLoader
from fuel_blending.config import Config
from fuel_blending.utils.constants import PROPERTY_DENSITY
from fuel_blending.commands import commands # Per testare le funzioni dei comandi

# --- Fixtures e Dati di Test ---

@pytest.fixture
def basic_config() -> Config:
    """Configurazione di base per i test."""
    # Crea una configurazione minima necessaria
    return Config()

@pytest.fixture
def sample_components() -> List[Component]:
    """Componenti di esempio."""
    return [
        Component(name="CompA", delta_type="as_is", delta_value=-10, density=750, properties={"ron": 95, "sulfur_ppm": 10, PROPERTY_DENSITY: 750}),
        Component(name="CompB", delta_type="as_is", delta_value=5, density=760, properties={"ron": 90, "sulfur_ppm": 50, PROPERTY_DENSITY: 760}),
        Component(name="Ethanol", delta_type="as_is", delta_value=-50, density=790, properties={"ron": 110, "sulfur_ppm": 1, PROPERTY_DENSITY: 790}, is_ethanol=True)
    ]

@pytest.fixture
def sample_additives() -> List[Additive]:
    """Additivi di esempio."""
    return [
        Additive(name="Add1", cost_usd_per_litre=2.5, density_add=900),
        Additive(name="Add2", cost_usd_per_litre=5.0, density_add=1000)
    ]

@pytest.fixture
def sample_grade_with_additives(sample_additives) -> Grade:
    """Grade di esempio con specifiche e additivi."""
    return Grade(
        name="TestGrade",
        specs={"ron": (92, None), "sulfur_ppm": (None, 30)},
        target_mass=1000,
        additives={"Add1": 100, "Add2": 50} # Add1: 100 ppm_vol, Add2: 50 ppm_vol
    )

@pytest.fixture
def sample_context(sample_components, sample_grade_with_additives, sample_additives) -> BlendingContext:
    """Contesto di blending di esempio con additivi."""
    # Nota: Il costruttore di BlendingContext dovrà essere aggiornato per accettare `available_additives`
    # Per ora, simuliamo la struttura post-modifica
    context = BlendingContext(
        components=sample_components,
        grade=sample_grade_with_additives,
        flat_price=700.0
        # available_additives=sample_additives # Questo verrà aggiunto dopo la modifica
    )
    # Aggiungiamo manualmente gli additivi disponibili per il test
    context.available_additives = sample_additives
    return context

@pytest.fixture
def sample_optimizer(sample_context, basic_config) -> Optimizer:
    """Ottimizzatore di esempio."""
    # Usa una configurazione semplice per i test
    opt_config = OptimizerConfig(solver="SLSQP", options={"maxiter": 50}, use_jacobian=False)
    return Optimizer(sample_context, opt_config)

@pytest.fixture
def sample_opt_result_success() -> OptimizationResultModel:
    """Risultato di ottimizzazione di esempio (successo)."""
    return OptimizationResultModel(
        grade_name="TestGrade",
        success=True,
        message="Optimization successful.",
        component_fractions={"CompA": 0.6, "CompB": 0.4},
        blend_properties={PROPERTY_DENSITY: 754.0, "ron": 93.0, "sulfur_ppm": 26.0},
        total_cost_usd_mt=694.0, # Costo solo idrocarburi
        shadow_prices={
            "ron_min": 1.5, # Prezzo ombra per RON minimo
            "sulfur_ppm_max": 0.1, # Prezzo ombra per Zolfo massimo
            "sum_frac_eq": 700.0 # Costo marginale del blend
        }
    )

# --- Test Cases ---

# 1. Test Gestione Additivi (ppm per volume e costo)

def test_additive_cost_calculation(sample_optimizer, sample_components):
    """Testa il calcolo del costo obiettivo includendo gli additivi."""
    # Simula le frazioni ottimizzate (solo componenti liberi)
    # Assumiamo che CompA e CompB siano liberi
    free_fractions = np.array([0.6, 0.4])
    all_fractions = sample_optimizer.context.reconstruct_fractions(free_fractions)

    # Calcola le proprietà del blend HC
    blend_props = sample_optimizer.calculator.calculate_properties(sample_components, all_fractions)
    blend_density = blend_props.get(PROPERTY_DENSITY)
    assert blend_density is not None and blend_density > 0

    # Calcola costo HC (usando la funzione del context)
    hc_cost = sample_optimizer.context.calculate_total_cost(all_fractions, blend_props)

    # Calcola costo additivi atteso
    expected_add1_cost_per_mt = (100 / 1e6) * (2.5 / blend_density) * 1000 # Convert litre cost to m3, then use density
    expected_add2_cost_per_mt = (50 / 1e6) * (5.0 / blend_density) * 1000
    expected_total_additive_cost = expected_add1_cost_per_mt + expected_add2_cost_per_mt

    # Simula la chiamata alla funzione obiettivo (dopo la modifica)
    # Questo test fallirà finché la funzione obiettivo non sarà modificata
    # total_cost = sample_optimizer._objective_function(free_fractions)

    # Per ora, calcoliamo il costo atteso manualmente
    expected_total_cost = hc_cost + expected_total_additive_cost

    # Placeholder: Verifica che i costi calcolati manualmente siano ragionevoli
    print(f"HC Cost: {hc_cost:.4f}")
    print(f"Blend Density: {blend_density:.4f}")
    print(f"Add1 Cost/mt: {expected_add1_cost_per_mt:.4f}")
    print(f"Add2 Cost/mt: {expected_add2_cost_per_mt:.4f}")
    print(f"Total Additive Cost/mt: {expected_total_additive_cost:.4f}")
    print(f"Expected Total Cost: {expected_total_cost:.4f}")

    # Assertions verranno aggiunte dopo l'implementazione
    # assert abs(total_cost - expected_total_cost) < 1e-4
    pytest.skip("Test richiede implementazione del costo additivi in Optimizer._objective_function")

# 2. Test Modifiche Output (Rimozione Comandi/Output)

def test_sensitivity_command_removed():
    """Verifica che il comando sensitivity sia stato rimosso da argparse."""
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command")
    # Simula l'aggiunta dei parser come in cli.py (ma senza sensitivity)
    optimize_parser = subparsers.add_parser("optimize")
    eval_candidate_parser = subparsers.add_parser("eval-candidate")

    with pytest.raises(SystemExit): # Argparse esce se il comando non è valido
        parser.parse_args(["sensitivity"])

    # Verifica anche che la funzione non esista più in commands (dopo la modifica)
    assert not hasattr(commands, "command_sensitivity")
    assert not hasattr(commands, "_print_sensitivity_results_table")

# 3. Test Calcolo Prezzo Neutro

def test_calculate_neutral_price(sample_components, sample_grade_with_additives, sample_opt_result_success):
    """Testa la funzione calculate_neutral_price di EconomicAnalyzer."""
    comp_a = sample_components[0]
    comp_b = sample_components[1]
    ethanol = sample_components[2]
    grade = sample_grade_with_additives
    shadow_prices = sample_opt_result_success.shadow_prices
    flat_price = 700.0

    # Calcola MV per CompA
    # MV = lambda_ron_min * ron_A - lambda_sulfur_max * sulfur_A
    mv_a = shadow_prices["ron_min"] * comp_a.properties["ron"] \
           - shadow_prices["sulfur_ppm_max"] * comp_a.properties["sulfur_ppm"]
    expected_neutral_price_a = flat_price - mv_a

    # Calcola MV per CompB
    mv_b = shadow_prices["ron_min"] * comp_b.properties["ron"] \
           - shadow_prices["sulfur_ppm_max"] * comp_b.properties["sulfur_ppm"]
    expected_neutral_price_b = flat_price - mv_b

    # Usa la funzione (dopo la modifica)
    # neutral_price_a = EconomicAnalyzer.calculate_neutral_price(comp_a, grade, shadow_prices, flat_price)
    # neutral_price_b = EconomicAnalyzer.calculate_neutral_price(comp_b, grade, shadow_prices, flat_price)
    # neutral_price_ethanol = EconomicAnalyzer.calculate_neutral_price(ethanol, grade, shadow_prices, flat_price)

    # Placeholder: Verifica calcoli manuali
    print(f"MV CompA: {mv_a:.4f}, Expected Neutral Price A: {expected_neutral_price_a:.4f}")
    print(f"MV CompB: {mv_b:.4f}, Expected Neutral Price B: {expected_neutral_price_b:.4f}")

    # Assertions verranno aggiunte dopo l'implementazione
    # assert neutral_price_a is not None
    # assert abs(neutral_price_a - expected_neutral_price_a) < 1e-4
    # assert neutral_price_b is not None
    # assert abs(neutral_price_b - expected_neutral_price_b) < 1e-4
    # assert neutral_price_ethanol is None # Etanolo dovrebbe restituire None
    pytest.skip("Test richiede implementazione/modifica di EconomicAnalyzer.calculate_neutral_price")

# Aggiungere altri test per:
# - Gestione errori nel calcolo del prezzo neutro (es. shadow prices mancanti)
# - Funzionamento del comando eval-candidate riscritto (test di integrazione)
# - Corretto caricamento dei componenti da valutare da Excel
# - Corretto output (tabella o file) del comando eval-candidate riscritto

