"""
Test per l'integrazione con Google Drive.

Questo modulo contiene i test per verificare il corretto funzionamento
dell'integrazione con Google Drive.
"""

import unittest
from unittest.mock import MagicMock, patch
import os
import tempfile
import json
import pandas as pd
from pathlib import Path

from fuel_blending.integrations.google_drive import (
    GoogleAuthManager,
    GoogleDriveManager,
    ExcelReader,
    GoogleDriveIntegration
)
from fuel_blending.models import Component, Grade, Additive
from fuel_blending.utils.exceptions import GoogleDriveError, DataLoadError

class TestGoogleDriveIntegration(unittest.TestCase):
    """Test per l'integrazione con Google Drive."""
    
    def setUp(self):
        """Setup per i test."""
        # Crea un file di credenziali temporaneo
        self.temp_dir = tempfile.TemporaryDirectory()
        self.credentials_path = Path(self.temp_dir.name) / "credentials.json"
        self.token_path = Path(self.temp_dir.name) / "token.json"
        
        # Contenuto del file di credenziali
        credentials_content = {
            "installed": {
                "client_id": "test_client_id",
                "project_id": "test_project_id",
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                "client_secret": "test_client_secret",
                "redirect_uris": ["urn:ietf:wg:oauth:2.0:oob", "http://localhost"]
            }
        }
        
        # Scrivi il file di credenziali
        with open(self.credentials_path, "w") as f:
            json.dump(credentials_content, f)
        
        # Contenuto del file del token
        token_content = {
            "token": "test_token",
            "refresh_token": "test_refresh_token",
            "token_uri": "https://oauth2.googleapis.com/token",
            "client_id": "test_client_id",
            "client_secret": "test_client_secret",
            "scopes": ["https://www.googleapis.com/auth/drive.readonly"]
        }
        
        # Scrivi il file del token
        with open(self.token_path, "w") as f:
            json.dump(token_content, f)
    
    def tearDown(self):
        """Cleanup dopo i test."""
        self.temp_dir.cleanup()
    
    @patch('fuel_blending.integrations.google_drive.auth.Credentials')
    def test_auth_manager_initialization(self, mock_credentials):
        """Test dell'inizializzazione del gestore dell'autenticazione."""
        # Crea un GoogleAuthManager
        auth_manager = GoogleAuthManager(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Verifica che i percorsi siano stati impostati correttamente
        self.assertEqual(auth_manager.credentials_file, str(self.credentials_path))
        self.assertEqual(auth_manager.token_file, str(self.token_path))
        self.assertEqual(auth_manager.scopes, ["https://www.googleapis.com/auth/drive.readonly"])
    
    @patch('fuel_blending.integrations.google_drive.auth.Credentials')
    @patch('fuel_blending.integrations.google_drive.auth.InstalledAppFlow')
    def test_auth_manager_authenticate(self, mock_flow, mock_credentials):
        """Test dell'autenticazione del gestore dell'autenticazione."""
        # Configura il mock
        mock_credentials.from_authorized_user_info.return_value.valid = True
        
        # Crea un GoogleAuthManager
        auth_manager = GoogleAuthManager(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Autentica
        credentials = auth_manager.authenticate()
        
        # Verifica che il metodo from_authorized_user_info sia stato chiamato
        mock_credentials.from_authorized_user_info.assert_called_once()
        
        # Verifica che le credenziali siano state restituite
        self.assertIsNotNone(credentials)
    
    @patch('fuel_blending.integrations.google_drive.drive.build')
    def test_drive_manager_initialization(self, mock_build):
        """Test dell'inizializzazione del gestore di Google Drive."""
        # Crea un mock per GoogleAuthManager
        mock_auth_manager = MagicMock()
        
        # Crea un GoogleDriveManager
        drive_manager = GoogleDriveManager(mock_auth_manager)
        
        # Verifica che il gestore dell'autenticazione sia stato impostato correttamente
        self.assertEqual(drive_manager.auth_manager, mock_auth_manager)
        self.assertIsNone(drive_manager.service)
    
    @patch('fuel_blending.integrations.google_drive.drive.build')
    def test_drive_manager_connect(self, mock_build):
        """Test della connessione del gestore di Google Drive."""
        # Crea un mock per GoogleAuthManager
        mock_auth_manager = MagicMock()
        mock_auth_manager.get_credentials.return_value = "test_credentials"
        
        # Crea un GoogleDriveManager
        drive_manager = GoogleDriveManager(mock_auth_manager)
        
        # Connetti
        drive_manager.connect()
        
        # Verifica che il metodo get_credentials sia stato chiamato
        mock_auth_manager.get_credentials.assert_called_once()
        
        # Verifica che il metodo build sia stato chiamato
        mock_build.assert_called_once_with('drive', 'v3', credentials="test_credentials")
        
        # Verifica che il servizio sia stato impostato
        self.assertIsNotNone(drive_manager.service)
    
    @patch('fuel_blending.integrations.google_drive.excel.pd.read_excel')
    def test_excel_reader_read_components(self, mock_read_excel):
        """Test della lettura dei componenti da un file Excel."""
        # Configura il mock
        mock_df = pd.DataFrame({
            'name': ['Comp1', 'Comp2'],
            'delta_type': ['as_is', 'factor'],
            'delta_value': [5.0, None],
            'multiplier': [None, 1.05],
            'density': [0.75, 0.73],
            'ron': [95.0, 98.0],
            'mon': [85.0, 88.0],
            'rvp': [10.0, 15.0],
            'sulfur_ppm': [10.0, 5.0],
            'benzene': [1.0, 0.5],
            'aromatics': [20.0, 15.0],
            'olefins': [5.0, 3.0],
            'mtbe': [0.0, 0.0],
            't10': [50.0, 45.0],
            't50': [100.0, 95.0],
            'e70': [30.0, 25.0],
            'oxy_wt': [0.0, 0.0],
            'is_ethanol': [False, False]
        })
        mock_read_excel.return_value = mock_df
        
        # Crea un mock per GoogleDriveManager
        mock_drive_manager = MagicMock()
        mock_drive_manager.download_file.return_value = "test_file.xlsx"
        
        # Crea un ExcelReader
        excel_reader = ExcelReader(mock_drive_manager)
        
        # Leggi i componenti
        components = excel_reader.read_components("test_file_id")
        
        # Verifica che il metodo download_file sia stato chiamato
        mock_drive_manager.download_file.assert_called_once_with("test_file_id")
        
        # Verifica che il metodo read_excel sia stato chiamato
        mock_read_excel.assert_called_once()
        
        # Verifica che i componenti siano stati letti correttamente
        self.assertEqual(len(components), 2)
        self.assertEqual(components[0].name, "Comp1")
        self.assertEqual(components[0].delta_type, "as_is")
        self.assertEqual(components[0].delta_value, 5.0)
        self.assertEqual(components[1].name, "Comp2")
        self.assertEqual(components[1].delta_type, "factor")
        self.assertEqual(components[1].multiplier, 1.05)
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleAuthManager')
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveManager')
    @patch('fuel_blending.integrations.google_drive.integration.ExcelReader')
    def test_integration_initialization(self, mock_excel_reader, mock_drive_manager, mock_auth_manager):
        """Test dell'inizializzazione dell'integrazione con Google Drive."""
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Verifica che i gestori siano stati creati correttamente
        mock_auth_manager.assert_called_once_with(str(self.credentials_path), str(self.token_path))
        mock_drive_manager.assert_called_once()
        mock_excel_reader.assert_called_once()
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleAuthManager')
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveManager')
    @patch('fuel_blending.integrations.google_drive.integration.ExcelReader')
    def test_integration_setup(self, mock_excel_reader, mock_drive_manager, mock_auth_manager):
        """Test della configurazione dell'integrazione con Google Drive."""
        # Configura i mock
        mock_auth_manager_instance = mock_auth_manager.return_value
        mock_drive_manager_instance = mock_drive_manager.return_value
        
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Configura l'integrazione
        integration.setup()
        
        # Verifica che i metodi authenticate e connect siano stati chiamati
        mock_auth_manager_instance.authenticate.assert_called_once()
        mock_drive_manager_instance.connect.assert_called_once()
    
    @patch('fuel_blending.integrations.google_drive.integration.GoogleAuthManager')
    @patch('fuel_blending.integrations.google_drive.integration.GoogleDriveManager')
    @patch('fuel_blending.integrations.google_drive.integration.ExcelReader')
    def test_integration_load_data(self, mock_excel_reader, mock_drive_manager, mock_auth_manager):
        """Test del caricamento dei dati dall'integrazione con Google Drive."""
        # Configura i mock
        mock_drive_manager_instance = mock_drive_manager.return_value
        mock_drive_manager_instance.service = True  # Simula che il servizio sia già connesso
        
        mock_excel_reader_instance = mock_excel_reader.return_value
        mock_excel_reader_instance.read_components.return_value = [
            Component(
                name="Comp1",
                delta_type="as_is",
                delta_value=5.0,
                density=0.75,
                ron=95.0,
                mon=85.0,
                rvp=10.0,
                sulfur_ppm=10.0,
                benzene=1.0,
                aromatics=20.0,
                olefins=5.0,
                mtbe=0.0,
                t10=50.0,
                t50=100.0,
                e70=30.0,
                oxy_wt=0.0,
                is_ethanol=False
            )
        ]
        
        mock_excel_reader_instance.read_grades.return_value = [
            Grade(
                name="Grade1",
                specs={
                    "RON": (91, None),
                    "MON": (81, None),
                    "RVP": (None, 60)
                },
                target_mass=1000,
                price_mode="as_is"
            )
        ]
        
        mock_excel_reader_instance.read_additives.return_value = {
            "Add1": Additive(
                name="Add1",
                cost_usd_per_litre=1.5,
                density_add=0.8
            )
        }
        
        # Crea un'integrazione con Google Drive
        integration = GoogleDriveIntegration(
            credentials_file=str(self.credentials_path),
            token_file=str(self.token_path)
        )
        
        # Carica i dati
        data = integration.load_data(
            components_file_id="components_file_id",
            grades_file_id="grades_file_id",
            additives_file_id="additives_file_id"
        )
        
        # Verifica che i metodi read_components, read_grades e read_additives siano stati chiamati
        mock_excel_reader_instance.read_components.assert_called_once_with("components_file_id", 0)
        mock_excel_reader_instance.read_grades.assert_called_once_with("grades_file_id", 0)
        mock_excel_reader_instance.read_additives.assert_called_once_with("additives_file_id", 0)
        
        # Verifica che i dati siano stati caricati correttamente
        self.assertEqual(len(data.components), 1)
        self.assertEqual(data.components[0].name, "Comp1")
        self.assertEqual(len(data.grades), 1)
        self.assertEqual(data.grades[0].name, "Grade1")
        self.assertEqual(len(data.additives), 1)
        self.assertEqual(data.additives["Add1"].name, "Add1")

if __name__ == "__main__":
    unittest.main()
