"""
Test per il modulo blending.properties.
"""

import pytest
import numpy as np
from typing import List, Dict # Added missing import

# Assicurati che gli import funzionino se eseguiti dalla root del progetto
from fuel_blending.blending.properties import PropertyCalculator, _ron_to_rl, _rl_to_ron, _mon_to_ml, _ml_to_mon
from fuel_blending.utils.constants import (
    PROPERTY_RON, PROPERTY_MON, PROPERTY_RVP, PROPERTY_DENSITY,
    PROPERTY_SULFUR_PPM, PROPERTY_BENZENE, PROPERTY_AROMATICS,
    PROPERTY_OLEFINS, PROPERTY_E150, PROPERTY_E70, PROPERTY_OXY_WT,
    # PROPERTY_T10, # Removed T10 import
    PROPERTY_T50, PROPERTY_MTBE, PROPERTY_RON_AVERAGE,
    DELTA_TYPE_AS_IS # Import delta type constant
)
from fuel_blending.utils.exceptions import PropertyCalculationError
from fuel_blending.models import Component # Importa Component

@pytest.fixture
def calculator() -> PropertyCalculator:
    """Fixture per creare un PropertyCalculator con valori di default."""
    return PropertyCalculator()

@pytest.fixture
def calculator_with_ron_linear_min() -> PropertyCalculator:
    """Fixture per creare un PropertyCalculator con ron_linear_min impostato."""
    return PropertyCalculator(ron_linear_min=92.0)

# Dati di esempio per i componenti (aggiornato per il nuovo costruttore Component)
@pytest.fixture
def components_data() -> List[Component]:
    """Fixture per creare una lista di Component di esempio."""
    return [
        Component(
            name="CompA",
            delta_type=DELTA_TYPE_AS_IS, # Aggiunto delta_type
            delta_value=0.0, # Aggiunto valore dummy per test
            density=750.0,
            properties={
                PROPERTY_RON: 95.0,
                PROPERTY_MON: 85.0,
                PROPERTY_RVP: 10.0,
                PROPERTY_SULFUR_PPM: 10.0,
                PROPERTY_T50: 100.0,
                PROPERTY_OXY_WT: 0.0,
                PROPERTY_BENZENE: 1.0,
                PROPERTY_AROMATICS: 20.0,
                PROPERTY_OLEFINS: 5.0,
                PROPERTY_MTBE: 0.0,
                PROPERTY_E70: 30.0,
                PROPERTY_E150: 90.0
            }
        ),
        Component(
            name="CompB",
            delta_type=DELTA_TYPE_AS_IS, # Aggiunto delta_type
            delta_value=0.0, # Aggiunto valore dummy per test
            density=720.0,
            properties={
                PROPERTY_RON: 90.0,
                PROPERTY_MON: 80.0,
                PROPERTY_RVP: 8.0,
                PROPERTY_SULFUR_PPM: 20.0,
                PROPERTY_T50: 95.0,
                PROPERTY_OXY_WT: 0.0,
                PROPERTY_BENZENE: 0.5,
                PROPERTY_AROMATICS: 15.0,
                PROPERTY_OLEFINS: 3.0,
                PROPERTY_MTBE: 0.0,
                PROPERTY_E70: 25.0,
                PROPERTY_E150: 85.0
            }
        ),
        Component(
            name="Ethanol",
            delta_type=DELTA_TYPE_AS_IS, # Aggiunto delta_type
            delta_value=0.0, # Aggiunto valore dummy per test
            density=790.0,
            properties={
                PROPERTY_RON: 108.0,
                PROPERTY_MON: 89.0,
                PROPERTY_RVP: 55.0,
                PROPERTY_SULFUR_PPM: 1.0,
                PROPERTY_T50: 78.0,
                PROPERTY_OXY_WT: 34.7,
                PROPERTY_BENZENE: 0.1,
                PROPERTY_AROMATICS: 0.0,
                PROPERTY_OLEFINS: 0.0,
                PROPERTY_MTBE: 0.0,
                PROPERTY_E70: 78.0,
                PROPERTY_E150: 78.0
            },
            is_ethanol=True
        )
    ]

# --- Helper per calcolare frazioni volumetriche ---
def calculate_volume_fractions(components: List[Component], w: np.ndarray) -> np.ndarray:
    """Calcola le frazioni volumetriche dalle frazioni massiche."""
    densities = np.array([c.density for c in components], dtype=np.float64)
    safe_densities = np.maximum(densities, 1e-9)
    w_over_d = w / safe_densities
    v_sum = np.sum(w_over_d)
    if v_sum < 1e-9:
        return np.zeros_like(w)
    return w_over_d / v_sum

# --- Test per proprietà lineari (per massa o volume) ---
@pytest.mark.parametrize(
    "prop_name, fractions_mass, expected_value",
    [
        # Densità (lineare per volume, ma calcolata da PropertyCalculator)
        (PROPERTY_DENSITY, [0.5, 0.5, 0.0], 734.693877), # Media armonica pesata
        (PROPERTY_DENSITY, [0.4, 0.4, 0.2], 745.5109), # Con etanolo
        # Oxygen (lineare per massa)
        (PROPERTY_OXY_WT, [0.4, 0.4, 0.2], 0.2 * 34.7), # Solo da etanolo
        (PROPERTY_OXY_WT, [0.5, 0.5, 0.0], 0.0),
        # Sulfur (lineare per volume)
        (PROPERTY_SULFUR_PPM, [0.8, 0.1, 0.1], 11.94), # ~ (0.8*10 + 0.1*20 + 0.1*1) basato su volume
        # Benzene (lineare per volume)
        (PROPERTY_BENZENE, [0.4, 0.4, 0.2], 0.678), # ~ (0.4*1.0 + 0.4*0.5 + 0.2*0.1) basato su volume
        # Aromatics (lineare per volume)
        (PROPERTY_AROMATICS, [0.4, 0.4, 0.2], 13.90), # ~ (0.4*20 + 0.4*15 + 0.2*0) basato su volume
        # Olefins (lineare per volume)
        (PROPERTY_OLEFINS, [0.4, 0.4, 0.2], 3.179), # ~ (0.4*5 + 0.4*3 + 0.2*0) basato su volume
        # MTBE (lineare per volume)
        (PROPERTY_MTBE, [0.4, 0.4, 0.2], 0.0),
        # T50 (lineare per volume)
        (PROPERTY_T50, [0.4, 0.4, 0.2], 92.95), # ~ (0.4*100 + 0.4*95 + 0.2*78) basato su volume
        # E70 (lineare per volume)
        (PROPERTY_E70, [0.4, 0.4, 0.2], 37.48), # ~ (0.4*30 + 0.4*25 + 0.2*78) basato su volume
        # E150 (lineare per volume)
        (PROPERTY_E150, [0.4, 0.4, 0.2], 85.57), # ~ (0.4*90 + 0.4*85 + 0.2*78) basato su volume
    ]
)
def test_linear_properties(calculator: PropertyCalculator, components_data: List[Component], prop_name: str, fractions_mass: list[float], expected_value: float):
    """Testa il calcolo delle proprietà lineari (massa o volume)."""
    w = np.array(fractions_mass)
    # Modifica per accedere alle proprietà tramite il dizionario
    # Questo test ora verifica PropertyCalculator, che internamente accede alle props
    properties = calculator.calculate_properties(components_data, w)
    assert properties[prop_name] == pytest.approx(expected_value, rel=1e-3)

# --- Test per RVP (non lineare) ---
def test_rvp_calculation(calculator: PropertyCalculator, components_data: List[Component]):
    """Testa il calcolo della RVP (non lineare)."""
    w = np.array([0.4, 0.4, 0.2]) # 40% A, 40% B, 20% Ethanol
    v = calculate_volume_fractions(components_data, w)
    # Modifica per accedere a RVP tramite il dizionario properties
    rvp_values = np.array([c.properties[PROPERTY_RVP] for c in components_data])

    # Calcolo atteso (usando exp=1.25)
    rvp_pow = rvp_values ** calculator.rvp_exp
    rvp_blend_index = np.sum(v * rvp_pow)
    expected_rvp = rvp_blend_index ** (1.0 / calculator.rvp_exp)

    properties = calculator.calculate_properties(components_data, w)
    assert properties[PROPERTY_RVP] == pytest.approx(expected_rvp)

# --- Test per RON (non lineare) ---
def test_ron_calculation(calculator: PropertyCalculator, components_data: List[Component]):
    """Testa il calcolo del RON (non lineare)."""
    w = np.array([0.4, 0.4, 0.2]) # 40% A, 40% B, 20% Ethanol
    v = calculate_volume_fractions(components_data, w)
    # Modifica per accedere a RON tramite il dizionario properties
    ron_values = np.array([c.properties[PROPERTY_RON] for c in components_data])

    # Calcolo atteso non lineare
    ron_linear_values = np.array([_ron_to_rl(r, calculator.ron_linear_min) for r in ron_values])
    ron_linear_blend = np.sum(v * ron_linear_values)
    expected_ron = _rl_to_ron(ron_linear_blend, calculator.ron_linear_min)
    # expected_ron ~ 98.198

    properties = calculator.calculate_properties(components_data, w)
    assert properties[PROPERTY_RON] == pytest.approx(expected_ron)
    assert properties[PROPERTY_RON_AVERAGE] == pytest.approx(expected_ron) # Verifica anche RON_AVERAGE

def test_ron_calculation_with_linear_min(calculator_with_ron_linear_min: PropertyCalculator, components_data: List[Component]):
    """Testa il calcolo del RON con ron_linear_min impostato."""
    calculator = calculator_with_ron_linear_min
    assert calculator.ron_linear_min == 92.0

    w = np.array([0.4, 0.4, 0.2]) # 40% A, 40% B, 20% Ethanol
    v = calculate_volume_fractions(components_data, w)
    # Modifica per accedere a RON tramite il dizionario properties
    ron_values = np.array([c.properties[PROPERTY_RON] for c in components_data]) # [95.0, 90.0, 108.0]

    # Calcolo atteso non lineare con soglia 92.0
    # CompB (90.0) è sotto la soglia, quindi usa 90.0 come valore lineare
    # CompA (95.0) e Ethanol (108.0) sono sopra, usa 10**(ron/100)
    ron_linear_values = np.array([
        _ron_to_rl(95.0, calculator.ron_linear_min), # 10**(95/100)
        _ron_to_rl(90.0, calculator.ron_linear_min), # 90.0 (sotto soglia)
        _ron_to_rl(108.0, calculator.ron_linear_min) # 10**(108/100)
    ])
    ron_linear_blend = np.sum(v * ron_linear_values)
    expected_ron = _rl_to_ron(ron_linear_blend, calculator.ron_linear_min)

    properties = calculator.calculate_properties(components_data, w)
    assert properties[PROPERTY_RON] == pytest.approx(expected_ron)

# --- Test per MON (non lineare) ---
def test_mon_calculation(calculator: PropertyCalculator, components_data: List[Component]):
    """Testa il calcolo del MON (non lineare)."""
    w = np.array([0.4, 0.4, 0.2]) # 40% A, 40% B, 20% Ethanol
    v = calculate_volume_fractions(components_data, w)
    # Modifica per accedere a MON tramite il dizionario properties
    mon_values = np.array([c.properties[PROPERTY_MON] for c in components_data])

    # Calcolo atteso non lineare
    mon_linear_values = np.array([_mon_to_ml(m) for m in mon_values])
    mon_linear_blend = np.sum(v * mon_linear_values)
    expected_mon = _ml_to_mon(mon_linear_blend)
    # expected_mon ~ 83.798

    properties = calculator.calculate_properties(components_data, w)
    assert properties[PROPERTY_MON] == pytest.approx(expected_mon)

# --- Test per proprietà non supportata ---
def test_unsupported_property(calculator: PropertyCalculator, components_data: List[Component]):
    """Testa il comportamento con una proprietà non supportata."""
    w = np.array([0.5, 0.3, 0.2])
    # Prova a calcolare una proprietà inesistente
    with pytest.raises(KeyError): # calculate_properties ora solleva KeyError se la prop non esiste
         props = calculator.calculate_properties(components_data, w)
         _ = props["non_existent_prop"]

# --- Test con input vuoti o non validi ---
def test_invalid_inputs(calculator: PropertyCalculator):
    """Testa il comportamento con input non validi."""
    with pytest.raises(PropertyCalculationError, match="nessun componente o frazione"):
        calculator.calculate_properties([], np.array([]))
    with pytest.raises(PropertyCalculationError, match="Lunghezze diverse"):
        # Crea componenti fittizi per il test (aggiornato per il nuovo costruttore)
        comp1 = Component(name="C1", delta_type=DELTA_TYPE_AS_IS, density=700, properties={})
        comp2 = Component(name="C2", delta_type=DELTA_TYPE_AS_IS, density=800, properties={})
        calculator.calculate_properties([comp1, comp2], np.array([0.5]))

# --- Test per derivate (solo verifiche di base sulla forma e NaN) ---
def test_derivative_calculation_shape(calculator: PropertyCalculator, components_data: List[Component]):
    """Testa che le derivate abbiano la forma corretta."""
    w = np.array([0.4, 0.4, 0.2])
    n = len(components_data)
    derivatives = calculator.calculate_property_derivatives(components_data, w)

    assert isinstance(derivatives, dict)
    # Verifica che tutte le proprietà calcolate abbiano derivate
    calculated_props = calculator.calculate_properties(components_data, w)
    assert set(derivatives.keys()) == set(calculated_props.keys())

    for prop, jac in derivatives.items():
        assert isinstance(jac, np.ndarray), f"Jacobian for {prop} is not a numpy array"
        assert jac.shape == (n,), f"Jacobian for {prop} has incorrect shape {jac.shape}, expected ({n},)"
        assert np.all(np.isfinite(jac)), f"Jacobian for {prop} contains NaN or Inf: {jac}"


