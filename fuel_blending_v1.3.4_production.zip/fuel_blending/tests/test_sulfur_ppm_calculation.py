"""
Test per verificare la correzione del calcolo del sulfur_ppm.

Questo modulo contiene test specifici per verificare che il calcolo
del sulfur_ppm utilizzi correttamente le frazioni volumetriche invece
delle frazioni massiche.
"""

import unittest
import numpy as np
from fuel_blending.blending.properties import PropertyCalculator
from fuel_blending.models import Component

class TestSulfurPpmCalculation(unittest.TestCase):
    """Test per il calcolo del sulfur_ppm."""
    
    def setUp(self):
        """Setup per i test."""
        # Crea un calcolatore di proprietà
        self.calculator = PropertyCalculator(rvp_exp=1.25)
        
        # Crea componenti di test con densità diverse e valori sulfur_ppm diversi
        self.components = [
            Component(
                name="Comp1",
                delta_type="as_is",
                delta_value=5.0,
                density=0.75,
                properties={
                    "ron": 95.0,
                    "mon": 85.0,
                    "rvp": 10.0,
                    "sulfur_ppm": 10.0,
                    "benzene": 1.0,
                    "aromatics": 20.0,
                    "olefins": 5.0,
                    "mtbe": 0.0,
                    # "t10": 50.0, # Removed as per properties.py
                    "t50": 100.0,
                    "e70": 30.0,
                    "oxy_wt": 0.0
                },
                is_ethanol=False
            ),
            Component(
                name="Comp2",
                delta_type="factor",
                multiplier=1.05,
                density=0.85,
                properties={
                    "ron": 98.0,
                    "mon": 88.0,
                    "rvp": 15.0,
                    "sulfur_ppm": 50.0,
                    "benzene": 0.5,
                    "aromatics": 15.0,
                    "olefins": 3.0,
                    "mtbe": 0.0,
                    # "t10": 45.0, # Removed as per properties.py
                    "t50": 95.0,
                    "e70": 25.0,
                    "oxy_wt": 50.0
                },
                is_ethanol=False
            )
        ]
    
    def test_sulfur_ppm_calculation_with_equal_volume_fractions(self):
        """
        Test del calcolo del sulfur_ppm con frazioni volumetriche uguali.
        
        Con frazioni volumetriche uguali, il valore di sulfur_ppm dovrebbe
        essere la media dei valori dei componenti.
        """
        # Calcola le frazioni di massa che corrispondono a frazioni volumetriche uguali
        densities = np.array([c.density for c in self.components])
        v_equal = np.array([0.5, 0.5])
        w_unnorm = v_equal * densities
        w = w_unnorm / np.sum(w_unnorm)
        
        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)
        
        # Verifica che sulfur_ppm sia la media dei valori dei componenti
        sulfur_values = np.array([c.properties["sulfur_ppm"] for c in self.components])
        expected_sulfur = np.dot(v_equal, sulfur_values)
        self.assertAlmostEqual(properties["sulfur_ppm"], expected_sulfur, places=5)
    
    def test_sulfur_ppm_calculation_with_different_volume_fractions(self):
        """
        Test del calcolo del sulfur_ppm con frazioni volumetriche diverse.
        
        Con frazioni volumetriche diverse, il valore di sulfur_ppm dovrebbe
        essere la media pesata dei valori dei componenti, con i pesi dati
        dalle frazioni volumetriche.
        """
        # Calcola le frazioni di massa che corrispondono a frazioni volumetriche specifiche
        densities = np.array([c.density for c in self.components])
        v_target = np.array([0.7, 0.3])
        w_unnorm = v_target * densities
        w = w_unnorm / np.sum(w_unnorm)
        
        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)
        
        # Verifica che sulfur_ppm sia la media pesata dei valori dei componenti
        sulfur_values = np.array([c.properties["sulfur_ppm"] for c in self.components])
        expected_sulfur = np.dot(v_target, sulfur_values)
        self.assertAlmostEqual(properties["sulfur_ppm"], expected_sulfur, places=5)
    
    def test_sulfur_ppm_calculation_vs_mass_fractions(self):
        """
        Test che verifica che il calcolo del sulfur_ppm utilizzi le frazioni volumetriche
        e non le frazioni massiche.
        
        Se il calcolo utilizzasse erroneamente le frazioni massiche, il risultato
        sarebbe diverso a causa delle diverse densità dei componenti.
        """
        # Frazioni di massa
        w = np.array([0.5, 0.5])
        
        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)
        
        # Calcola le frazioni volumetriche
        densities = np.array([c.density for c in self.components])
        v_unnorm = w / densities
        v = v_unnorm / np.sum(v_unnorm)
        
        # Calcola sulfur_ppm usando le frazioni volumetriche (metodo corretto)
        sulfur_values = np.array([c.properties["sulfur_ppm"] for c in self.components])
        correct_sulfur = np.dot(v, sulfur_values)
        
        # Calcola sulfur_ppm usando le frazioni massiche (metodo errato)
        incorrect_sulfur = np.dot(w, sulfur_values)
        
        # Verifica che il valore calcolato sia uguale a quello corretto
        # e diverso da quello errato
        self.assertAlmostEqual(properties["sulfur_ppm"], correct_sulfur, places=5)
        self.assertNotAlmostEqual(properties["sulfur_ppm"], incorrect_sulfur, places=5)
    
    def test_oxy_wt_calculation_vs_volume_fractions(self):
        """
        Test che verifica che il calcolo dell'oxy_wt utilizzi le frazioni massiche
        e non le frazioni volumetriche.
        
        Questo test è complementare al test del sulfur_ppm e verifica che
        l'oxy_wt continui a essere calcolato correttamente con le frazioni massiche.
        """
        # Frazioni di massa
        w = np.array([0.5, 0.5])
        
        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)
        
        # Calcola le frazioni volumetriche
        densities = np.array([c.density for c in self.components])
        v_unnorm = w / densities
        v = v_unnorm / np.sum(v_unnorm)
        
        # Calcola oxy_wt usando le frazioni massiche (metodo corretto)
        oxy_values = np.array([c.properties.get("oxy_wt", 0.0) for c in self.components])
        correct_oxy = np.dot(w, oxy_values)
        
        # Calcola oxy_wt usando le frazioni volumetriche (metodo errato)
        incorrect_oxy = np.dot(v, oxy_values)
        
        # Verifica che il valore calcolato sia uguale a quello corretto
        # e diverso da quello errato
        self.assertAlmostEqual(properties["oxy_wt"], correct_oxy, places=5)
        self.assertNotAlmostEqual(properties["oxy_wt"], incorrect_oxy, places=5)
    
    def test_derivatives_of_sulfur_ppm(self):
        """
        Test delle derivate del sulfur_ppm rispetto alle frazioni di massa.
        
        Per proprietà lineari basate sul volume, la derivata rispetto a w_i
        è più complessa e dipende dalle derivate delle frazioni volumetriche.
        """
        # Frazioni di massa
        w = np.array([0.3, 0.7])
        
        # Calcola le derivate
        derivatives = self.calculator.calculate_property_derivatives(self.components, w)
        
        # Calcola le frazioni volumetriche
        v = self.calculator._mass_to_volume(self.components, w)
        
        # Calcola le derivate delle frazioni volumetriche
        densities = np.array([c.density for c in self.components])
        # Correggi il nome del metodo
        v, safe_densities = self.calculator._mass_to_volume(self.components, w)
        dv_dw = self.calculator._calculate_dv_dw(v, safe_densities, w)
        
        # Calcola manualmente le derivate del sulfur_ppm
        sulfur_values = np.array([c.properties["sulfur_ppm"] for c in self.components])
        manual_d_sulfur = np.zeros(2)
        
        for i in range(2):
            for j in range(2):
                manual_d_sulfur[i] += sulfur_values[j] * dv_dw[j, i]
        
        # Verifica che le derivate calcolate siano corrette
        np.testing.assert_array_almost_equal(derivatives["sulfur_ppm"], manual_d_sulfur)

if __name__ == "__main__":
    unittest.main()
