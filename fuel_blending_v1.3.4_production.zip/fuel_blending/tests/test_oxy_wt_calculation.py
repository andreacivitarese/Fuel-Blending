"""
Test per verificare la correzione del calcolo dell'oxy_wt.

Questo modulo contiene test specifici per verificare che il calcolo
dell'oxy_wt utilizzi correttamente le frazioni massiche invece delle
frazioni volumetriche.
"""

import unittest
import numpy as np
from fuel_blending.blending.properties import PropertyCalculator
from fuel_blending.models import Component
# Import constants needed for properties dictionary
from fuel_blending.utils.constants import (
    PROPERTY_RON, PROPERTY_MON, PROPERTY_RVP, PROPERTY_DENSITY,
    PROPERTY_SULFUR_PPM, PROPERTY_BENZENE, PROPERTY_AROMATICS,
    PROPERTY_OLEFINS, PROPERTY_E150, PROPERTY_E70, PROPERTY_OXY_WT,
    PROPERTY_T50, PROPERTY_MTBE, DELTA_TYPE_AS_IS, DELTA_TYPE_FACTOR
)

class TestOxyWtCalculation(unittest.TestCase):
    """Test per il calcolo dell'oxy_wt."""

    def setUp(self):
        """Setup per i test (aggiornato per il nuovo costruttore Component)."""
        # Crea un calcolatore di proprietà
        self.calculator = PropertyCalculator(rvp_exp=1.25)

        # Crea componenti di test con densità diverse e valori oxy_wt diversi
        self.components = [
            Component(
                name="Comp1",
                delta_type=DELTA_TYPE_AS_IS, # Required argument
                delta_value=5.0,
                density=0.75,  # Densità bassa
                properties={
                    PROPERTY_RON: 95.0,
                    PROPERTY_MON: 85.0,
                    PROPERTY_RVP: 10.0,
                    PROPERTY_SULFUR_PPM: 10.0,
                    PROPERTY_BENZENE: 1.0,
                    PROPERTY_AROMATICS: 20.0,
                    PROPERTY_OLEFINS: 5.0,
                    PROPERTY_MTBE: 0.0,
                    # PROPERTY_T10: 50.0, # T10 non è più una costante standard
                    PROPERTY_T50: 100.0,
                    PROPERTY_E70: 30.0,
                    PROPERTY_E150: 90.0, # Aggiunto E150 se necessario
                    PROPERTY_OXY_WT: 0.0,  # Nessun ossigeno
                },
                is_ethanol=False
            ),
            Component(
                name="Comp2",
                delta_type=DELTA_TYPE_FACTOR, # Required argument
                multiplier=1.05,
                density=0.85,  # Densità alta
                properties={
                    PROPERTY_RON: 98.0,
                    PROPERTY_MON: 88.0,
                    PROPERTY_RVP: 15.0,
                    PROPERTY_SULFUR_PPM: 5.0,
                    PROPERTY_BENZENE: 0.5,
                    PROPERTY_AROMATICS: 15.0,
                    PROPERTY_OLEFINS: 3.0,
                    PROPERTY_MTBE: 0.0,
                    # PROPERTY_T10: 45.0, # T10 non è più una costante standard
                    PROPERTY_T50: 95.0,
                    PROPERTY_E70: 25.0,
                    PROPERTY_E150: 85.0, # Aggiunto E150 se necessario
                    PROPERTY_OXY_WT: 50.0,  # Alto contenuto di ossigeno
                },
                is_ethanol=False
            )
        ]

    def test_oxy_wt_calculation_with_equal_mass_fractions(self):
        """
        Test del calcolo dell'oxy_wt con frazioni di massa uguali.

        Con frazioni di massa uguali (50% ciascuna), il valore di oxy_wt
        dovrebbe essere la media dei valori dei componenti, indipendentemente
        dalle loro densità.
        """
        # Frazioni di massa uguali
        w = np.array([0.5, 0.5])

        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)

        # Verifica che oxy_wt sia la media dei valori dei componenti
        expected_oxy_wt = 0.5 * 0.0 + 0.5 * 50.0  # Media pesata con frazioni di massa
        self.assertAlmostEqual(properties[PROPERTY_OXY_WT], expected_oxy_wt, places=5)

    def test_oxy_wt_calculation_with_different_mass_fractions(self):
        """
        Test del calcolo dell'oxy_wt con frazioni di massa diverse.

        Con frazioni di massa diverse, il valore di oxy_wt dovrebbe essere
        la media pesata dei valori dei componenti, con i pesi dati dalle
        frazioni di massa.
        """
        # Frazioni di massa diverse
        w = np.array([0.7, 0.3])

        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)

        # Verifica che oxy_wt sia la media pesata dei valori dei componenti
        expected_oxy_wt = 0.7 * 0.0 + 0.3 * 50.0  # Media pesata con frazioni di massa
        self.assertAlmostEqual(properties[PROPERTY_OXY_WT], expected_oxy_wt, places=5)

    def test_oxy_wt_calculation_vs_volume_fractions(self):
        """
        Test che verifica che il calcolo dell'oxy_wt utilizzi le frazioni di massa
        e non le frazioni volumetriche.

        Se il calcolo utilizzasse erroneamente le frazioni volumetriche, il risultato
        sarebbe diverso a causa delle diverse densità dei componenti.
        """
        # Frazioni di massa
        w = np.array([0.5, 0.5])

        # Calcola le proprietà
        properties = self.calculator.calculate_properties(self.components, w)

        # Calcola le frazioni volumetriche
        densities = np.array([c.density for c in self.components])
        v_unnorm = w / densities
        v = v_unnorm / np.sum(v_unnorm)

        # Calcola oxy_wt usando le frazioni volumetriche (metodo errato)
        oxy_values = np.array([c.properties[PROPERTY_OXY_WT] for c in self.components])
        incorrect_oxy_wt = np.dot(v, oxy_values)

        # Calcola oxy_wt usando le frazioni massiche (metodo corretto)
        correct_oxy_wt = np.dot(w, oxy_values)

        # Verifica che il valore calcolato sia uguale a quello corretto
        # e diverso da quello errato
        self.assertAlmostEqual(properties[PROPERTY_OXY_WT], correct_oxy_wt, places=5)
        self.assertNotAlmostEqual(properties[PROPERTY_OXY_WT], incorrect_oxy_wt, places=5)

    # Rimosso test_sulfur_ppm_calculation perché sulfur è basato su volume ora
    # def test_sulfur_ppm_calculation(self):
    #     ...

    def test_derivatives_of_oxy_wt(self):
        """
        Test delle derivate dell'oxy_wt rispetto alle frazioni di massa.

        Per proprietà lineari basate sul peso, la derivata rispetto a w_i
        dovrebbe essere semplicemente il valore della proprietà per il componente i.
        """
        # Frazioni di massa
        w = np.array([0.4, 0.6])

        # Calcola le derivate
        derivatives = self.calculator.calculate_property_derivatives(self.components, w)

        # Verifica che le derivate dell'oxy_wt siano corrette
        oxy_values = np.array([c.properties[PROPERTY_OXY_WT] for c in self.components])
        np.testing.assert_array_almost_equal(derivatives[PROPERTY_OXY_WT], oxy_values)

    # Rimosso test_derivatives_of_sulfur_ppm perché sulfur è basato su volume ora
    # def test_derivatives_of_sulfur_ppm(self):
    #     ...

if __name__ == "__main__":
    unittest.main()

