"""
Integration tests for the fuel_blending CLI.

These tests simulate end-to-end runs of the CLI commands.
"""

import pytest
import subprocess
import sys
from pathlib import Path
import pandas as pd
import json

# Define paths relative to the project root (assuming tests are run from root)
PROJECT_ROOT = Path(__file__).parent.parent
TEST_DATA_DIR = PROJECT_ROOT / "data_examples"
TEST_OUTPUT_DIR = PROJECT_ROOT / "test_outputs"

# Ensure the output directory exists
TEST_OUTPUT_DIR.mkdir(exist_ok=True)

# Path to the CLI entry point (adjust if necessary)
CLI_ENTRY_POINT = [sys.executable, "-m", "fuel_blending.cli"]

# Helper function to run CLI commands
def run_cli_command(cmd_args: list[str]) -> subprocess.CompletedProcess:
    """Runs a CLI command and returns the result."""
    full_cmd = CLI_ENTRY_POINT + cmd_args
    command_str = " ".join(full_cmd)
    print(f"\nRunning command: {command_str}")
    result = subprocess.run(full_cmd, capture_output=True, text=True, cwd=PROJECT_ROOT)
    print(f"STDOUT:\n{result.stdout}")
    print(f"STDERR:\n{result.stderr}")
    return result

# --- Test Optimize Command --- 

@pytest.mark.integration
def test_optimize_local_files_csv_output():
    """Test the optimize command with local Excel files and CSV output."""
    components_file = TEST_DATA_DIR / "components_example.xlsx"
    grades_file = TEST_DATA_DIR / "grades_example.xlsx"
    additives_file = TEST_DATA_DIR / "additives_example.xlsx"
    output_file = TEST_OUTPUT_DIR / "optimize_results_local.csv"

    args = [
        "optimize",
        str(components_file),
        str(grades_file),
        "--additives", str(additives_file),
        "--output", str(output_file),
        "--format", "csv", # Ensure CSV format for eval-candidate test
        "--flat-price", "700",
        "--continue-on-error" # Allow continuing even if one grade fails
    ]

    result = run_cli_command(args)

    assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
    assert "Salvataggio risultati in" in result.stdout or "Salvataggio risultati in" in result.stderr
    assert output_file.exists(), "Output CSV file was not created."

    # Basic check on the output file content
    try:
        df = pd.read_csv(output_file)
        assert not df.empty, "Output CSV file is empty."
        assert "Grade" in df.columns
        assert "Success" in df.columns
        assert "Cost (USD/mt)" in df.columns
        # Check if at least one grade was successful (assuming example data allows this)
        assert df["Success"].any(), "No grade optimization was successful in the output."
    except Exception as e:
        pytest.fail(f"Failed to read or validate output CSV file: {e}")

@pytest.mark.integration
def test_optimize_local_files_no_output():
    """Test the optimize command with local Excel files and console output, including shadow prices."""
    components_file = TEST_DATA_DIR / "components_example.xlsx"
    grades_file = TEST_DATA_DIR / "grades_example.xlsx"
    additives_file = TEST_DATA_DIR / "additives_example.xlsx"

    args = [
        "optimize",
        str(components_file),
        str(grades_file),
        "--additives", str(additives_file),
        "--flat-price", "700",
        "--continue-on-error"
    ]

    result = run_cli_command(args)

    assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
    # Check for summary table output markers in stdout
    assert "Optimization Results Summary" in result.stdout
    assert "Grade" in result.stdout
    assert "Status" in result.stdout
    assert "Cost (USD/mt)" in result.stdout
    assert "SUCCESS" in result.stdout # Expect at least one success with example data

    # Check for shadow price table output (assuming at least one grade succeeds)
    assert "Shadow Prices for Grade:" in result.stdout
    assert "Constraint Name" in result.stdout
    assert "Shadow Price (USD/mt per unit)" in result.stdout

# --- Test Eval-Candidate Command --- 

@pytest.mark.integration
def test_eval_candidate_local_files_csv_output():
    """Test the eval-candidate command with local files and CSV output."""
    # Ensure the optimization results file exists from the previous test
    opt_results_file = TEST_OUTPUT_DIR / "optimize_results_local.csv"
    assert opt_results_file.exists(), f"Optimization results file {opt_results_file} not found. Run test_optimize_local_files_csv_output first."

    candidates_file = TEST_DATA_DIR / "candidates_example.xlsx"
    grades_file = TEST_DATA_DIR / "grades_example.xlsx" # Needed for specs
    components_file = TEST_DATA_DIR / "components_example.xlsx" # Needed for context
    output_file = TEST_OUTPUT_DIR / "eval_candidate_results.csv"

    # Check if candidates file exists (created by helper script)
    assert candidates_file.exists(), f"Candidates file {candidates_file} not found. Ensure it was created."

    args = [
        "eval-candidate",
        str(candidates_file),
        "--grades", str(grades_file),
        "--components", str(components_file), # Add components file
        "--from-results", str(opt_results_file),
        "--output", str(output_file),
        "--format", "csv",
        "--flat-price", "700"
    ]

    result = run_cli_command(args)

    assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
    assert "Salvataggio risultati in" in result.stdout or "Salvataggio risultati in" in result.stderr
    assert output_file.exists(), "Output CSV file was not created."

    # Basic check on the output file content
    try:
        df = pd.read_csv(output_file)
        assert not df.empty, "Output CSV file is empty."
        assert "candidate_id" in df.columns
        assert "grade_name" in df.columns
        assert "cost_usd_mt" in df.columns
        assert "optimal_cost_usd_mt" in df.columns
        assert "delta_cost" in df.columns
        assert "constraints_ok" in df.columns
    except Exception as e:
        pytest.fail(f"Failed to read or validate output CSV file: {e}")

@pytest.mark.integration
def test_eval_candidate_local_files_no_output():
    """Test the eval-candidate command with local files and console output, including neutral prices."""
    # Ensure the optimization results file exists
    opt_results_file = TEST_OUTPUT_DIR / "optimize_results_local.csv"
    assert opt_results_file.exists(), f"Optimization results file {opt_results_file} not found. Run test_optimize_local_files_csv_output first."

    candidates_file = TEST_DATA_DIR / "candidates_example.xlsx"
    grades_file = TEST_DATA_DIR / "grades_example.xlsx"
    components_file = TEST_DATA_DIR / "components_example.xlsx"

    assert candidates_file.exists(), f"Candidates file {candidates_file} not found."

    args = [
        "eval-candidate",
        str(candidates_file),
        "--grades", str(grades_file),
        "--components", str(components_file),
        "--from-results", str(opt_results_file),
        "--flat-price", "700"
    ]

    result = run_cli_command(args)

    assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
    # Check for summary table output
    assert "Candidate Evaluation Summary" in result.stdout
    assert "Candidate ID" in result.stdout
    assert "Grade" in result.stdout
    assert "Cost (USD/mt)" in result.stdout
    assert "Optimal Cost" in result.stdout
    assert "Delta Cost" in result.stdout
    assert "Constraints OK?" in result.stdout

    # Check for neutral price table output (assuming at least one grade has results)
    assert "Neutral Prices for Grade:" in result.stdout
    assert "Component Name" in result.stdout
    assert "Neutral Price (USD/mt)" in result.stdout

# --- Test Sensitivity Command --- 

@pytest.mark.integration
def test_sensitivity_presence_local_files():
    """Test the sensitivity command (presence analysis) with local files."""
    components_file = TEST_DATA_DIR / "components_example.xlsx"
    grades_file = TEST_DATA_DIR / "grades_example.xlsx"
    additives_file = TEST_DATA_DIR / "additives_example.xlsx"
    output_file = TEST_OUTPUT_DIR / "sensitivity_presence_results.csv"

    args = [
        "sensitivity",
        str(components_file),
        str(grades_file),
        "--additives", str(additives_file),
        "--output", str(output_file),
        "--format", "csv",
        "--flat-price", "700",
        "--analysis-type", "presence",
        # Optionally limit components/grades to speed up test
        # "--components-list", "CompA", "CompB",
        # "--grades-list", "Grade1"
    ]

    result = run_cli_command(args)

    assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
    assert "Salvataggio risultati in" in result.stdout or "Salvataggio risultati in" in result.stderr
    assert output_file.exists(), "Output CSV file was not created."

    # Basic check on the output file content
    try:
        df = pd.read_csv(output_file)
        assert not df.empty, "Output CSV file is empty."
        assert "param_name" in df.columns # Component name for presence analysis
        assert "param_value" in df.columns # Should be 0 for removed component
        assert "grade_name" in df.columns
        assert "success" in df.columns
        assert "cost_usd_mt" in df.columns
    except Exception as e:
        pytest.fail(f"Failed to read or validate output CSV file: {e}")

@pytest.mark.integration
def test_sensitivity_price_local_files():
    """Test the sensitivity command (price analysis) with local files."""
    components_file = TEST_DATA_DIR / "components_example.xlsx"
    grades_file = TEST_DATA_DIR / "grades_example.xlsx"
    additives_file = TEST_DATA_DIR / "additives_example.xlsx"
    output_file = TEST_OUTPUT_DIR / "sensitivity_price_results.csv"

    args = [
        "sensitivity",
        str(components_file),
        str(grades_file),
        "--additives", str(additives_file),
        "--output", str(output_file),
        "--format", "csv",
        "--flat-price", "700",
        "--analysis-type", "price",
        "--price-delta", "10", # 10% change
        "--delta-type", "percent",
        "--direction", "both",
        # Optionally limit components/grades to speed up test
        # "--components-list", "CompA",
        # "--grades-list", "Grade1"
    ]

    result = run_cli_command(args)

    assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
    assert "Salvataggio risultati in" in result.stdout or "Salvataggio risultati in" in result.stderr
    assert output_file.exists(), "Output CSV file was not created."

    # Basic check on the output file content
    try:
        df = pd.read_csv(output_file)
        assert not df.empty, "Output CSV file is empty."
        assert "param_name" in df.columns # Component name for price analysis
        assert "param_value" in df.columns # New price delta/multiplier
        assert "grade_name" in df.columns
        assert "success" in df.columns
        assert "cost_usd_mt" in df.columns
    except Exception as e:
        pytest.fail(f"Failed to read or validate output CSV file: {e}")


# --- Test Google Drive Integration (Optional, requires setup) ---

# @pytest.mark.integration
# @pytest.mark.skipif(not Path("~/.fuel_blending/credentials.json").expanduser().exists(), reason="Google Drive credentials not found")
# def test_optimize_google_drive_files():
#     """Test optimize command loading files from Google Drive (requires setup)."""
#     # Replace with actual Google Drive File IDs
#     components_id = "YOUR_COMPONENTS_FILE_ID"
#     grades_id = "YOUR_GRADES_FILE_ID"
#     additives_id = "YOUR_ADDITIVES_FILE_ID"
#     output_file = TEST_OUTPUT_DIR / "optimize_results_gdrive.csv"
# 
#     args = [
#         "optimize",
#         components_id,
#         grades_id,
#         "--additives", additives_id,
#         "--output", str(output_file),
#         "--format", "csv",
#         "--flat-price", "700",
#         "--from-google-drive",
#         "--continue-on-error"
#     ]
# 
#     result = run_cli_command(args)
# 
#     assert result.returncode == 0, f"CLI command failed with error: {result.stderr}"
#     assert output_file.exists(), "Output CSV file was not created."
#     # Add more specific checks if needed


