"""
Tests for the Optimizer class and shadow price extraction.
"""

import pytest
import numpy as np
import pandas as pd
from pathlib import Path
import logging # Added missing import

# Import necessary classes from the fuel_blending package
from fuel_blending.config import ConfigManager, Config
from fuel_blending.loaders import DataLoader
from fuel_blending.models import Component, Grade, Additive, OptimizationResultModel
from fuel_blending.blending.context import BlendingContext
from fuel_blending.optimization.optimizer import Optimizer, OptimizerConfig
from fuel_blending.utils.exceptions import OptimizationError
# Import constants needed for Component initialization and properties
from fuel_blending.utils.constants import (
    DELTA_TYPE_AS_IS, PROPERTY_RON, PROPERTY_SULFUR_PPM, PROPERTY_DENSITY
)

# Fixture for a simple BlendingContext (updated for new Component constructor)
@pytest.fixture(scope="module")
def simple_context():
    """Provides a simple BlendingContext for testing."""
    # Define simple components
    comp1 = Component(
        name="CompA",
        delta_type=DELTA_TYPE_AS_IS,
        delta_value=10.0, # Example cost delta
        density=0.7,
        properties={
            PROPERTY_RON: 90.0,
            PROPERTY_SULFUR_PPM: 10.0,
            # Add other properties if needed by constraints, using PROPERTY_ constants
        }
    )
    comp2 = Component(
        name="CompB",
        delta_type=DELTA_TYPE_AS_IS,
        delta_value=20.0, # Example cost delta
        density=0.8,
        properties={
            PROPERTY_RON: 95.0,
            PROPERTY_SULFUR_PPM: 5.0,
        }
    )
    comp3 = Component(
        name="CompC",
        delta_type=DELTA_TYPE_AS_IS,
        delta_value=5.0, # Example cost delta
        density=0.6,
        properties={
            PROPERTY_RON: 85.0,
            PROPERTY_SULFUR_PPM: 15.0,
        }
    )
    components = [comp1, comp2, comp3]

    # Define a simple grade with specs matching component properties
    grade = Grade(
        name="TestGrade",
        specs={
            PROPERTY_RON: (92.0, None), # Active constraint (min)
            PROPERTY_SULFUR_PPM: (None, 12.0), # Active constraint (max)
            PROPERTY_DENSITY: (0.65, 0.75) # Active constraints (min, max)
        }
        # Other properties omitted for simplicity
    )

    # No additives for simplicity
    additives = []

    # Create context
    context = BlendingContext(components, grade, additives)
    return context

# Fixture for OptimizerConfig using trust-constr
@pytest.fixture(scope="module")
def trust_constr_config():
    """Provides an OptimizerConfig using trust-constr."""
    return OptimizerConfig(
        solver="trust-constr",
        options={"maxiter": 500, "verbose": 0, "xtol": 1e-6, "gtol": 1e-6, "barrier_tol": 1e-6},
        use_jacobian=True,
        check_constraints_post=True,
        constraint_tolerance=1e-5
    )

# Test function for shadow price extraction with trust-constr
def test_shadow_price_extraction_trust_constr(simple_context, trust_constr_config):
    """
    Tests the extraction of shadow prices (Lagrange multipliers) when using
    the trust-constr solver.
    Verifies the presence of expected multiplier keys.
    """
    optimizer = Optimizer(context=simple_context, config=trust_constr_config)

    try:
        result, _ = optimizer.optimize() # Unpack result and attempts

        # Basic checks
        assert result is not None
        assert result.success, f"Optimization failed: {result.message}"
        assert isinstance(result, OptimizationResultModel)

        # Shadow price checks
        shadow_prices = result.shadow_prices # Use the correct attribute name
        print(f"\nExtracted Shadow Prices (trust-constr): {shadow_prices}") # Print for debugging

        assert isinstance(shadow_prices, dict)
        assert len(shadow_prices) > 0, "Shadow prices dictionary is empty."

        # Check for expected keys based on the simple context constraints
        # Note: We check for presence, not exact values, as those are hard to predict
        # and depend heavily on the specific problem instance.

        # 1. Linear constraint (sum_fraction_equality)
        assert "sum_fraction_equality" in shadow_prices

        # 2. Non-linear constraints (from Grade specs)
        assert f"{PROPERTY_RON}_min" in shadow_prices
        assert f"{PROPERTY_SULFUR_PPM}_max" in shadow_prices
        assert f"{PROPERTY_DENSITY}_min" in shadow_prices
        assert f"{PROPERTY_DENSITY}_max" in shadow_prices

        # 3. Bounds (check if any bound multipliers are present - optional)
        # At least one bound multiplier (lower or upper) should likely be present
        # if the solution hits a bound (e.g., a component fraction is near 0 or 1).
        bound_keys_present = any(k.startswith("bound_lower_") or k.startswith("bound_upper_") for k in shadow_prices)
        # This assertion is less strict as it depends on the solution hitting a bound
        # assert bound_keys_present, "Expected at least one bound Lagrange multiplier."
        print(f"Bound keys present: {bound_keys_present}")

        # Check data types (should be float)
        for key, value in shadow_prices.items():
            assert isinstance(value, float), f"Multiplier for {key} is not a float: {type(value)}"

    except OptimizationError as e:
        pytest.fail(f"Optimization raised an unexpected error: {e}")

# Fixture for OptimizerConfig using SLSQP
@pytest.fixture(scope="module")
def slsqp_config():
    """Provides an OptimizerConfig using SLSQP."""
    return OptimizerConfig(
        solver="slsqp",
        options={"maxiter": 500, "ftol": 1e-6}, # ftol is common for SLSQP
        use_jacobian=True, # SLSQP can use jacobian
        check_constraints_post=True,
        constraint_tolerance=1e-5
    )

# Test function for shadow price extraction with SLSQP (expecting empty/warning)
def test_shadow_price_extraction_slsqp(simple_context, slsqp_config, caplog):
    """
    Tests the extraction of shadow prices when using the SLSQP solver.
    Expects the multipliers dictionary to be empty and a warning to be logged.
    """
    optimizer = Optimizer(context=simple_context, config=slsqp_config)

    try:
        # Capture log messages
        with caplog.at_level(logging.WARNING):
            result, _ = optimizer.optimize() # Unpack result and attempts

        # Basic checks
        assert result is not None
        assert result.success, f"Optimization failed: {result.message}"
        assert isinstance(result, OptimizationResultModel)

        # Shadow price checks for SLSQP
        shadow_prices = result.shadow_prices # Use the correct attribute name
        print(f"\nExtracted Shadow Prices (SLSQP): {shadow_prices}") # Print for debugging

        assert isinstance(shadow_prices, dict)
        assert len(shadow_prices) == 0, "Shadow prices should be empty for SLSQP."

        # Check for the warning message in logs
        assert "Lagrange multiplier extraction is not reliably supported for the \'SLSQP\' solver" in caplog.text

    except OptimizationError as e:
        pytest.fail(f"Optimization raised an unexpected error: {e}")


