"""
Test di base per verificare l'importabilità del pacchetto ristrutturato.

Questo test verifica che tutti i moduli principali del pacchetto
fuel_blending siano correttamente importabili.
"""

import unittest


class TestImports(unittest.TestCase):
    """Test per verificare che tutti i moduli siano importabili."""
    
    def test_main_package_import(self):
        """Verifica che il pacchetto principale sia importabile."""
        import fuel_blending
        self.assertIsNotNone(fuel_blending)
        self.assertIsNotNone(fuel_blending.__version__)
    
    def test_utils_import(self):
        """Verifica che il modulo utils sia importabile."""
        from fuel_blending.utils import setup_logging, constants, exceptions
        self.assertIsNotNone(setup_logging)
        self.assertIsNotNone(constants.PROPERTY_RON)
        self.assertIsNotNone(exceptions.FuelBlendingError)
    
    def test_blending_import(self):
        """Verifica che il modulo blending sia importabile."""
        from fuel_blending.blending import BlendingContext, PropertyCalculator, ConstraintManager
        self.assertIsNotNone(BlendingContext)
        self.assertIsNotNone(PropertyCalculator)
        self.assertIsNotNone(ConstraintManager)
    
    def test_models_import(self):
        """Verifica che il modulo models sia importabile."""
        from fuel_blending.models import Component, Grade, BlendingModel
        self.assertIsNotNone(Component)
        self.assertIsNotNone(Grade)
        self.assertIsNotNone(BlendingModel)
    
    def test_optimization_import(self):
        """Verifica che il modulo optimization sia importabile."""
        from fuel_blending.optimization import Optimizer, OptimizationResult
        self.assertIsNotNone(Optimizer)
        self.assertIsNotNone(OptimizationResult)
    
    def test_analysis_import(self):
        """Verifica che il modulo analysis sia importabile."""
        from fuel_blending.analysis import EconomicAnalyzer
        self.assertIsNotNone(EconomicAnalyzer)


if __name__ == "__main__":
    unittest.main()
