"""
Interfaccia a riga di comando aggiornata con supporto per Google Drive.
"""

import argparse
import logging
from pathlib import Path
import sys

# Import dalla nuova struttura
from .config import Config # Assumendo che Config sia in config.py
# Aggiorna l'import per riflettere la nuova posizione dei comandi
from .commands.commands import command_optimize, command_eval_candidate 
# Importa anche command_sensitivity se esiste
try:
    from .commands.commands import command_sensitivity
except ImportError:
    # Definisci una funzione fittizia se non esiste per evitare errori
    def command_sensitivity(*args, **kwargs):
        logger = logging.getLogger(__name__)
        logger.error("Comando 'sensitivity' non implementato.")
        sys.exit(1)

# Logger
logger = logging.getLogger(__name__)

def run_cli(args: list[str], config: Config):
    """
    Esegue la CLI.
    
    Args:
        args: Argomenti della CLI (lista di stringhe)
        config: Configurazione
    """
    # Parsing degli argomenti
    parser = argparse.ArgumentParser(
        description="Fuel Blending Optimization CLI",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    subparsers = parser.add_subparsers(dest="command", help="Comando da eseguire", required=True)
    
    # --- Argomenti comuni per Google Drive ---
    google_drive_parser = argparse.ArgumentParser(add_help=False)
    google_drive_group = google_drive_parser.add_argument_group("Google Drive Options")
    google_drive_group.add_argument(
        "--from-google-drive", 
        action="store_true", 
        help="Carica i file di input specificati (components, grades, additives, candidates) da Google Drive usando i loro ID invece dei percorsi locali."
    )
    google_drive_group.add_argument(
        "--interactive", 
        action="store_true", 
        help="Se --from-google-drive è attivo, permette la selezione interattiva dei file da Google Drive se gli ID non sono forniti o non validi."
    )
    google_drive_group.add_argument(
        "--credentials-file", 
        type=Path, 
        default=config.google_drive.credentials_file, # Prende il default dalla config
        help="Percorso del file credentials.json per l'autenticazione Google Drive API."
    )
    google_drive_group.add_argument(
        "--token-file", 
        type=Path, 
        default=config.google_drive.token_file, # Prende il default dalla config
        help="Percorso del file token.json per salvare/caricare il token di accesso OAuth2."
    )
    # --- Fine Argomenti Google Drive ---
    
    # --- Comando optimize ---
    optimize_parser = subparsers.add_parser(
        "optimize", 
        parents=[google_drive_parser], 
        help="Esegue l'ottimizzazione del blending per uno o più grade.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    optimize_parser.add_argument("components", type=str, help="Percorso del file Excel dei componenti o ID Google Drive.")
    optimize_parser.add_argument("grades", type=str, help="Percorso del file Excel dei grade o ID Google Drive.")
    optimize_parser.add_argument("--additives", type=str, help="Percorso del file Excel degli additivi o ID Google Drive (opzionale).")
    optimize_parser.add_argument("--flat-price", type=float, default=config.flat_price, help="Prezzo flat base per il calcolo dei costi (USD/mt).")
    optimize_parser.add_argument("--output", type=Path, help="Percorso del file CSV per salvare il riepilogo dei risultati.")
    optimize_parser.add_argument("--rvp-exp", type=float, default=config.blending.rvp_exp, help="Esponente utilizzato nel calcolo della RVP.")
    optimize_parser.add_argument("--solver", choices=["slsqp", "trust-constr", "cobyla"], default=config.optimizer.solver, help="Solver da utilizzare per l'ottimizzazione.")
    optimize_parser.add_argument("--solver-opt", action="append", default=[], metavar="KEY=VALUE", help="Opzioni specifiche per il solver (es. maxiter=500). Può essere usato più volte.")
    optimize_parser.add_argument("--max-attempts", type=int, default=config.optimizer.max_attempts, help="Numero massimo di tentativi totali del solver (inclusi fallback).")
    optimize_parser.add_argument("--continue-on-error", action="store_true", help="Continua con l'ottimizzazione del grade successivo anche se uno fallisce.")
    optimize_parser.add_argument("--no-check-constraints", action="store_false", dest="check_constraints_post", default=config.optimizer.check_constraints_post, help="Disabilita il controllo dei vincoli dopo il completamento dell'ottimizzazione.")
    optimize_parser.set_defaults(func=command_optimize) # Associa la funzione al comando
    # --- Fine Comando optimize ---
    
    # --- Comando eval-candidate ---
    eval_candidate_parser = subparsers.add_parser(
        "eval-candidate", 
        parents=[google_drive_parser], 
        help="Valuta uno o più blend candidati rispetto ai risultati ottimali.",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter
    )
    eval_candidate_parser.add_argument("candidates", type=str, help="Percorso del file Excel dei candidati o ID Google Drive.")
    eval_candidate_parser.add_argument("--grades", type=str, required=True, help="Percorso del file Excel dei grade o ID Google Drive (necessario per le specifiche). ")
    eval_candidate_parser.add_argument("--from-results", type=str, required=True, help="Percorso del file CSV/JSON contenente i risultati dell'ottimizzazione precedente.")
    eval_candidate_parser.add_argument("--components-for-neutral-price", type=str, required=True, help="Percorso del file Excel dei componenti (stile template) per cui calcolare i prezzi neutri o ID Google Drive.")
    # TODO: Aggiungere argomento per file componenti se non incluso nei risultati
    eval_candidate_parser.add_argument("--flat-price", type=float, default=config.flat_price, help="Prezzo flat base per il calcolo dei costi (USD/mt).")
    eval_candidate_parser.add_argument("--output", type=Path, help="Percorso del file CSV/JSON per salvare i risultati della valutazione.")
    eval_candidate_parser.add_argument("--format", choices=["csv", "json"], default="csv", help="Formato del file di output.")
    eval_candidate_parser.set_defaults(func=command_eval_candidate) # Associa la funzione al comando
    # --- Fine Comando eval-candidate ---
    
    # --- Comando sensitivity (se implementato) ---
    # Assumendo che command_sensitivity sia stato importato o definito
    if 'command_sensitivity' in globals() and callable(command_sensitivity):
        sensitivity_parser = subparsers.add_parser(
            "sensitivity", 
            parents=[google_drive_parser], 
            help="Esegue analisi di sensibilità (es. presenza componenti).",
            formatter_class=argparse.ArgumentDefaultsHelpFormatter
        )
        # Aggiungere qui gli argomenti specifici per sensitivity, simili a v5.7
        sensitivity_parser.add_argument("components", type=str, help="Percorso file componenti o ID GDrive.")
        sensitivity_parser.add_argument("grades", type=str, help="Percorso file grade o ID GDrive.")
        sensitivity_parser.add_argument("--additives", type=str, help="Percorso file additivi o ID GDrive (opzionale).")
        sensitivity_parser.add_argument("--flat-price", type=float, default=config.flat_price, help="Prezzo flat base (USD/mt).")
        sensitivity_parser.add_argument("--output", type=Path, help="Percorso file output (CSV, JSON, Markdown).")
        sensitivity_parser.add_argument("--format", choices=["csv", "json", "markdown"], default="markdown", help="Formato output.")
        # Argomenti specifici per l'analisi di sensibilità (da v5.7)
        sensitivity_parser.add_argument("--analysis-type", choices=["presence", "price"], default="presence", help="Tipo di analisi: presenza/assenza componenti o variazione prezzo.")
        sensitivity_parser.add_argument("--price-delta", type=float, default=5.0, help="Variazione prezzo (valore assoluto o percentuale, per --analysis-type=price).")
        sensitivity_parser.add_argument("--delta-type", choices=["percent", "absolute"], default="percent", help="Tipo di variazione prezzo (per --analysis-type=price).")
        sensitivity_parser.add_argument("--direction", choices=["up", "down", "both"], default="both", help="Direzione variazione prezzo (per --analysis-type=price).")
        sensitivity_parser.add_argument("--components-list", dest="components_list", nargs='+', metavar='COMP_NAME', help="Lista specifica di componenti su cui eseguire l'analisi (default: tutti).")
        sensitivity_parser.add_argument("--grades-list", dest="grades_list", nargs='+', metavar='GRADE_NAME', help="Lista specifica di grade su cui eseguire l'analisi (default: tutti).")
        sensitivity_parser.set_defaults(func=command_sensitivity) # Associa la funzione al comando
    # --- Fine Comando sensitivity ---
    
    # Parsing degli argomenti forniti
    try:
        parsed_args = parser.parse_args(args)
    except SystemExit as e:
         # Evita l'uscita se args è vuoto o help richiesto
         if e.code != 0:
             raise
         return # Esce tranquillamente se help richiesto

    # Aggiornamento della configurazione globale con gli argomenti specifici del comando
    # Flat price (comune a optimize, eval-candidate, sensitivity)
    if hasattr(parsed_args, 'flat_price') and parsed_args.flat_price is not None:
        config.flat_price = parsed_args.flat_price
        logger.debug(f"Config updated: flat_price = {config.flat_price}")
        
    # Opzioni specifiche di optimize
    if parsed_args.command == "optimize":
        if parsed_args.rvp_exp is not None:
            config.blending.rvp_exp = parsed_args.rvp_exp
            logger.debug(f"Config updated: blending.rvp_exp = {config.blending.rvp_exp}")
        if parsed_args.solver is not None:
            config.optimizer.solver = parsed_args.solver
            logger.debug(f"Config updated: optimizer.solver = {config.optimizer.solver}")
        if parsed_args.max_attempts is not None:
            config.optimizer.max_attempts = parsed_args.max_attempts
            logger.debug(f"Config updated: optimizer.max_attempts = {config.optimizer.max_attempts}")
        # Nota: check_constraints_post è gestito da dest e default
        config.optimizer.check_constraints_post = parsed_args.check_constraints_post
        logger.debug(f"Config updated: optimizer.check_constraints_post = {config.optimizer.check_constraints_post}")
            
        # Aggiornamento delle opzioni del solver da --solver-opt
        if parsed_args.solver_opt:
            for opt in parsed_args.solver_opt:
                if "=" in opt:
                    key, value_str = opt.split("=", 1)
                    try:
                        # Tentativo di conversione a float o int
                        if "." in value_str or "e" in value_str.lower():
                            value = float(value_str)
                        else:
                            value = int(value_str)
                    except ValueError:
                        # Se la conversione fallisce, mantieni la stringa
                        value = value_str
                    config.optimizer.options[key.strip()] = value
                    logger.debug(f"Config updated: optimizer.options[{key.strip()}] = {value}")
                else:
                    logger.warning(f"Ignorata opzione solver mal formattata: {opt}")

    # Esecuzione della funzione associata al comando
    if hasattr(parsed_args, 'func'):
        # Passa solo gli argomenti parsati e la configurazione aggiornata
        parsed_args.func(parsed_args, config)
    else:
        # Questo non dovrebbe accadere se 'required=True' è usato nei subparsers
        parser.print_help()

