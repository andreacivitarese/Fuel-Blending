"""
Configurazione centralizzata per il sistema di fuel blending.
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Dict, Any, Optional, List, Union
from dataclasses import dataclass, field

@dataclass
class BlendingConfig:
    """
    Configurazione per il blending.
    
    Attributes:
        rvp_exp: Esponente RVP
        ron_linear_min: Valore minimo di RON lineare
        base_density: Densità base per il calcolo del prezzo escalato
    """
    rvp_exp: float = 1.25
    ron_linear_min: Optional[float] = None
    base_density: float = 755.0

@dataclass
class OptimizerConfig:
    """
    Configurazione per l'ottimizzatore.
    
    Attributes:
        solver: Nome del solver
        options: Opzioni del solver
        use_jacobian: Flag per l'uso del Jacobiano analitico
        max_attempts: Numero massimo di tentativi
        check_constraints: Flag per il controllo dei vincoli dopo l'ottimizzazione
    """
    solver: str = "trust-constr"
    options: Dict[str, Any] = field(default_factory=lambda: {
        "maxiter": 1000,
        "xtol": 1e-6,
        "gtol": 1e-6,
        "barrier_tol": 1e-6
    })
    use_jacobian: bool = True
    max_attempts: int = 5
    check_constraints: bool = True

@dataclass
class LoggingConfig:
    """
    Configurazione per il logging.
    
    Attributes:
        level: Livello di logging
        file: Percorso del file di log
        format: Formato del log
        max_size: Dimensione massima del file di log
        backup_count: Numero di backup
    """
    level: str = "INFO"
    file: Optional[str] = None
    format: str = "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
    max_size: int = 10 * 1024 * 1024  # 10 MB
    backup_count: int = 5

@dataclass
class PathsConfig:
    """
    Configurazione per i percorsi.
    
    Attributes:
        data_dir: Directory dei dati
        output_dir: Directory di output
        log_dir: Directory dei log
    """
    data_dir: str = "data"
    output_dir: str = "output"
    log_dir: str = "logs"

@dataclass
class Config:
    """
    Configurazione completa.
    
    Attributes:
        blending: Configurazione per il blending
        optimizer: Configurazione per l'ottimizzatore
        logging: Configurazione per il logging
        paths: Configurazione per i percorsi
        flat_price: Prezzo flat
        environment: Ambiente (development, production)
    """
    blending: BlendingConfig = field(default_factory=BlendingConfig)
    optimizer: OptimizerConfig = field(default_factory=OptimizerConfig)
    logging: LoggingConfig = field(default_factory=LoggingConfig)
    paths: PathsConfig = field(default_factory=PathsConfig)
    flat_price: float = 700.0
    environment: str = "development"

class ConfigManager:
    """
    Gestore della configurazione.
    
    Carica la configurazione da file YAML e fornisce accesso alle impostazioni.
    """
    
    def __init__(self, config_dir: Optional[Union[str, Path]] = None):
        """
        Inizializza il gestore della configurazione.
        
        Args:
            config_dir: Directory di configurazione (default: ./config_examples relative alla CWD)
        """
        # Default to config_examples relative to current working directory if not provided
        self.config_dir = Path(config_dir) if config_dir else Path.cwd() / "config_examples"
        self.config = Config()
        self.logger = logging.getLogger("fuel_blending.config")
    
    def load(self, environment: str = "development", user_config_path: Optional[Union[str, Path]] = None) -> Config:
        """
        Carica la configurazione.
        
        Args:
            environment: Ambiente (development, production)
            user_config_path: Percorso della configurazione personalizzata (sovrascrive tutto)
            
        Returns:
            Config: Configurazione caricata
        """
        # Carica la configurazione predefinita
        default_config_path = self.config_dir / "default.yaml"
        if default_config_path.exists():
            self._load_from_file(default_config_path)
        else:
            self.logger.warning(f"File di configurazione predefinito non trovato: {default_config_path}")

        # Carica la configurazione dell'ambiente
        env_config_path = self.config_dir / f"{environment}.yaml"
        if env_config_path.exists():
            self._load_from_file(env_config_path)
        else:
            self.logger.warning(f"File di configurazione ambiente non trovato: {env_config_path}")

        # Carica la configurazione personalizzata se fornita
        if user_config_path:
            user_config_path = Path(user_config_path)
            if user_config_path.exists():
                self._load_from_file(user_config_path)
            else:
                 self.logger.warning(f"File di configurazione utente non trovato: {user_config_path}")

        # Carica la configurazione dalle variabili d'ambiente (sovrascrive i file)
        self._load_from_env()
        
        # Imposta l'ambiente
        self.config.environment = environment
        
        # Valida la configurazione
        self._validate()
        
        return self.config
    
    def _load_from_file(self, config_path: Path) -> None:
        """
        Carica la configurazione da un file YAML.
        
        Args:
            config_path: Percorso del file di configurazione
        """
        try:
            with open(config_path, "r") as f:
                config_data = yaml.safe_load(f)
            
            if config_data:
                self._update_config(config_data)
                self.logger.info(f"Configurazione caricata da {config_path}")
                
        except Exception as e:
            self.logger.error(f"Errore nel caricamento della configurazione da {config_path}: {str(e)}")
    
    def _load_from_env(self) -> None:
        """Carica la configurazione dalle variabili d'ambiente."""
        # Mappa delle variabili d'ambiente
        env_map = {
            "BLENDING_RVP_EXP": ("blending", "rvp_exp", float),
            "BLENDING_BASE_DENSITY": ("blending", "base_density", float),
            "OPTIMIZER_SOLVER": ("optimizer", "solver", str),
            "OPTIMIZER_MAX_ATTEMPTS": ("optimizer", "max_attempts", int),
            "LOGGING_LEVEL": ("logging", "level", str),
            "LOGGING_FILE": ("logging", "file", str),
            "PATHS_DATA_DIR": ("paths", "data_dir", str),
            "PATHS_OUTPUT_DIR": ("paths", "output_dir", str),
            "PATHS_LOG_DIR": ("paths", "log_dir", str),
            "FLAT_PRICE": ("flat_price", None, float)
        }
        
        for env_var, (section, key, type_func) in env_map.items():
            if env_var in os.environ:
                value = os.environ[env_var]
                
                try:
                    # Converti il valore al tipo corretto
                    typed_value = type_func(value)
                    
                    # Aggiorna la configurazione
                    if key is None:
                        setattr(self.config, section, typed_value)
                    else:
                        section_obj = getattr(self.config, section)
                        setattr(section_obj, key, typed_value)
                    
                    self.logger.info(f"Configurazione aggiornata da variabile d'ambiente {env_var}")
                    
                except Exception as e:
                    self.logger.error(f"Errore nell'aggiornamento della configurazione da variabile d'ambiente {env_var}: {str(e)}")
    
    def _update_config(self, config_data: Dict[str, Any]) -> None:
        """
        Aggiorna la configurazione con i dati forniti.
        
        Args:
            config_data: Dati di configurazione
        """
        # Aggiorna la configurazione di blending
        if "blending" in config_data:
            for key, value in config_data["blending"].items():
                if hasattr(self.config.blending, key):
                    setattr(self.config.blending, key, value)
        
        # Aggiorna la configurazione dell'ottimizzatore
        if "optimizer" in config_data:
            for key, value in config_data["optimizer"].items():
                if key == "options" and isinstance(value, dict):
                    self.config.optimizer.options.update(value)
                elif hasattr(self.config.optimizer, key):
                    setattr(self.config.optimizer, key, value)
        
        # Aggiorna la configurazione del logging
        if "logging" in config_data:
            for key, value in config_data["logging"].items():
                if hasattr(self.config.logging, key):
                    setattr(self.config.logging, key, value)
        
        # Aggiorna la configurazione dei percorsi
        if "paths" in config_data:
            for key, value in config_data["paths"].items():
                if hasattr(self.config.paths, key):
                    setattr(self.config.paths, key, value)
        
        # Aggiorna il prezzo flat
        if "flat_price" in config_data:
            self.config.flat_price = float(config_data["flat_price"])
    
    def _validate(self) -> None:
        """Valida la configurazione."""
        # Validazione della configurazione di blending
        if self.config.blending.rvp_exp <= 0:
            self.logger.warning("Esponente RVP non valido, impostato a 1.25")
            self.config.blending.rvp_exp = 1.25
        
        if self.config.blending.base_density <= 0:
            self.logger.warning("Densità base non valida, impostata a 755.0")
            self.config.blending.base_density = 755.0
        
        # Validazione della configurazione dell'ottimizzatore
        if self.config.optimizer.solver not in ["trust-constr", "slsqp", "cobyla"]:
            self.logger.warning(f"Solver {self.config.optimizer.solver} non supportato, impostato a trust-constr")
            self.config.optimizer.solver = "trust-constr"
        
        if self.config.optimizer.max_attempts <= 0:
            self.logger.warning("Numero massimo di tentativi non valido, impostato a 5")
            self.config.optimizer.max_attempts = 5
        
        # Validazione della configurazione del logging
        if self.config.logging.level.upper() not in ["DEBUG", "INFO", "WARNING", "ERROR", "CRITICAL"]:
            self.logger.warning(f"Livello di logging {self.config.logging.level} non valido, impostato a INFO")
            self.config.logging.level = "INFO"
        
        # Validazione del prezzo flat
        if self.config.flat_price <= 0:
            self.logger.warning("Prezzo flat non valido, impostato a 700.0")
            self.config.flat_price = 700.0
    
    def get_config(self) -> Config:
        """
        Ottiene la configurazione.
        
        Returns:
            Config: Configurazione
        """
        return self.config
    
    def get_paths(self) -> Dict[str, Path]:
        """
        Ottiene i percorsi assoluti basati sulla directory di lavoro corrente.
        
        Returns:
            Dict[str, Path]: Percorsi assoluti
        """
        base_dir = Path.cwd()
        
        return {
            "data_dir": base_dir / self.config.paths.data_dir,
            "output_dir": base_dir / self.config.paths.output_dir,
            "log_dir": base_dir / self.config.paths.log_dir
        }
    
    def ensure_directories(self) -> None:
        """Assicura che le directory necessarie esistano."""
        paths = self.get_paths()
        
        for path_name, path_obj in paths.items():
            try:
                path_obj.mkdir(parents=True, exist_ok=True)
                self.logger.debug(f"Directory assicurata: {path_obj}")
            except Exception as e:
                self.logger.error(f"Errore nella creazione della directory {path_obj}: {str(e)}")

# Istanza globale del gestore di configurazione
# Viene caricato con le impostazioni predefinite all'importazione
# Può essere ricaricato con .load() se necessario
config_manager = ConfigManager()
config = config_manager.load() # Carica la configurazione predefinita/ambiente all'avvio

