"""
Analisi economica per il sistema di fuel blending.

Logica adattata dalla v5.7, con esclusione dell'etanolo dal calcolo del valore marginale.
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Any, Tuple
import logging

# Aggiornato per usare i modelli e le costanti della nuova struttura
from ..models import Component, Grade
from ..utils.constants import (
    KEY_CANDIDATE, KEY_GRADE, KEY_MV_USD_T, KEY_DELTA_NEUT, KEY_MULT_NEUT,
    DELTA_TYPE_AS_IS, DELTA_TYPE_FACTOR, DELTA_TYPE_ESCALATED
)
# Presumendo che BlendingContext e BlendingModel/OptimizationResultModel siano disponibili
# Potrebbe essere necessario adattare l'import e l'uso di optimization_results
# from ..blending import BlendingContext, OptimizationResultModel 

class EconomicAnalyzer:
    """
    Analizzatore economico per il blending.
    """
    
    logger = logging.getLogger("fuel_blending.analysis")
    
    @staticmethod
    def analyze_candidates(
        candidates: List[Component],
        grades: List[Grade],
        optimization_results: Dict[str, Dict[str, Any]], # Struttura da verificare/adattare
        flat_price: float
    ) -> pd.DataFrame:
        """
        Analizza i candidati (escludendo l'etanolo).
        
        Args:
            candidates: Lista dei candidati
            grades: Lista dei grade
            optimization_results: Risultati dell'ottimizzazione
            flat_price: Prezzo flat (USD/mt)
            
        Returns:
            pd.DataFrame: Dataframe con i risultati dell'analisi
        """
        results = []
        
        # Filtra i candidati per escludere l'etanolo
        non_ethanol_candidates = [c for c in candidates if not c.is_ethanol]
        if len(non_ethanol_candidates) < len(candidates):
            EconomicAnalyzer.logger.info("Etanolo escluso dall'analisi economica dei candidati.")

        for candidate in non_ethanol_candidates:
            for grade in grades:
                # Verifica che il grade sia presente nei risultati di ottimizzazione
                if grade.name not in optimization_results:
                    EconomicAnalyzer.logger.warning(f"Grade {grade.name} non trovato nei risultati di ottimizzazione")
                    continue
                
                # Ottieni i risultati di ottimizzazione per il grade
                opt_result = optimization_results[grade.name]
                
                # Calcola il valore marginale
                # Nota: La funzione calculate_marginal_value ora gestisce l'esclusione dell'etanolo
                # ma qui passiamo solo candidati non-etanolo, quindi non è strettamente necessario
                # il controllo interno alla funzione per questa chiamata specifica.
                mv_usd_t = EconomicAnalyzer.calculate_marginal_value(
                    candidate,
                    grade,
                    opt_result,
                    flat_price # Passato ma non usato direttamente qui
                )
                
                # Calcola i valori neutri
                delta_neut, mult_neut = EconomicAnalyzer.calculate_neutral_values(
                    candidate,
                    mv_usd_t,
                    flat_price
                )
                
                # Aggiungi il risultato
                result = {
                    KEY_CANDIDATE: candidate.name,
                    KEY_GRADE: grade.name,
                    KEY_MV_USD_T: round(mv_usd_t, 2),
                    KEY_DELTA_NEUT: round(delta_neut, 2) if delta_neut is not None else None,
                    KEY_MULT_NEUT: round(mult_neut, 4) if mult_neut is not None else None
                }
                
                results.append(result)
        
        # Crea il dataframe
        df = pd.DataFrame(results)
        
        return df
    
    @staticmethod
    def calculate_marginal_value(
        candidate: Component,
        grade: Grade, # Non usato direttamente, ma potrebbe servire in futuro
        opt_result: Dict[str, Any],
        flat_price: float # Non usato direttamente, ma potrebbe servire in futuro
    ) -> float:
        """
        Calcola il valore marginale (MV) di un componente in USD/mt.
        Esclude l'etanolo dal calcolo.
        
        Args:
            candidate: Componente candidato
            grade: Grade target
            opt_result: Risultato dell'ottimizzazione per il grade
            flat_price: Prezzo flat (USD/mt)
            
        Returns:
            float: Valore marginale (USD/mt)
        """
        # Escludi l'etanolo
        if candidate.is_ethanol:
            EconomicAnalyzer.logger.debug(f"Skipping marginal value calculation for ethanol component: {candidate.name}")
            return 0.0 # O un altro valore indicativo, es. NaN
            
        # Estrai i moltiplicatori di Lagrange (lambdas)
        # La struttura di opt_result potrebbe essere cambiata, adattare se necessario
        lambdas = opt_result.get("lambdas", {})
        
        # Inizializza il valore marginale
        mv_usd_t = 0.0
        
        # Itera sulle proprietà del candidato e sui lambdas corrispondenti
        # Assumendo che i lambdas siano nominati come "property_name_lo" o "property_name_hi"
        for prop_name, prop_value in candidate.properties.items():
            lambda_lo_key = f"{prop_name}_lo"
            lambda_hi_key = f"{prop_name}_hi"
            
            if lambda_lo_key in lambdas and lambdas[lambda_lo_key] != 0:
                mv_usd_t += lambdas[lambda_lo_key] * prop_value
            
            if lambda_hi_key in lambdas and lambdas[lambda_hi_key] != 0:
                # Il contributo del limite superiore è negativo
                mv_usd_t -= lambdas[lambda_hi_key] * prop_value

        # Contributo specifico della densità (se gestito separatamente)
        # Assicurarsi che 'density' sia nel dizionario properties se non gestito sopra
        if "density" not in candidate.properties:
             lambda_lo_key = "density_lo"
             lambda_hi_key = "density_hi"
             if lambda_lo_key in lambdas and lambdas[lambda_lo_key] != 0:
                 mv_usd_t += lambdas[lambda_lo_key] * candidate.density
             if lambda_hi_key in lambdas and lambdas[lambda_hi_key] != 0:
                 mv_usd_t -= lambdas[lambda_hi_key] * candidate.density

        # Contributo del vincolo di massa (se presente e rilevante)
        # Il lambda per il vincolo di massa rappresenta il costo marginale
        # dell'intero blend, non il valore marginale di un componente specifico.
        # Solitamente non si include direttamente nel MV del componente.
        # if "mass" in lambdas and lambdas["mass"] != 0:
        #     mv_usd_t += lambdas["mass"] # O un'altra interpretazione

        # Nota: La logica per VLI è stata rimossa implicitamente perché VLI
        # non è più una proprietà gestita.
        
        return mv_usd_t
    
    @staticmethod
    def calculate_neutral_values(
        candidate: Component,
        mv_usd_t: float,
        flat_price: float
    ) -> Tuple[Optional[float], Optional[float]]:
        """
        Calcola il differenziale neutro (delta_neut) e il moltiplicatore neutro (mult_neut).
        
        Args:
            candidate: Componente candidato
            mv_usd_t: Valore marginale (USD/mt)
            flat_price: Prezzo flat (USD/mt)
            
        Returns:
            Tuple[Optional[float], Optional[float]]: Differenziale neutro e moltiplicatore neutro
        """
        delta_neut = None
        mult_neut = None
        
        # Il valore marginale (mv_usd_t) rappresenta quanto il costo totale del blend
        # diminuisce (se positivo) o aumenta (se negativo) per ogni unità marginale
        # del componente aggiunto. Il prezzo "neutro" è il prezzo al quale
        # l'aggiunta del componente non cambia il costo totale.
        # Prezzo Neutro = Prezzo Flat - Valore Marginale
        neutral_price = flat_price - mv_usd_t

        if candidate.delta_type == DELTA_TYPE_AS_IS:
            # delta_neut = Prezzo Neutro - Prezzo Flat
            delta_neut = neutral_price - flat_price 
            # Equivalentemente: delta_neut = -mv_usd_t
            
        elif candidate.delta_type == DELTA_TYPE_FACTOR:
            # Prezzo Neutro = Prezzo Flat * mult_neut
            if flat_price != 0:
                mult_neut = neutral_price / flat_price
                # Equivalentemente: mult_neut = (flat_price - mv_usd_t) / flat_price = 1 - mv_usd_t / flat_price
            
        elif candidate.delta_type == DELTA_TYPE_ESCALATED:
            # Prezzo Componente = Prezzo Flat * (base_density / component_density)
            # Prezzo Neutro = Prezzo Flat * (base_density / component_density)
            # In questo caso, il delta_neut rispetto al prezzo flat dipende dalla densità.
            # Il calcolo originale sembrava calcolare il delta rispetto al prezzo flat
            # assumendo che il prezzo del componente fosse escalato.
            # delta_neut = Prezzo Componente Escalato - Prezzo Flat
            # Qui vogliamo il delta che rende il prezzo del componente uguale al Prezzo Neutro.
            # Prezzo Neutro = Prezzo Flat + delta_neut_escalated
            # delta_neut_escalated = Prezzo Neutro - Prezzo Flat = -mv_usd_t
            # Quindi, il delta neutro per un componente escalato è lo stesso di 'as_is'.
            # Manteniamo la logica originale per coerenza, ma potrebbe essere rivista.
            base_density = candidate.base_density_component or 755.0 # Usa default se non specificato
            if candidate.density != 0:
                 component_escalated_price = flat_price * (base_density / candidate.density)
                 delta_neut = component_escalated_price - flat_price
            # Questo delta_neut però non è quello che rende il componente neutrale
            # in termini di valore marginale, ma il suo delta intrinseco.
            # Per il valore neutrale, sarebbe delta_neut = -mv_usd_t
            # Chiedere chiarimenti se necessario.
            # Per ora, usiamo delta_neut = -mv_usd_t anche per escalated per coerenza logica.
            delta_neut = -mv_usd_t

        return delta_neut, mult_neut

