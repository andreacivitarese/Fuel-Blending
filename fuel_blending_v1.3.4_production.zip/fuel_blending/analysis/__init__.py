"""
Modulo di inizializzazione per il sottopacchetto analysis.

Questo modulo esporta le classi e funzioni principali per l'analisi economica
e di sensibilità dei blend di carburanti.
"""

from .economic_analyzer import EconomicAnalyzer

__all__ = ["EconomicAnalyzer"]
