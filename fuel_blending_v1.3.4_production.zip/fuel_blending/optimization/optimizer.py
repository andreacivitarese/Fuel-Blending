"""
Ottimizzatore per il sistema di fuel blending.

Questo modulo contiene le classi per configurare ed eseguire l'ottimizzazione
del blend, inclusa la gestione robusta dei tentativi del solver e il fine-tuning
per la versione 1.2.
"""

import numpy as np
from typing import Dict, List, Optional, Any, Tuple, Callable, Union # Added Union
import logging
from scipy.optimize import minimize, OptimizeResult, Bounds, LinearConstraint, NonlinearConstraint
from dataclasses import dataclass, field
import time

# Import aggiornati per la struttura v1.2
from ..blending.context import BlendingContext
from ..blending.properties import PropertyCalculator
from ..blending.constraints import ConstraintManager, Constraint # Constraint importato ma non usato direttamente qui
from ..models import Component, Grade, Additive, OptimizationResultModel
from ..utils.exceptions import (
    OptimizationError, SolverConvergenceError,
    ConstraintViolationError, InfeasibleProblemError
)
from ..utils.constants import PROPERTY_DENSITY, CONSTRAINT_MIN, CONSTRAINT_MAX, CONSTRAINT_EQUAL

# Logger
logger = logging.getLogger(__name__)

@dataclass
class OptimizerConfig:
    """
    Configurazione per l'ottimizzatore.

    Attributes:
        solver: Nome del solver (es. "trust-constr", "slsqp").
        options: Opzioni specifiche del solver.
        use_jacobian: Flag per l'uso del Jacobiano analitico (se disponibile).
        max_attempts: Numero massimo di tentativi totali (inclusi fallback).
        initial_point_attempts: Numero di tentativi con punti iniziali diversi.
        check_constraints_post: Flag per il controllo dei vincoli dopo l'ottimizzazione.
        constraint_tolerance: Tolleranza per la verifica dei vincoli.
    """
    solver: str = "trust-constr"
    options: Dict[str, Any] = field(default_factory=lambda: {
        "maxiter": 1000,
        "xtol": 1e-7, # Tolleranza più stretta sulla soluzione
        "gtol": 1e-7, # Tolleranza più stretta sul gradiente
        "barrier_tol": 1e-7, # Tolleranza più stretta per trust-constr
        "verbose": 0 # 0: no output, 1: final, 2: iter, 3: more
    })
    use_jacobian: bool = True
    max_attempts: int = 5
    initial_point_attempts: int = 3
    check_constraints_post: bool = True
    constraint_tolerance: float = 1e-6

@dataclass
class SolverAttempt:
    """
    Rappresenta un singolo tentativo di ottimizzazione.

    Attributes:
        method: Metodo del solver utilizzato.
        initial_point: Punto iniziale utilizzato (frazioni componenti liberi).
        options: Opzioni del solver utilizzate.
        success: Flag di successo del tentativo.
        message: Messaggio restituito dal solver.
        result: Oggetto OptimizeResult completo restituito da scipy.optimize.minimize.
        duration: Durata del tentativo in secondi.
    """
    method: str
    initial_point: np.ndarray
    options: Dict[str, Any]
    success: bool = False
    message: str = ""
    result: Optional[OptimizeResult] = None
    duration: float = 0.0

class SolverManager:
    """
    Gestisce i tentativi multipli di ottimizzazione con diverse strategie.
    """

    def __init__(self, config: OptimizerConfig):
        """
        Inizializza il gestore.

        Args:
            config: Configurazione dell'ottimizzatore.
        """
        self.config = config
        self.logger = logging.getLogger(f"{__name__}.SolverManager")

        # Definizione dei solver alternativi
        # COBYLA non usa bounds/jac, SLSQP e trust-constr sì
        self.fallback_solvers = {
            "trust-constr": ["slsqp"], # COBYLA potrebbe essere troppo diverso
            "slsqp": ["trust-constr"],
            "cobyla": ["slsqp"]
        }

    def solve(
        self,
        objective_func: Callable[[np.ndarray], float],
        initial_point: np.ndarray,
        bounds: Bounds, # Usiamo l'oggetto Bounds di SciPy
        constraints: List[Union[LinearConstraint, NonlinearConstraint]], # Usiamo oggetti SciPy
        jacobian_func: Optional[Callable[[np.ndarray], np.ndarray]] = None,
        constraint_jacobian_func: Optional[Callable[[np.ndarray], np.ndarray]] = None,
        grade_name: str = "unknown"
    ) -> Tuple[OptimizeResult, List[SolverAttempt]]:
        """
        Tenta di risolvere il problema di ottimizzazione con strategie di fallback.

        Args:
            objective_func: Funzione obiettivo da minimizzare.
            initial_point: Punto iniziale (frazioni componenti liberi).
            bounds: Oggetto Bounds per le variabili.
            constraints: Lista di oggetti LinearConstraint e NonlinearConstraint.
            jacobian_func: Funzione per il calcolo del gradiente dell'obiettivo (opzionale).
            constraint_jacobian_func: Funzione per il calcolo del Jacobiano dei vincoli non lineari (opzionale).
            grade_name: Nome del grade (per logging).

        Returns:
            Tuple[OptimizeResult, List[SolverAttempt]]: Risultato dell'ottimizzazione e lista dei tentativi.

        Raises:
            SolverConvergenceError: Se tutti i tentativi falliscono.
            InfeasibleProblemError: Se il solver determina che il problema è infattibile.
        """
        attempts_log: List[SolverAttempt] = []
        current_method = self.config.solver
        current_options = self.config.options.copy()
        current_x0 = initial_point.copy()

        # Determina se usare il Jacobiano per obiettivo e vincoli
        use_obj_jac = self.config.use_jacobian and jacobian_func is not None
        use_con_jac = self.config.use_jacobian and constraint_jacobian_func is not None

        # Prepara jac dei vincoli per trust-constr se necessario
        prepared_constraints = self._prepare_constraints_for_solver(constraints, use_con_jac, constraint_jacobian_func, current_method)

        # Tentativo principale
        success, result, attempt = self._run_attempt(
            objective_func, current_x0, bounds, prepared_constraints,
            current_method, current_options,
            jacobian_func if use_obj_jac else None,
            grade_name, "main"
        )
        attempts_log.append(attempt)
        if success: return result, attempts_log
        if result is not None and "infeasible" in result.message.lower(): # Check result is not None
             raise InfeasibleProblemError(grade_name, f"Solver {current_method} reported infeasible problem: {result.message}")

        # Tentativi con punti iniziali diversi
        self.logger.info(f"[{grade_name}] Main solver {current_method} failed. Trying {self.config.initial_point_attempts} different initial points...")
        for i in range(self.config.initial_point_attempts):
            if len(attempts_log) >= self.config.max_attempts: break
            new_x0 = self._generate_new_initial_point(initial_point, bounds)
            success, result, attempt = self._run_attempt(
                objective_func, new_x0, bounds, prepared_constraints, # Usa gli stessi vincoli preparati
                current_method, current_options,
                jacobian_func if use_obj_jac else None,
                grade_name, f"retry_x0_{i+1}"
            )
            attempts_log.append(attempt)
            if success: return result, attempts_log

        if len(attempts_log) >= self.config.max_attempts:
             raise SolverConvergenceError(grade_name, current_method, "Max attempts reached after initial point retries", attempts_log)

        # Tentativi con solver alternativi
        fallback_methods = self.fallback_solvers.get(current_method, [])
        for fallback_method in fallback_methods:
            if len(attempts_log) >= self.config.max_attempts: break
            self.logger.warning(f"[{grade_name}] Solver {current_method} failed. Trying fallback solver {fallback_method}...")

            # Adatta jac e opzioni per il solver di fallback
            fallback_use_obj_jac = use_obj_jac and fallback_method != "cobyla"
            fallback_obj_jac = jacobian_func if fallback_use_obj_jac else None
            # Prepara i vincoli specificamente per il solver di fallback
            fallback_constraints = self._prepare_constraints_for_solver(constraints, use_con_jac, constraint_jacobian_func, fallback_method)

            success, result, attempt = self._run_attempt(
                objective_func, initial_point, bounds, fallback_constraints,
                fallback_method, current_options,
                fallback_obj_jac,
                grade_name, f"fallback_{fallback_method}"
            )
            attempts_log.append(attempt)
            if success: return result, attempts_log

        if len(attempts_log) >= self.config.max_attempts:
             raise SolverConvergenceError(grade_name, current_method, "Max attempts reached after fallbacks", attempts_log)

        # Se tutti i tentativi falliscono
        raise SolverConvergenceError(grade_name, current_method, "All optimization attempts failed", attempts_log)

    def _prepare_constraints_for_solver(
        self,
        original_constraints: List[Union[LinearConstraint, NonlinearConstraint]],
        use_con_jac: bool,
        constraint_jacobian_func: Optional[Callable[[np.ndarray], np.ndarray]],
        method: str
    ) -> List[Union[LinearConstraint, NonlinearConstraint]]:
        """Prepara la lista dei vincoli per il solver specifico, aggiungendo il Jacobiano se necessario."""
        prepared_constraints = []
        for constr in original_constraints:
            if isinstance(constr, NonlinearConstraint):
                # Crea una nuova istanza di NonlinearConstraint per evitare modifiche in-place
                jac_func = None
                if method == 'trust-constr' and use_con_jac and constraint_jacobian_func:
                    jac_func = constraint_jacobian_func
                elif method == 'slsqp': # SLSQP non usa jac per NonlinearConstraint nel formato oggetto
                    pass
                prepared_constraints.append(
                    NonlinearConstraint(constr.fun, constr.lb, constr.ub, jac=jac_func, keep_feasible=constr.keep_feasible)
                )
            else: # LinearConstraint
                prepared_constraints.append(constr)
        return prepared_constraints

    def _run_attempt(
        self, objective_func, x0, bounds, constraints, method, options, obj_jac, grade_name, attempt_label
    ) -> Tuple[bool, Optional[OptimizeResult], SolverAttempt]:
        """Esegue un singolo tentativo di ottimizzazione e logga i risultati."""
        self.logger.info(f"[{grade_name}] Running attempt '{attempt_label}' with solver {method}")
        start_time = time.time()
        attempt = SolverAttempt(method, x0.copy(), options.copy())
        result = None
        try:
            # Nota: COBYLA non accetta 'bounds' o 'jac'
            # trust-constr e slsqp accettano Bounds e lista di Linear/NonlinearConstraint
            minimize_args = {
                "fun": objective_func,
                "x0": x0,
                "method": method,
                "jac": obj_jac, # Passa jac obiettivo se disponibile
                "bounds": bounds if method != 'cobyla' else None,
                "constraints": constraints if method != 'cobyla' else [c for c in constraints if isinstance(c, NonlinearConstraint)], # COBYLA usa solo non lineari
                "options": options
            }
            self.logger.debug(f"[{grade_name}] Calling minimize with method={method}, use_obj_jac={obj_jac is not None}, num_constraints={len(minimize_args['constraints'])}")

            result = minimize(**minimize_args)

            attempt.success = result.success
            attempt.message = result.message
            attempt.result = result
            if result.success:
                self.logger.info(f"[{grade_name}] Attempt '{attempt_label}' ({method}) SUCCEEDED in {result.nfev}fev/{result.nit}it: {result.message}")
            else:
                 self.logger.warning(f"[{grade_name}] Attempt '{attempt_label}' ({method}) FAILED: {result.message}")
        except (ValueError, TypeError, np.linalg.LinAlgError, Exception) as e:
            # Cattura errori più generici durante la chiamata a minimize
            attempt.success = False
            attempt.message = f"Error during optimization call: {type(e).__name__}: {str(e)}"
            self.logger.error(f"[{grade_name}] Attempt '{attempt_label}' ({method}) raised an ERROR: {attempt.message}", exc_info=True)
        finally:
            attempt.duration = time.time() - start_time
            self.logger.info(f"[{grade_name}] Attempt '{attempt_label}' ({method}) finished in {attempt.duration:.3f}s")

        return attempt.success, result, attempt

    def _generate_new_initial_point(self, x0: np.ndarray, bounds: Bounds) -> np.ndarray:
        """Genera un nuovo punto iniziale casuale normalizzato all'interno dei bounds."""
        low_bounds = bounds.lb
        high_bounds = bounds.ub

        # Genera punti casuali uniformemente tra low e high bounds
        new_x0 = low_bounds + np.random.rand(len(x0)) * (high_bounds - low_bounds)

        # Assicura che la somma sia vicina a hc_mass (il vincolo lineare gestirà l'uguaglianza esatta)
        # Usare la somma degli high_bounds è una stima ragionevole del target sum per la normalizzazione,
        # dato che i bounds stessi riflettono la massa disponibile per i componenti liberi.
        target_sum = np.sum(high_bounds)
        current_sum = np.sum(new_x0)
        if current_sum > 1e-9:
            new_x0 = new_x0 * (target_sum / current_sum) # Scala per avvicinarsi alla somma target

        # Assicura che i valori siano strettamente dentro i bounds per evitare problemi numerici
        # Aggiungiamo un piccolo epsilon ai limiti
        epsilon = 1e-9
        adjusted_low = np.minimum(low_bounds + epsilon, high_bounds - epsilon)
        adjusted_high = np.maximum(high_bounds - epsilon, low_bounds + epsilon)
        new_x0 = np.clip(new_x0, adjusted_low, adjusted_high)

        # Rinormalizza se il clip ha cambiato significativamente la somma
        final_sum = np.sum(new_x0)
        if final_sum > 1e-9 and abs(final_sum - target_sum) > 1e-6:
             new_x0 = new_x0 * (target_sum / final_sum)
             new_x0 = np.clip(new_x0, adjusted_low, adjusted_high) # Clip finale

        self.logger.debug(f"Generated new initial point (sum={np.sum(new_x0):.4f})")
        return new_x0

class Optimizer:
    """
    Classe principale per l'ottimizzazione del blending.

    Orchestra la preparazione dei dati, l'esecuzione dell'ottimizzazione
    tramite SolverManager e il post-processing dei risultati.
    """

    def __init__(self, context: BlendingContext, config: OptimizerConfig):
        """
        Inizializza l'ottimizzatore.

        Args:
            context: Contesto di blending con dati e configurazioni.
            config: Configurazione dell'ottimizzatore.
        """
        self.context = context
        self.config = config
        # Passa parametri da context a calculator se necessario (es. rvp_exp, ron_linear_min)
        self.calculator = PropertyCalculator(rvp_exp=context.rvp_exp, ron_linear_min=context.grade.ron_linear_min)
        self.constraint_manager = ConstraintManager() # Istanza del gestore vincoli
        self.solver_manager = SolverManager(config) # Usa SolverManager
        self.logger = logging.getLogger(f"{__name__}.Optimizer")

        # Prepara i vincoli di specifica dal grade
        self.constraint_manager.add_constraints_from_grade(self.context.grade)
        self.logger.info(f"Optimizer initialized for grade '{self.context.grade.name}' with {len(self.constraint_manager.get_active_constraints())} spec constraints.")

    def _objective_function(self, free_fractions: np.ndarray) -> float:
        """Funzione obiettivo: minimizzare il costo totale del blend (USD/mt)."""
        try:
            all_fractions = self.context.reconstruct_fractions(free_fractions)
            # Calcola le proprietà del blend HC necessarie (almeno la densità)
            blend_properties = self.calculator.calculate_properties(self.context.components, all_fractions)
            blend_density = blend_properties.get(PROPERTY_DENSITY)

            # Calcola il costo base degli idrocarburi
            hc_cost = self.context.calculate_total_cost(all_fractions, blend_properties)

            # Calcola il costo aggiuntivo degli additivi
            total_additive_cost_per_mt = 0.0
            if blend_density is not None and blend_density > 1e-9: # Assicurati che la densità sia valida
                for additive_name, ppm_vol in self.context.grade.additives.items():
                    additive = self.context.get_additive_by_name(additive_name)
                    if additive and additive.cost_usd_per_litre is not None:
                        # Formula: (ppm/1e6) * (cost_usd_per_litre / blend_density_kg_per_m3)
                        # Assumendo blend_density in kg/m3 e cost in USD/litre
                        # (ppm_vol / 1e6) [vol_add/vol_blend] * (1 / blend_density [kg/m3]) [m3_blend/kg_blend] * cost_usd_per_litre [USD/litre_add]
                        # = (ppm_vol / 1e6) * (1 / blend_density) * 1000 [litre_blend/kg_blend] * cost_usd_per_litre [USD/litre_add]
                        # Questo non sembra corretto. Rivediamo le unità.
                        # ppm_vol = (Volume Additivo / Volume Blend) * 1e6
                        # Costo Additivo [USD/mt Blend] = (Volume Additivo / Massa Blend) * Costo Additivo [USD / Volume Additivo]
                        # Volume Additivo / Massa Blend = (Volume Additivo / Volume Blend) * (Volume Blend / Massa Blend)
                        #                             = (ppm_vol / 1e6) * (1 / blend_density [kg/m3])
                        #                             = (ppm_vol / 1e6 / blend_density) [m3 Additivo / kg Blend]
                        # Converti m3 Additivo in Litri: * 1000
                        #                             = (ppm_vol * 1000 / 1e6 / blend_density) [Litri Additivo / kg Blend]
                        # Converti kg Blend in mt Blend: * 1000
                        #                             = (ppm_vol * 1000 * 1000 / 1e6 / blend_density) [Litri Additivo / mt Blend]
                        #                             = (ppm_vol / blend_density) [Litri Additivo / mt Blend]
                        # Costo Additivo [USD/mt Blend] = (ppm_vol / blend_density) * cost_usd_per_litre [USD/Litre Additivo]
                        cost_add_k_per_mt = (ppm_vol / blend_density) * additive.cost_usd_per_litre
                        total_additive_cost_per_mt += cost_add_k_per_mt
                        self.logger.debug(f"Additive {additive_name}: ppm={ppm_vol}, cost/L={additive.cost_usd_per_litre}, blend_dens={blend_density:.4f}, cost/mt={cost_add_k_per_mt:.4f}")
                    elif not additive:
                        self.logger.warning(f"Additive {additive_name} requested by grade but not found in context during cost calculation.")
            elif blend_density is None or blend_density <= 1e-9:
                 self.logger.warning(f"Blend density ({blend_density}) is invalid, cannot calculate additive costs.")
                 # Potrebbe essere meglio restituire inf se la densità non è calcolabile?
                 # return np.inf

            total_cost = hc_cost + total_additive_cost_per_mt
            self.logger.debug(f"Objective function: HC Cost={hc_cost:.4f}, Additive Cost={total_additive_cost_per_mt:.4f}, Total={total_cost:.4f}")
            return total_cost
        except Exception as e:
            self.logger.error(f"Error in objective function: {e}", exc_info=True)
            return np.inf # Ritorna infinito in caso di errore

    def _objective_jacobian(self, free_fractions: np.ndarray) -> np.ndarray:
        """Jacobiano della funzione obiettivo rispetto alle frazioni libere."""
        try:
            # Calcola il Jacobiano del costo HC
            all_fractions = self.context.reconstruct_fractions(free_fractions)
            # Calcola le proprietà e le derivate necessarie (almeno densità)
            blend_properties = self.calculator.calculate_properties(self.context.components, all_fractions)
            property_derivatives = self.calculator.calculate_property_jacobians(self.context.components, all_fractions)
            blend_density = blend_properties.get(PROPERTY_DENSITY)
            blend_density_jacobian_full = property_derivatives.get(PROPERTY_DENSITY)

            # Jacobiano del costo HC (rispetto a tutte le frazioni)
            hc_cost_jacobian_full = self.context.calculate_total_cost_jacobian(all_fractions, blend_properties, property_derivatives)
            if hc_cost_jacobian_full is None:
                self.logger.error("Failed to calculate hydrocarbon cost jacobian.")
                return np.zeros(len(free_fractions))

            # Calcola il Jacobiano del costo additivi
            total_additive_cost_jacobian_full = np.zeros_like(hc_cost_jacobian_full)
            if blend_density is not None and blend_density > 1e-9 and blend_density_jacobian_full is not None:
                # d(1/D_blend)/dw_j = - (1 / D_blend^2) * d(D_blend)/dw_j
                d_inv_density_dw = - (1.0 / (blend_density**2 + 1e-9)) * blend_density_jacobian_full

                for additive_name, ppm_vol in self.context.grade.additives.items():
                    additive = self.context.get_additive_by_name(additive_name)
                    if additive and additive.cost_usd_per_litre is not None:
                        # Jacobiano del costo dell'additivo k rispetto a tutte le frazioni w
                        # d(cost_add_k)/dw = d((ppm_vol / D_blend) * cost_usd_per_litre) / dw
                        #                  = (ppm_vol * cost_usd_per_litre) * d(1/D_blend)/dw
                        additive_cost_jacobian_k = (ppm_vol * additive.cost_usd_per_litre) * d_inv_density_dw
                        total_additive_cost_jacobian_full += additive_cost_jacobian_k
            elif blend_density is None or blend_density <= 1e-9:
                self.logger.warning(f"Blend density ({blend_density}) is invalid, cannot calculate additive cost jacobian.")
            elif blend_density_jacobian_full is None:
                 self.logger.warning("Blend density jacobian is not available, cannot calculate additive cost jacobian.")

            # Jacobiano totale rispetto a tutte le frazioni
            total_cost_jacobian_full = hc_cost_jacobian_full + total_additive_cost_jacobian_full

            # Estrai le colonne corrispondenti alle frazioni libere
            free_indices = self.context.free_indices
            jacobian_free = total_cost_jacobian_full[free_indices]
            self.logger.debug(f"Objective Jacobian (free vars): {jacobian_free}")
            return jacobian_free
        except Exception as e:
            self.logger.error(f"Error in objective jacobian: {e}", exc_info=True)
            # Ritorna zeri della dimensione corretta
            return np.zeros(len(self.context.free_indices))

    def _constraint_function_wrapper(self, free_fractions: np.ndarray) -> np.ndarray:
        """Wrapper per la funzione dei vincoli non lineari per gestire errori."""
        try:
            all_fractions = self.context.reconstruct_fractions(free_fractions)
            # Usa il metodo aggiornato del constraint manager
            constraint_values = self.constraint_manager.evaluate_constraints_for_scipy(all_fractions, self.calculator)
            return constraint_values
        except Exception as e:
            self.logger.error(f"Error in constraint function: {e}", exc_info=True)
            # Ritorna un valore che probabilmente violerà i vincoli
            num_constraints = len(self.constraint_manager.get_scipy_nonlinear_constraints_definitions()) # Ottieni numero vincoli
            return np.full(num_constraints, np.inf)

    def _constraint_jacobian_wrapper(self, free_fractions: np.ndarray) -> np.ndarray:
        """Wrapper per il Jacobiano dei vincoli non lineari per gestire errori."""
        try:
            all_fractions = self.context.reconstruct_fractions(free_fractions)
            # Usa il metodo aggiornato del constraint manager
            full_jacobian = self.constraint_manager.evaluate_jacobian_for_scipy(all_fractions, self.calculator)
            # Estrai colonne corrispondenti ai componenti liberi
            jac = full_jacobian[:, self.context.free_indices]
            # self.logger.debug(f"Constraint Jacobian shape: {jac.shape}") # Debug log
            return jac
        except Exception as e:
            self.logger.error(f"Error in constraint jacobian: {e}", exc_info=True)
            # Ritorna una matrice di zeri della dimensione corretta
            num_constraints = len(self.constraint_manager.get_scipy_nonlinear_constraints_definitions())
            num_free_vars = len(self.context.free_indices)
            return np.zeros((num_constraints, num_free_vars))

    def _extract_lagrange_multipliers(
        self,
        result: OptimizeResult,
        linear_constraints: List[LinearConstraint],
        nonlinear_constraints: List[NonlinearConstraint],
        bounds: Bounds
        ) -> Dict[str, float]:
        """Estrae i moltiplicatori di Lagrange dai risultati.

        Tenta di estrarre i moltiplicatori per 'trust-constr'. Per 'SLSQP',
        l'estrazione non è supportata in modo affidabile da scipy.optimize.minimize.
        """
        lambdas = {}
        num_vars = len(result.x)
        active_constraints_map = self.constraint_manager.get_active_constraints_map() # {prop_type: Constraint}
        solver_method = result.get('method', self.config.solver) # Get method from result if available

        try:
            # --- Trust-Constr --- 
            if solver_method == 'trust-constr' and hasattr(result, 'v') and result.v is not None and len(result.v) > 0:
                # trust-constr: result.v contiene moltiplicatori per [linear_eq, linear_ineq, nonlinear_eq, nonlinear_ineq, bounds_lower, bounds_upper]
                # L'ordine è determinato da come SciPy assembla internamente i vincoli.
                lagrange_multipliers = result.v
                current_idx = 0
                self.logger.debug(f"Raw Lagrange multipliers (trust-constr): {lagrange_multipliers}")

                # 1. Vincoli Lineari (assumendo solo sum_fraction_equality)
                num_lc = sum(lc.A.shape[0] for lc in linear_constraints)
                if num_lc == 1 and current_idx < len(lagrange_multipliers):
                    lambdas["sum_fraction_equality"] = float(lagrange_multipliers[current_idx])
                    self.logger.debug(f"Mapped lambda['sum_fraction_equality'] = {lambdas['sum_fraction_equality']:.4e} (Index: {current_idx})")
                    current_idx += 1
                elif num_lc > 1:
                     self.logger.warning(f"Unexpected number of linear constraints ({num_lc}), skipping Lagrange mapping for linear.")
                     current_idx += num_lc # Skip expected indices

                # 2. Vincoli Non Lineari (nell'ordine definito in ConstraintManager)
                nlc_definitions = self.constraint_manager.get_scipy_nonlinear_constraints_definitions()
                num_nlc = len(nlc_definitions)
                if num_nlc != len(nonlinear_constraints):
                     self.logger.warning("Mismatch between nonlinear constraint definitions and SciPy objects.")
                
                for i, (prop_name, const_type) in enumerate(nlc_definitions):
                    if current_idx < len(lagrange_multipliers):
                        lambda_val = float(lagrange_multipliers[current_idx])
                        constraint_key = f"{prop_name}_{const_type}" # Es: "ron_min", "rvp_max"
                        lambdas[constraint_key] = lambda_val
                        self.logger.debug(f"Mapped lambda['{constraint_key}'] = {lambda_val:.4e} (Index: {current_idx})")
                        current_idx += 1
                    else:
                        self.logger.warning(f"Ran out of Lagrange multipliers while mapping non-linear constraint {i+1} ('{prop_name}_{const_type}')")
                        break
                
                # Ensure we skip the correct number even if mapping failed midway
                current_idx = num_lc + num_nlc 

                # 3. Bounds (Lower and Upper)
                # Lower bounds
                start_lower_bound_idx = current_idx
                for i in range(num_vars):
                    idx_to_check = start_lower_bound_idx + i
                    if idx_to_check < len(lagrange_multipliers):
                        lambda_val = float(lagrange_multipliers[idx_to_check])
                        if abs(lambda_val) > 1e-7: # Logga solo se significativo
                            comp_name = self.context.components[self.context.free_indices[i]].name
                            bound_key = f"bound_lower_{comp_name}"
                            lambdas[bound_key] = lambda_val
                            self.logger.debug(f"Mapped lambda['{bound_key}'] = {lambda_val:.4e} (Index: {idx_to_check})")
                    else:
                        self.logger.warning(f"Ran out of Lagrange multipliers while mapping lower bound {i+1}")
                        break
                
                # Upper bounds
                start_upper_bound_idx = start_lower_bound_idx + num_vars
                for i in range(num_vars):
                    idx_to_check = start_upper_bound_idx + i
                    if idx_to_check < len(lagrange_multipliers):
                        lambda_val = float(lagrange_multipliers[idx_to_check])
                        if abs(lambda_val) > 1e-7: # Logga solo se significativo
                            comp_name = self.context.components[self.context.free_indices[i]].name
                            bound_key = f"bound_upper_{comp_name}"
                            lambdas[bound_key] = lambda_val
                            self.logger.debug(f"Mapped lambda['{bound_key}'] = {lambda_val:.4e} (Index: {idx_to_check})")
                    else:
                        self.logger.warning(f"Ran out of Lagrange multipliers while mapping upper bound {i+1}")
                        break

            # --- SLSQP --- 
            elif solver_method == 'slsqp':
                # Based on research (StackOverflow, GitHub issues), standard scipy.optimize.minimize
                # with SLSQP does not reliably expose Lagrange multipliers in the OptimizeResult object.
                # Therefore, extraction is not supported for SLSQP.
                self.logger.warning("Lagrange multiplier extraction is not reliably supported for the 'SLSQP' solver within scipy.optimize.minimize. Multipliers will be empty.")

            # --- Other Solvers --- 
            else:
                self.logger.info(f"Lagrange multipliers not available or extraction not implemented for solver '{solver_method}'.")

        except IndexError as e:
            self.logger.error(f"Error extracting Lagrange multipliers: Index out of bounds. This might indicate an unexpected structure in result.v for '{solver_method}'. {e}", exc_info=True)
        except Exception as e:
            self.logger.error(f"Error extracting Lagrange multipliers: {e}", exc_info=True)

        return lambdas

    def _check_constraints(
        self,
        final_fractions: np.ndarray,
        tolerance: float
        ) -> Tuple[bool, Dict[str, Tuple[float, float, str]]]:
        """Verifica i vincoli dopo l'ottimizzazione."""
        all_satisfied = True
        violations: Dict[str, Tuple[float, float, str]] = {}
        try:
            calculated_properties = self.calculator.calculate_properties(self.context.components, final_fractions)
            active_constraints = self.constraint_manager.get_active_constraints()

            self.logger.info("--- Post-Optimization Constraint Check ---")
            for constraint in active_constraints:
                prop_name = constraint.property_name
                # Gestione speciale per RON_AVERAGE
                prop_name_in_calc = self.context.grade.PROPERTY_RON if prop_name == self.context.grade.PROPERTY_RON_AVERAGE else prop_name

                if prop_name_in_calc not in calculated_properties:
                    self.logger.warning(f"Property '{prop_name_in_calc}' for constraint '{prop_name}' not found in calculated properties.")
                    continue

                prop_value = calculated_properties[prop_name_in_calc]
                satisfied, violation_amount = self.constraint_manager.check_constraint(constraint, prop_value)

                bound_type_str = constraint.constraint_type
                bound_value = constraint.value
                status_str = "OK"

                if violation_amount > tolerance:
                    all_satisfied = False
                    status_str = f"VIOLATED (Value: {prop_value:.4f}, Violation: {violation_amount:.4e})"
                    violations[prop_name] = (prop_value, violation_amount, f"{bound_type_str} {bound_value:.4f}")
                else:
                    status_str = f"OK (Value: {prop_value:.4f})"

                self.logger.info(f"Constraint [{prop_name} {bound_type_str} {bound_value:.4f}]: {status_str}")
            self.logger.info("--- End Constraint Check ---")

            # Verifica somma frazioni (già vincolata, ma controllo extra)
            total_sum = np.sum(final_fractions)
            if abs(total_sum - 1.0) > tolerance:
                 all_satisfied = False
                 violation_sum = abs(total_sum - 1.0)
                 violations["sum_fractions"] = (total_sum, violation_sum, "equal 1.0")
                 self.logger.warning(f"Sum of fractions deviates significantly from 1.0: {total_sum:.6f}")

        except Exception as e:
            self.logger.error(f"Error during post-optimization constraint check: {e}", exc_info=True)
            return False, {"check_error": (0.0, 1.0, str(e))}

        return all_satisfied, violations

    def optimize(self) -> OptimizationResultModel:
        """
        Esegue l'intero processo di ottimizzazione.

        Returns:
            OptimizationResultModel: Risultato dell'ottimizzazione.

        Raises:
            OptimizationError: Se l'ottimizzazione fallisce per motivi imprevisti.
            SolverConvergenceError: Se il solver non converge dopo tutti i tentativi.
            ConstraintViolationError: Se i vincoli non sono soddisfatti dopo l'ottimizzazione (e check_constraints_post è True).
            InfeasibleProblemError: Se il solver determina che il problema è infattibile.
        """
        start_time = time.time()
        self.logger.info(f"Starting optimization for grade: {self.context.grade.name}")

        # Definisci variabili libere e bounds
        free_indices = self.context.free_indices
        if not free_indices:
            raise OptimizationError("No free variables available for optimization.")

        initial_point = np.array([1.0 / len(free_indices)] * len(free_indices)) * self.context.hc_mass
        bounds_list = [(0.0, 1.0)] * len(free_indices) # Bounds base 0-1 per le frazioni libere
        bounds = Bounds([b[0] for b in bounds_list], [b[1] for b in bounds_list])

        # Definisci vincoli lineari (somma frazioni libere = hc_mass)
        # Sum(x_free) = hc_mass
        linear_constraint_matrix = np.ones((1, len(free_indices)))
        linear_constraints = [
            LinearConstraint(linear_constraint_matrix, lb=self.context.hc_mass, ub=self.context.hc_mass)
        ]
        self.logger.debug(f"Linear constraint: Sum(free_vars) == {self.context.hc_mass:.4f}")

        # Definisci vincoli non lineari (specifiche grade)
        # Ottieni le definizioni dei vincoli non lineari per SciPy
        nlc_definitions = self.constraint_manager.get_scipy_nonlinear_constraints_definitions()
        if nlc_definitions:
            # Crea l'oggetto NonlinearConstraint
            # Le funzioni wrapper gestiranno il calcolo effettivo
            # I limiti lb/ub sono determinati dal tipo di vincolo (min/max)
            lbs = [0.0 if const_type == CONSTRAINT_MIN else -np.inf for _, const_type in nlc_definitions]
            ubs = [np.inf if const_type == CONSTRAINT_MIN else 0.0 for _, const_type in nlc_definitions]
            # Pass jacobian wrapper only if needed by the intended solver (trust-constr)
            jac_func = self._constraint_jacobian_wrapper if self.config.solver == 'trust-constr' and self.config.use_jacobian else None
            nonlinear_constraints = [
                NonlinearConstraint(self._constraint_function_wrapper, lb=lbs, ub=ubs, jac=jac_func)
            ]
            self.logger.debug(f"Defined {len(nlc_definitions)} non-linear constraints.")
        else:
            nonlinear_constraints = []
            self.logger.debug("No non-linear constraints defined.")

        all_constraints = linear_constraints + nonlinear_constraints

        # Esegui ottimizzazione con SolverManager
        try:
            result, attempts_log = self.solver_manager.solve(
                objective_func=self._objective_function,
                initial_point=initial_point,
                bounds=bounds,
                constraints=all_constraints,
                jacobian_func=self._objective_jacobian if self.config.use_jacobian else None,
                # constraint_jacobian_func è passato implicitamente tramite NonlinearConstraint e _prepare_constraints_for_solver
                grade_name=self.context.grade.name
            )
        except (SolverConvergenceError, InfeasibleProblemError) as e:
            self.logger.error(f"Optimization failed for grade '{self.context.grade.name}': {e}")
            raise e # Rilancia l'eccezione specifica
        except Exception as e:
            self.logger.error(f"Unexpected error during optimization: {e}", exc_info=True)
            raise OptimizationError(f"Unexpected error: {e}")

        # Estrai risultati
        final_free_fractions = result.x
        final_all_fractions = self.context.reconstruct_fractions(final_free_fractions)
        final_cost = result.fun

        # Calcola proprietà finali
        final_properties = self.calculator.calculate_properties(self.context.components, final_all_fractions)

        # Estrai moltiplicatori di Lagrange
        # Pass the actual solver method used (from result) if available
        result_with_method = result.copy() # Avoid modifying original result
        if 'method' not in result_with_method:
             result_with_method['method'] = self.config.solver # Fallback to config if not in result
        lagrange_multipliers = self._extract_lagrange_multipliers(result_with_method, linear_constraints, nonlinear_constraints, bounds)

        # Verifica vincoli post-ottimizzazione
        constraints_satisfied, violations = True, {}
        if self.config.check_constraints_post:
            constraints_satisfied, violations = self._check_constraints(final_all_fractions, self.config.constraint_tolerance)
            if not constraints_satisfied:
                violation_details = "; ".join([f"{p}: {v[0]:.4f} (viol: {v[1]:.2e}, target: {v[2]})" for p, v in violations.items()])
                error_msg = f"Constraints violated after optimization for grade '{self.context.grade.name}'. Violations: {violation_details}"
                self.logger.error(error_msg)
                # Non sollevare eccezione qui, ma segnalare nel risultato
                # raise ConstraintViolationError(error_msg)

        total_duration = time.time() - start_time
        self.logger.info(f"Optimization for grade '{self.context.grade.name}' completed in {total_duration:.3f}s. Final cost: {final_cost:.4f} USD/mt")

        # Crea modello di risultato
        optimization_result = OptimizationResultModel(
            grade_name=self.context.grade.name,
            success=result.success and constraints_satisfied, # Successo se solver converge E vincoli rispettati
            message=result.message if result.success else f"Solver failed: {result.message}",
            total_cost_usd_mt=final_cost,
            blend_composition={comp.name: float(frac) for comp, frac in zip(self.context.components, final_all_fractions) if frac > 1e-9},
            blend_properties=final_properties,
            lagrange_multipliers=lagrange_multipliers,
            solver_attempts=attempts_log,
            solver_result_details={
                'nfev': result.nfev, 'nit': result.nit, 'status': result.status,
                'njev': result.njev if hasattr(result, 'njev') else None,
                'nhev': result.nhev if hasattr(result, 'nhev') else None
            },
            constraint_violations=violations,
            optimization_duration_sec=total_duration
        )

        return optimization_result

