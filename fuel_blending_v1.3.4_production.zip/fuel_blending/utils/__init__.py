"""
Utility di alto livello & re-export di costanti/exception.

Questo file espone:
    * tutte le costanti di utils.constants
    * le eccezioni personalizzate
    * setup_logging() – funzione per configurare il logging
"""

from __future__ import annotations

from .constants import *  # noqa: F403, F401
from .exceptions import (
    FuelBlendingError,
    OptimizationError,
    PropertyCalculationError,
    SensitivityAnalysisError,
)
from .logging_setup import setup_logging

__all__ = [
    # costanti
    *[name for name in globals() if name.isupper()],
    # eccezioni
    "FuelBlendingError",
    "OptimizationError",
    "PropertyCalculationError",
    "SensitivityAnalysisError",
    # funzioni
    "setup_logging",
]
