"""
Configurazione centralizzata del logging per Fuel-Blending.

Usa:
    from fuel_blending.utils import setup_logging
    setup_logging(level="INFO", log_file="fuel_blending.log")
"""

from __future__ import annotations

import logging
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional


_DEFAULT_FORMAT = (
    "%(asctime)s [%(levelname)s] %(name)s | %(message)s "
    "(%(filename)s:%(lineno)d)"
)
_DEFAULT_DATEFMT = "%Y-%m-%d %H:%M:%S"


def _add_file_handler(
    logger: logging.Logger,
    file_path: Path,
    level: int,
) -> None:
    file_path.parent.mkdir(parents=True, exist_ok=True)
    handler = RotatingFileHandler(
        file_path, maxBytes=5_000_000, backupCount=3, encoding="utf-8"
    )
    handler.setLevel(level)
    handler.setFormatter(logging.Formatter(_DEFAULT_FORMAT, _DEFAULT_DATEFMT))
    logger.addHandler(handler)


def setup_logging(
    *,
    level: str | int = "INFO",
    log_file: Optional[str | Path] = None,
    root_name: str = "fuel_blending",
) -> logging.Logger:
    """
    Inizializza (o restituisce) il logger root del progetto.

    Args:
        level: livello minimo («DEBUG», «INFO», … o int).
        log_file: opzionale; se fornito, crea un handler a rotazione.
        root_name: namespace principale da configurare.

    Returns:
        logging.Logger: il logger configurato.
    """
    lvl = logging.getLevelName(level) if isinstance(level, str) else level
    logger = logging.getLogger(root_name)
    logger.setLevel(lvl)

    # Evita duplicazioni se setup_logging viene chiamato più volte.
    if not any(isinstance(h, logging.StreamHandler) for h in logger.handlers):
        stream = logging.StreamHandler()
        stream.setLevel(lvl)
        stream.setFormatter(logging.Formatter(_DEFAULT_FORMAT, _DEFAULT_DATEFMT))
        logger.addHandler(stream)

    if log_file:
        _add_file_handler(logger, Path(log_file), lvl)

    # Propaga a sub-logger solo se non già configurati.
    logging.captureWarnings(True)
    return logger
