"""
Eccezioni personalizzate per il pacchetto fuel_blending.

Questo modulo definisce tutte le eccezioni specifiche utilizzate nel pacchetto.
"""

class FuelBlendingError(Exception):
    """Eccezione base per tutti gli errori del pacchetto fuel_blending."""
    pass


class OptimizationError(FuelBlendingError):
    """Errore durante l'ottimizzazione del blend."""
    pass


class SolverConvergenceError(OptimizationError):
    """Errore specifico quando il solver non converge."""
    pass


class ConstraintViolationError(OptimizationError):
    """Errore specifico quando i vincoli non sono soddisfatti."""
    pass


class InfeasibleProblemError(OptimizationError):
    """Errore specifico quando il problema di ottimizzazione risulta infattibile."""
    pass


class PropertyCalculationError(FuelBlendingError):
    """Errore nel calcolo delle proprietà di blending."""
    pass


class SensitivityAnalysisError(FuelBlendingError):
    """Errore nell'analisi di sensibilità / presenza componenti."""
    pass


class ConfigurationError(FuelBlendingError):
    """Errore nella configurazione del pacchetto o dei dati di input."""
    pass


class DataLoadError(FuelBlendingError):
    """Errore durante il caricamento dei dati da file o Google Drive."""
    pass


class AuthenticationError(FuelBlendingError):
    """Errore durante l'autenticazione con servizi esterni (es. Google Drive)."""
    pass


class GoogleDriveError(FuelBlendingError):
    """Errore specifico per le operazioni con Google Drive."""
    pass

