"""
Logging dettagliato per il pacchetto fuel_blending.

Questo modulo estende le funzionalità di logging_setup.py con funzioni
per il logging dettagliato di operazioni specifiche.
"""

import logging
import time
from functools import wraps
from typing import Any, Callable, TypeVar

from .logging_setup import setup_logging

# Type variable per le funzioni decorate
F = TypeVar('F', bound=Callable[..., Any])

# Ottieni il logger per questo modulo
logger = setup_logging(root_name="fuel_blending.utils.detailed_logging")


def log_execution_time(func: F) -> F:
    """
    Decoratore che registra il tempo di esecuzione di una funzione.
    
    Args:
        func: La funzione da decorare
        
    Returns:
        La funzione decorata
    """
    @wraps(func)
    def wrapper(*args: Any, **kwargs: Any) -> Any:
        start_time = time.time()
        logger.debug(f"Iniziando l'esecuzione di {func.__name__}")
        
        try:
            result = func(*args, **kwargs)
            execution_time = time.time() - start_time
            logger.debug(f"{func.__name__} completata in {execution_time:.4f} secondi")
            return result
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"{func.__name__} fallita dopo {execution_time:.4f} secondi: {str(e)}")
            raise
            
    return wrapper  # type: ignore


def log_optimization_step(step: int, objective_value: float, constraints_violation: float) -> None:
    """
    Registra un passo di ottimizzazione.
    
    Args:
        step: Numero del passo di ottimizzazione
        objective_value: Valore corrente della funzione obiettivo
        constraints_violation: Violazione massima dei vincoli
    """
    logger.debug(
        f"Passo ottimizzazione {step}: "
        f"obiettivo={objective_value:.6f}, "
        f"violazione_vincoli={constraints_violation:.6e}"
    )


def log_property_calculation(property_name: str, components: list[str], values: list[float], result: float) -> None:
    """
    Registra il calcolo di una proprietà di blending.
    
    Args:
        property_name: Nome della proprietà calcolata
        components: Lista dei nomi dei componenti
        values: Lista dei valori della proprietà per ciascun componente
        result: Risultato del calcolo
    """
    logger.debug(f"Calcolo proprietà {property_name}: risultato={result:.6f}")
    if logger.isEnabledFor(logging.DEBUG):
        for comp, val in zip(components, values):
            logger.debug(f"  {comp}: {val:.6f}")
