"""
Costanti utilizzate nel pacchetto fuel_blending.

Questo modulo definisce tutte le costanti utilizzate nel pacchetto per evitare
l'uso di stringhe letterali nel codice.
"""

# Proprietà dei carburanti
PROPERTY_RON = "ron"
PROPERTY_MON = "mon"
PROPERTY_RVP = "rvp"
PROPERTY_DENSITY = "density"
PROPERTY_SULFUR_PPM = "sulfur_ppm" # Rinominato da PROPERTY_SULFUR
PROPERTY_BENZENE = "benzene"
PROPERTY_AROMATICS = "aromatics"
PROPERTY_OLEFINS = "olefins"
PROPERTY_E150 = "e150"
PROPERTY_E70 = "e70"
PROPERTY_OXY_WT = "oxy_wt" # Rinominato da PROPERTY_OXYGEN
PROPERTY_T10 = "t10"  # Riattivato T10
PROPERTY_T50 = "t50"
PROPERTY_MTBE = "mtbe"

# Specifiche target aggiuntive (non proprietà dei componenti)
PROPERTY_RON_AVERAGE = "ron_average"

# Tipi di vincoli
CONSTRAINT_MIN = "min"
CONSTRAINT_MAX = "max"
CONSTRAINT_EQUAL = "equal"

# Valori di default
DEFAULT_FLAT_PRICE = 700.0
DEFAULT_RVP_EXP = 1.25
DEFAULT_HC_MASS = 1.0
DEFAULT_BASE_DENSITY = 755.0 # Densità base per escalation prezzo

# Costanti per l'analisi di sensibilità
SENSITIVITY_PRICE = "price"
SENSITIVITY_PRESENCE = "presence"

# Colonne per i risultati dell'analisi
COL_COMPONENT = "component"
COL_GRADE = "grade"
COL_ORIGINAL_FRACTION = "original_fraction"
COL_BASELINE_COST = "baseline_cost"
COL_NEW_COST = "new_cost"
COL_COST_CHANGE = "cost_change"
COL_COST_CHANGE_PERCENT = "cost_change_percent"
COL_IS_FEASIBLE = "is_feasible"
COL_IMPACT_SCORE = "impact_score"

# Costanti per il tipo di delta di prezzo (definite anche in models.py)
DELTA_TYPE_AS_IS = "as_is"
DELTA_TYPE_FACTOR = "factor"
DELTA_TYPE_ESCALATED = "escalated"

# Costanti per la modalità di prezzo del grade (definite anche in models.py)
PRICE_MODE_AS_IS = "as_is"
PRICE_MODE_ESCALATED = "escalated"

# Costanti per l'analisi economica (definite anche in economic_analyzer.py)
KEY_CANDIDATE = "Candidate"
KEY_GRADE = "Grade"
KEY_MV_USD_T = "MV (USD/t)"
KEY_DELTA_NEUT = "Delta Neut"
KEY_MULT_NEUT = "Mult Neut"

