# Fuel Blending Optimization Package - Complete Guide (v1.3.4)

## Introduction

Welcome to the complete user guide for the Fuel Blending Optimization Package. This package provides a powerful and flexible suite of tools designed for optimizing fuel blend recipes based on component properties, target specifications, and economic factors. It incorporates advanced optimization techniques, flexible data loading capabilities (including integration with Google Drive), and detailed analysis features to help refineries and blending operations achieve optimal results.

This guide covers all aspects of the package, from installation and configuration to detailed usage instructions for the command-line interface (CLI) and interpretation of the generated outputs. Whether you are a process engineer, an optimization specialist, or a data analyst, this guide aims to provide you with the necessary information to effectively utilize the package for your fuel blending needs.

We will explore the core functionalities, including:

*   **Blend Optimization:** Finding the least-cost blend recipe that meets all specified quality constraints for various fuel grades.
*   **Candidate Evaluation:** Assessing the economic impact and feasibility of user-defined or alternative blend recipes compared to the optimal solution.
*   **Sensitivity Analysis:** Understanding how changes in input parameters, such as component prices or grade specifications, affect the optimal blend and its cost.
*   **Data Management:** Loading input data (components, grades, additives) from various sources like local Excel files or Google Drive.
*   **Configuration:** Customizing the package's behavior, including optimizer settings, logging levels, and file paths, through YAML configuration files.

This version (v1.3.4) builds upon previous versions by:
*   Modifying additive handling to use **ppm by volume**.
*   Focusing the analysis output primarily on **shadow prices** and **neutral prices**.
*   Enhancing the `eval-candidate` command to automatically calculate **neutral prices** for a specified list of components against each target grade.
*   Removing the `sensitivity` analysis functionality based on user requirements.



## Installation

Follow these steps to install the Fuel Blending Optimization Package and its dependencies. It is highly recommended to use a virtual environment to avoid conflicts with other Python projects.

1.  **Create a Virtual Environment (Recommended):**
    Open your terminal or command prompt and navigate to the directory where you have the `fuel_blending` project folder. Then, run:

    ```bash
    python3 -m venv venv
    ```

2.  **Activate the Virtual Environment:**
    *   On Linux/macOS:
        ```bash
        source venv/bin/activate
        ```
    *   On Windows (Command Prompt):
        ```bash
        venv\Scripts\activate.bat
        ```
    *   On Windows (PowerShell):
        ```bash
        .\venv\Scripts\Activate.ps1
        ```
    You should see `(venv)` prefixed to your command prompt, indicating the virtual environment is active.

3.  **Install the Package:**
    Navigate into the main `fuel_blending` directory (the one containing `pyproject.toml`). Install the package in "editable" mode. This mode links the installed package to your source code, so any changes you make to the code are immediately reflected without needing reinstallation.

    ```bash
    pip install -e .
    ```
    This command installs the core package and its essential dependencies defined in `pyproject.toml`.

4.  **Install Optional Dependencies (Optional):**
    The package includes optional dependencies for specific features like Google Drive integration or development tools (like `pytest` for running tests).

    *   To install Google Drive support:
        ```bash
        pip install -e ".[google_drive]"
        ```
    *   To install development tools (includes `rich` for table output, `mypy` for type checking, `pytest` for testing):
        ```bash
        pip install -e ".[dev]"
        ```
    *   To install all optional dependencies:
        ```bash
        pip install -e ".[google_drive,dev]"
        ```

Once the installation is complete, the `fuel-blending` command-line tool will be available in your environment.



## Configuration

The package utilizes a flexible configuration system based on YAML files and environment variables, managed by the `ConfigManager`.

### Configuration Files

Configuration settings are loaded from YAML files located in a specified configuration directory. By default, the CLI looks for a directory named `config_examples` in the current working directory, but you can specify a different directory using the `--config-dir` global option.

The loading order is as follows, with later sources overriding earlier ones:

1.  **`default.yaml`:** Contains the base configuration settings for all environments.
2.  **`{environment}.yaml`:** Contains environment-specific overrides (e.g., `development.yaml`, `production.yaml`). The environment is typically set via the `--env` global option (defaults to `development`).
3.  **User-specified file:** A specific configuration file path can be provided using the `--config-file` global option, which overrides settings from the default and environment files.
4.  **Environment Variables:** Specific configuration keys can be overridden by setting environment variables (see below).

### Configuration Structure (`default.yaml` example)

```yaml
blending:
  rvp_exp: 1.25             # Exponent for RVP calculation
  base_density: 755.0       # Base density for escalated price calculation

optimizer:
  solver: trust-constr      # Optimization solver (e.g., trust-constr, slsqp)
  options:
    maxiter: 1000           # Max iterations for the solver
    xtol: 1e-6              # Tolerance for variable changes
    gtol: 1e-6              # Tolerance for gradient norm
    barrier_tol: 1e-6       # Tolerance for barrier parameter (trust-constr)
  use_jacobian: true        # Whether to use analytical Jacobians (recommended)
  max_attempts: 5           # Max optimization attempts with different starting points
  initial_point_attempts: 10 # Number of random points to try if the first fails
  check_constraints_post: true # Verify constraints after optimization
  constraint_tolerance: 1e-6 # Tolerance for constraint violation checks

logging:
  level: INFO               # Logging level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
  file: null                # Path to log file (null for console only)
  format: "%(asctime)s - %(name)s - %(levelname)s - %(message)s" # Log message format
  max_size: 10485760        # Max log file size in bytes (10 MB)
  backup_count: 5           # Number of backup log files to keep

paths:
  data_dir: data            # Default relative path for input data
  output_dir: output          # Default relative path for output files
  log_dir: logs             # Default relative path for log files

flat_price: 700.0           # Base flat price (e.g., USD/mt) for component pricing

google_drive:               # Optional: Configuration for Google Drive integration
  credentials_file: "path/to/credentials.json" # Path to Google API credentials
  token_file: "path/to/token.json"           # Path to store/load user token
```

### Environment Variables

You can override specific configuration settings using environment variables. The variable name follows the pattern `[SECTION]_[KEY]` (all uppercase). For nested keys like optimizer options, direct override via environment variables is not supported; use YAML files instead.

*   `BLENDING_RVP_EXP`: Overrides `blending.rvp_exp`
*   `BLENDING_BASE_DENSITY`: Overrides `blending.base_density`
*   `OPTIMIZER_SOLVER`: Overrides `optimizer.solver`
*   `OPTIMIZER_MAX_ATTEMPTS`: Overrides `optimizer.max_attempts`
*   `LOGGING_LEVEL`: Overrides `logging.level`
*   `LOGGING_FILE`: Overrides `logging.file`
*   `PATHS_DATA_DIR`: Overrides `paths.data_dir`
*   `PATHS_OUTPUT_DIR`: Overrides `paths.output_dir`
*   `PATHS_LOG_DIR`: Overrides `paths.log_dir`
*   `FLAT_PRICE`: Overrides `flat_price`
*   `GOOGLE_DRIVE_CREDENTIALS_FILE`: Overrides `google_drive.credentials_file`
*   `GOOGLE_DRIVE_TOKEN_FILE`: Overrides `google_drive.token_file`

**Example:**
```bash
export LOGGING_LEVEL=DEBUG
export FLAT_PRICE=750.5
fuel-blending optimize ...
```



## Command-Line Interface (CLI) Usage

The package provides a command-line interface (CLI) tool named `fuel-blending` for executing various tasks.

### Global Options

These options can be used with any command:

*   `--config-dir <path>`: Specifies the directory containing configuration files (`default.yaml`, `development.yaml`, etc.). Defaults to `./config_examples` relative to the current working directory.
*   `--config-file <path>`: Specifies a single configuration file to load, overriding settings from `default.yaml` and environment-specific files.
*   `--env <name>`: Sets the operating environment (e.g., `development`, `production`). This determines which `{environment}.yaml` file is loaded. Defaults to `development`.
*   `--log-level <level>`: Overrides the logging level specified in the configuration (e.g., `DEBUG`, `INFO`, `WARNING`, `ERROR`).
*   `--interactive`: Enables interactive prompts, for example, for Google Drive file selection if a specific ID is not provided.

### Commands

#### 1. `optimize`

Performs the fuel blend optimization for one or more grades.

```bash
fuel-blending optimize --components <path_or_id> --grades <path_or_id> [options]
```

**Arguments:**

*   `--components-file <path_or_id>`: **Required.** Path (local) or File ID (Google Drive) of the Excel file containing component data.
*   `--grades-file <path_or_id>`: **Required.** Path (local) or File ID (Google Drive) of the Excel file containing grade specifications.
*   `--additives-file <path_or_id>`: (Optional) Path (local) or File ID (Google Drive) of the Excel file containing additive data.
*   `--output-file <path>`: (Optional) Path to save the optimization results summary. The format is determined by `--format`.
*   `--format <format>`: (Optional) Output file format (`csv` or `json`). Defaults to `csv`.
*   `--from-google-drive`: (Flag) If present, indicates that `<path_or_id>` arguments refer to Google Drive File IDs instead of local paths.
*   `--credentials-file <path>`: (Optional, for GDrive) Path to Google API credentials file. Overrides config.
*   `--token-file <path>`: (Optional, for GDrive) Path to Google API token file. Overrides config.
*   `--continue-on-error`: (Flag) If present, continues optimizing other grades even if one fails.

**Functionality:**

Loads component, grade, and optional additive data. For each grade defined in the grades file, it runs the optimization process to find the minimum cost blend that satisfies all quality specifications. It uses the solver and settings defined in the configuration. Results, including component fractions, blend properties, cost, status, and **shadow prices (Lagrange multipliers)**, are saved to the specified output file or displayed on the console.

**Console Output:** If `--output-file` is *not* specified, a summary of the optimization results is printed to the console in a formatted table, followed by a table displaying the **shadow prices** for each successfully optimized grade (requires the `rich` library, installed with `[dev]` dependencies). See the "Interpreting Results" section for more details on shadow prices.

#### 2. `eval-candidate`

Evaluates one or more predefined candidate blends against the optimal results.

```bash
fuel-blending eval-candidate --candidates <path_or_id> --grades <path_or_id> --from-results <path_or_id> --components-for-neutral-price <path_or_id> [options]
```

**Arguments:**

*   `--candidates-file <path_or_id>`: **Required.** Path/ID of the file containing candidate blends (e.g., Excel or CSV with columns: `candidate_id`, `grade_name`, `ComponentName1`, `ComponentName2`, ...).
*   `--grades-file <path_or_id>`: **Required.** Path/ID of the grades file (to get specifications for constraint checking).
*   `--results-file <path_or_id>`: **Required.** Path/ID of the file containing the optimal results (output from a previous `optimize` run, needed for comparison and economic analysis, including neutral prices).
*   `--components-for-neutral-price <path_or_id>`: **Required.** Path/ID of the Excel file containing the list of components (using the same format as the main components input file) for which neutral prices should be calculated for each target grade.
*   `--additives-file <path_or_id>`: (Optional) Path/ID of the additives file.
*   `--output-file <path>`: (Optional) Path to save the evaluation results.
*   `--format <format>`: (Optional) Output file format (`csv` or `json`). Defaults to `csv`.
*   `--from-google-drive`: (Flag) Use Google Drive for input files.
*   `--credentials-file <path>`: (Optional, for GDrive) Path to credentials file.
*   `--token-file <path>`: (Optional, for GDrive) Path to token file.

**Functionality:**

Loads components (implicitly from results or specified file), grades, additives (optional), candidate blends, previous optimization results, and the list of components for neutral price calculation. For each candidate blend, it calculates the blend properties, total cost, and checks if it meets the grade specifications. It compares the candidate's cost to the optimal cost for the same grade (if available in the results file). Using the shadow prices from the optimal results, it calculates the **neutral price** for each component specified in the `--components-for-neutral-price` file, in the context of each target grade. The evaluation details, including constraint checks, cost comparison, and neutral prices, are saved to the specified output file or displayed on the console.

**Console Output:** If `--output-file` is *not* specified, a summary of the candidate evaluation results is printed to the console in a formatted table, followed by tables displaying the **neutral prices** for each grade evaluated (requires the `rich` library). See the "Interpreting Results" section for more details on neutral prices.

###### 3. `sensitivity` (Removed in v1.3.4)

This command has been removed in version 1.3.4 based on user requirements.



## Input File Formats

The package primarily uses Excel files (`.xlsx`) for input data. Ensure your files adhere to the expected structure and naming conventions.

### 1. Components File (`components_example.xlsx`)

This file defines the properties and costs of the available blending components.

*   **Sheet Name:** Typically `Components` (configurable if needed, but standard practice is recommended).
*   **Columns:**
    *   `Name`: **Required.** Unique name for the component (e.g., `Reformate`, `Alkylate`, `Ethanol`).
    *   `Delta Type`: **Required.** How the price differential is applied. Options: `as_is`, `factor`, `escalated`.
    *   `Price Differential`: (Optional) The price difference relative to the `flat_price` defined in the configuration. Required if `Delta Type` is `as_is` or `escalated`.
    *   `Multiplier`: (Optional) The price factor relative to the `flat_price`. Required if `Delta Type` is `factor`.
    *   `Density`: **Required.** Density of the component (e.g., kg/m3 or other consistent unit).
    *   `Base Density Component`: (Optional) Base density used for `escalated` price calculations for this specific component. Overrides grade or global settings.
    *   `Max Qty (mt)`: (Optional) Maximum available quantity in metric tons.
    *   `Is Ethanol`: (Optional) Boolean (`TRUE`/`FALSE`) indicating if the component is ethanol. Used for specific calculations or constraints.
    *   *Property Columns*: **Required.** Columns for each relevant blend property (e.g., `RON`, `MON`, `Sulfur PPM`, `Density`, `RVP`, `Oxy Wt`, etc.). The column headers must match the property constants used internally (e.g., `RON`, `SULFUR_PPM`, `OXY_WT`). The loader maps these columns into the `properties` dictionary of the `Component` object.

### 2. Grades File (`grades_example.xlsx`)

This file defines the target specifications for the final fuel grades.

*   **Sheet Name:** Typically `Grades`.
*   **Columns:**
    *   `Name`: **Required.** Unique name for the grade (e.g., `Premium Unleaded`, `Regular E10`).
    *   `Target Mass (mt)`: (Optional) The target mass for the blend in metric tons. Defaults to 1.0.
    *   `Price Mode`: (Optional) How the grade's price is determined for economic analysis. Options: `as_is`, `escalated`. Defaults to `as_is`.
    *   `Base Density Escalation`: (Optional) Base density used for `escalated` price calculations for this specific grade. Overrides the global setting.
    *   `RON Linear Min`: (Optional) Minimum threshold for linear RON calculation.
    *   `Force Ethanol Enabled`: (Optional) Boolean (`TRUE`/`FALSE`) to enable ethanol forcing.
    *   `Force Ethanol Mass Frac`: (Optional) Required mass fraction if ethanol forcing is enabled.
    *   *Property Specification Columns*: **Required.** Columns for each property that has a specification. Use suffixes `_min`, `_max`, or `_target` (e.g., `RON_min`, `Sulfur PPM_max`, `Density_min`, `Density_max`). The property name part must match the constants (e.g., `SULFUR_PPM_max`).
    *   *Component Constraint Columns*: (Optional) Columns specifying minimum or maximum fractions for specific components in this grade. Use suffixes `_min` or `_max` (e.g., `Ethanol_min`, `Reformate_max`).
    *   *Additive Dosage Columns*: (Optional) Columns specifying the required dosage for specific additives in ppm by weight (e.g., `AdditiveA_ppmw`).

### 3. Additives File (`additives_example.xlsx`)

This file defines optional additives used in blending.

*   **Sheet Name:** Typically `Additives`.
*   **Columns:**
    *   `Name`: **Required.** Unique name for the additive (e.g., `Additive_A`, `Detergent_X`).
    *   `Cost`: **Required.** Cost of the additive (e.g., USD per kg or USD per liter, ensure consistency with how cost is applied).
    *   `Density`: **Required.** Density of the additive (e.g., kg/m3). This is crucial for converting between mass, volume, and ppm by volume.

**Note on Additive Handling (v1.3.4):** Additives are incorporated into the blend based on **ppm by volume** constraints specified in the Grades file. The optimizer ensures the final blend meets these volumetric requirements. The cost contribution of additives is calculated based on their specified cost and the amount added (converted to mass using density if the cost is per mass unit, or used directly if cost is per volume unit).

### 4. Candidates File (`candidates_example.xlsx`)

This file defines specific blend recipes to be evaluated by the `eval-candidate` command.

*   **Sheet Name:** Typically `Candidates`.
*   **Columns:**
    *   `candidate_id`: **Required.** A unique identifier for the candidate blend.
    *   `grade_name`: **Required.** The name of the target grade this candidate is intended for. Must match a name in the Grades file.
    *   *Component Fraction Columns*: **Required.** Columns for each component used in the blend, with the header being the exact component name (e.g., `Reformate`, `Alkylate`, `Ethanol`). The values represent the **mass fraction** of that component in the blend. Fractions for a given candidate should sum to 1.0.



## Interpreting Results

Understanding the output of the optimization and analysis commands is crucial for making informed blending decisions.

### Optimization Results (`optimize` command)

When running the `optimize` command, the output (either in the console or the specified file) provides the following key information for each grade:

*   **Grade Name:** The name of the grade being optimized.
*   **Status:** Indicates whether the optimization was successful (`SUCCESS`) or failed (`FAILED`).
*   **Message:** Provides details about the optimization outcome (e.g., "Optimization terminated successfully", "Iteration limit reached", "Infeasible solution").
*   **Cost (USD/mt):** The minimum total cost per metric ton of the optimized blend.
*   **Component Fractions:** The **mass fraction** of each component in the optimal blend.
*   **Blend Properties:** The calculated properties (RON, Sulfur PPM, Density, etc.) of the final blend.
*   **Shadow Prices (Lagrange Multipliers):** (Displayed in console or included in output data) These values indicate the sensitivity of the total blend cost to changes in the constraints. See the "Shadow Prices" section below for details.

### Candidate Evaluation Results (`eval-candidate` command)

When running `eval-candidate`, the output provides:

*   **Candidate ID:** The identifier of the evaluated blend.
*   **Grade Name:** The target grade for the candidate.
*   **Cost (USD/mt):** The calculated cost of the candidate blend.
*   **Optimal Cost (USD/mt):** The cost of the optimal blend for the same grade (from the `--results-file`).
*   **Delta Cost:** The difference between the candidate cost and the optimal cost.
*   **Constraints OK?:** Indicates whether the candidate blend meets all specifications for the target grade (`Yes` or `No`).
*   **Violations:** If constraints are not met, this field (in the output file) may list the specific violations.
*   **Neutral Prices:** (Displayed in console or included in output data) These values indicate the price at which each component would be economically neutral to add to the blend. See the "Neutral Prices" section below for details.

### Sensitivity Analysis Results (`sensitivity` command)

When running `sensitivity`, the output shows the impact of parameter changes:

*   **Param Name:** The name of the parameter that was changed (e.g., component name for `presence` or `price` analysis).
*   **Param Value:** The value the parameter was set to for that run (e.g., 0 for removal in `presence`, or the new price differential in `price`).
*   **Grade Name:** The grade being analyzed.
*   **Status:** Success or failure of the optimization for this scenario.
*   **Cost (USD/mt):** The resulting blend cost for this scenario.
*   **Base Cost (USD/mt):** The cost from the initial optimization run (before parameter change).
*   **Delta Cost vs Base:** The difference in cost compared to the base case.

### Understanding Economic Indicators

#### Shadow Prices (Lagrange Multipliers)

Shadow prices, also known as Lagrange multipliers or dual values, are a key output of the optimization process, particularly when using solvers like `trust-constr`. They are associated with the constraints of the optimization problem (e.g., property limits like `RON_min`, `Sulfur PPM_max`, or component fraction limits).

*   **Interpretation:** A shadow price represents the rate of change in the optimal objective function value (i.e., the minimum blend cost) for a small relaxation (change) in the corresponding constraint's right-hand side. 
    *   For a `_min` constraint (e.g., `RON_min`), a positive shadow price indicates how much the total cost would *decrease* if the minimum requirement were lowered by one unit.
    *   For a `_max` constraint (e.g., `Sulfur PPM_max`), a positive shadow price indicates how much the total cost would *decrease* if the maximum limit were raised by one unit.
    *   A shadow price of zero typically means the constraint is not binding (i.e., the optimal solution is not limited by this constraint).
*   **Units:** The units are typically (Cost Unit / Constraint Unit), for example, (USD/mt) / (RON unit) or (USD/mt) / (ppm Sulfur).
*   **Usage:** Shadow prices are valuable for identifying bottlenecks in the blend. High shadow prices highlight constraints that significantly impact the cost. Understanding these sensitivities can guide decisions about component purchasing, process adjustments, or specification negotiations.
*   **Availability:** Shadow prices are reliably extracted when using the `trust-constr` solver. Other solvers like `SLSQP` may not provide them consistently.
*   **Output:** When running `optimize` without an `--output-file`, shadow prices are displayed in a table for each successful grade optimization.

#### Neutral Prices

Neutral prices are calculated by the `eval-candidate` command using the shadow prices obtained from a prior `optimize` run. They provide an economic valuation for each component within the context of a specific optimal blend.

*   **Interpretation:** The neutral price of a component is the theoretical price at which adding a marginal amount of that component to the optimal blend would neither increase nor decrease the total blend cost. It represents the economic breakeven point for that component in that specific blend.
    *   If a component's actual cost (or price differential) is *lower* than its neutral price (or neutral differential), it is economically favorable to use more of it (if constraints allow).
    *   If a component's actual cost is *higher* than its neutral price, it is economically unfavorable.
*   **Calculation:** The neutral price is derived from the component's contribution to meeting the blend constraints, valued by the shadow prices of those constraints, relative to the overall blend cost (often represented by the shadow price of the sum-to-one constraint or calculated relative to the flat price).
*   **Types:** The neutral value can be expressed as:
    *   `Neutral Price (USD/mt)`: The absolute breakeven price.
    *   `Delta Neutral`: The breakeven price *differential* relative to the flat price (for components priced `as_is` or `escalated`).
    *   `Multiplier Neutral`: The breakeven price *factor* relative to the flat price (for components priced using `factor`).
*   **Usage:** Neutral prices help evaluate the relative economic value of different components in a given blend scenario. They can inform purchasing strategies and identify opportunities for cost reduction by substituting components based on their economic contribution versus their market price.
*   **Output:** When running `eval-candidate` without an `--output-file`, neutral prices (or their delta/multiplier equivalents) are displayed in a table for each evaluated grade.



## Development and Testing

### Running Tests

Automated tests are crucial for ensuring the package's correctness and stability. Tests are implemented using `pytest`.

1.  **Install Development Dependencies:** Make sure you have installed the package with the `[dev]` extras:
    ```bash
    pip install -e ".[dev]"
    ```
2.  **Run Tests:** Navigate to the main `fuel_blending` directory (the one containing `run_tests.sh`) and execute the test script:
    ```bash
    bash run_tests.sh
    ```
    This script runs `pytest`, which will automatically discover and execute tests located in the `fuel_blending/tests` directory.

### Type Checking

The codebase uses type hints extensively. You can use `mypy` for static type checking to catch potential errors before runtime.

1.  **Install Development Dependencies:** Ensure `mypy` is installed (included in `[dev]` extras).
2.  **Run Type Checking:** From the main `fuel_blending` directory, run:
    ```bash
    mypy .
    ```
    `mypy` will analyze the code and report any type inconsistencies or errors found.



## Troubleshooting

*   **`ModuleNotFoundError`:** Ensure your virtual environment is activated and you have installed the package correctly using `pip install -e .`. If the error persists, check your `PYTHONPATH` or potential conflicts with other installed packages.
*   **Google Drive Authentication Errors:** Verify that your `credentials.json` file is correctly configured and accessible. The first time you run a command using Google Drive, you might be prompted to authorize the application in your browser. Ensure the `token.json` file is writable.
*   **Optimization Failures:** If the `optimize` command fails (`FAILED` status):
    *   Check the logs for detailed error messages from the solver.
    *   Verify that the grade specifications are feasible given the component properties.
    *   Try increasing `optimizer.options.maxiter` or adjusting tolerances in the configuration.
    *   Consider trying a different solver (`trust-constr` or `slsqp`).
*   **Constraint Violations:** If `check_constraints_post` is enabled and violations are reported after optimization, it might indicate numerical instability or very tight tolerances. Try slightly relaxing the `optimizer.constraint_tolerance` or the grade specifications.
*   **Incorrect Calculations:** Double-check your input data formats and values. Ensure units are consistent across all input files.



## Conclusion

This guide provides a comprehensive overview of the Fuel Blending Optimization Package. By leveraging its features for optimization, evaluation, and sensitivity analysis, users can gain valuable insights into their blending processes and achieve significant cost savings while maintaining product quality. Remember to consult the specific sections for detailed instructions and refer to the troubleshooting guide if you encounter issues.

